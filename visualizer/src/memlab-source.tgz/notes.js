// node notes.js id  → list step index, line, note text, and dangling count
const { chromium } = require('playwright'); const path = require('path');
(async () => { const b = await chromium.launch(); const p = await b.newPage();
  await p.goto('file://' + path.resolve('dist/index.html'));
  const r = await p.evaluate(id => { location.hash = '#' + id; route(); const o = [];
    for (let i = 0; i < UI.snaps.length; i++) { go(i); o.push(i + ' L' + UI.snaps[i].line + ' d' + document.querySelectorAll('#mem .dang').length + ' ' + document.querySelector('#note').textContent.slice(0, 110)); } return o; }, process.argv[2]);
  console.log(r.join('\n')); await b.close(); })();
