const { chromium } = require('playwright'); const path = require('path');
(async () => { const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 420, height: 900 } });
  await p.goto('file://' + path.resolve('dist/index.html') + '#cp-list'); await p.evaluate(() => go(20)); await p.waitForTimeout(300);
  await p.screenshot({ path: '/tmp/claude-0/mob.png', fullPage: false }); await b.close(); })();
