// node shots.js → home in en light, th dark; one lab in th dark
const { chromium } = require('playwright'); const path = require('path');
(async () => { const b = await chromium.launch();
  for (const [scheme, lang, hash, file] of [['light','en','','home-en.png'],['dark','th','','home-th-dark.png'],['dark','th','#cp-vector','vec-th-dark.png']]) {
    const p = await b.newPage({ viewport: { width: 1500, height: 1000 }, colorScheme: scheme });
    await p.goto('file://' + path.resolve('dist/index.html') + hash);
    await p.evaluate(l => { setLang ? setLang(l) : 0; }, lang);
    if (hash) await p.evaluate(() => go(40));
    await p.waitForTimeout(400);
    await p.screenshot({ path: '/tmp/claude-0/' + file, fullPage: true }); await p.close(); }
  await b.close(); })();
