const { chromium } = require('playwright'); const path = require('path');
(async () => { const b = await chromium.launch(); const p = await b.newPage();
await p.goto('file://' + path.resolve('dist/index.html'));
const r = await p.evaluate(([id, k]) => { location.hash = '#' + id; route(); go(+k); return [...document.querySelectorAll('#mem .dang')].map(e => e.outerHTML + ' in ' + (e.closest('[data-addr],[data-base]')||{}).outerHTML?.slice(0,200)); }, [process.argv[2], process.argv[3]]);
console.log(r.join('\n')); await b.close(); })();
