/* Part I · heap memory, classes, this, copies, templates, lambdas */

// ------------------------------------------------------------------ new / delete
(() => {
  const code = `int main() {
    int* p = new int(7);        // one int on the heap
    int* arr = new int[4]();    // four ints, all zero
    for (int i = 0; i < 4; i++)
        arr[i] = (i + 1) * 10;
    *p = arr[2] + 1;            // 31
    delete p;                   // give the int back
    p = nullptr;
    int* leak = new int[2];     // garbage values!
    leak = arr;                 // the 2 ints are now lost
    delete[] arr;               // arrays need delete[]
    return 0;                   // leak and arr now dangle
}`;
  const at = LN(code);
  def({
    id: 'new-delete', dangOK: true, part: 1, lesson: '03', lessonFile: '03-cp-vector.md',
    title: L('The heap: new and delete', 'Heap: new และ delete'),
    summary: L('new reserves memory on the heap and gives you its address. That memory outlives the function and stays until you delete it. Forget delete and you leak; delete twice or use it afterwards and you corrupt memory.',
      'new จองหน่วยความจำบน heap แล้วคืนแอดเดรสให้คุณ หน่วยความจำนั้นอยู่ได้นานกว่าฟังก์ชัน จนกว่าคุณจะ delete ถ้าลืม delete ก็รั่ว ถ้า delete ซ้ำหรือใช้หลัง delete ก็ทำหน่วยความจำพัง'),
    blurb: L('new, new[], delete, delete[], leaks and dangling pointers.', 'new, new[], delete, delete[] หน่วยความจำรั่ว และพอยน์เตอร์ห้อย'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts. The heap is empty.', 'main เริ่มทำงาน heap ยังว่าง'));
      const hb = sim.newObj('int', [['value', 'int', 7]], { label: 'new int(7)', expr: 'new int(7)' });
      const p = sim.local('p', 'int*', P(hb));
      sim.step(at('new int(7)'), L(
        'Two things happen: <b class="h">new</b> finds 4 free bytes on the heap at ' + hex(hb) + ' and writes 7 there, then the <b>address</b> is stored in the stack variable <code>p</code>. The int has no name; you can reach it only through p.',
        'เกิดสองอย่าง: <b class="h">new</b> หา 4 ไบต์ว่างบน heap ที่ ' + hex(hb) + ' แล้วเขียน 7 ลงไป จากนั้น<b>แอดเดรส</b>ถูกเก็บในตัวแปร <code>p</code> บน stack ตัว int นี้ไม่มีชื่อ เข้าถึงได้ผ่าน p เท่านั้น'));
      const ab = sim.newArray('int', 4, 0, { label: 'new int[4]()', expr: 'new int[4]()' });
      const arr = sim.local('arr', 'int*', P(ab));
      sim.step(at('new int[4]()'), L(
        '<code>new int[4]()</code> reserves 16 contiguous bytes. The <code>()</code> means "value-initialise", so all four are 0. Without it they would be garbage. The block starts at ' + hex(ab) + ' (the gap after the first block stands for the allocator\'s bookkeeping).',
        '<code>new int[4]()</code> จอง 16 ไบต์ติดกัน วงเล็บ <code>()</code> หมายถึงกำหนดค่าเริ่มต้น ทั้งสี่ช่องจึงเป็น 0 ถ้าไม่มีจะเป็นค่าขยะ บล็อกเริ่มที่ ' + hex(ab) + ' (ช่องว่างหลังบล็อกแรกแทนพื้นที่ที่ตัวจัดสรรใช้จดบันทึก)'));
      const i = sim.local('i', 'int', 0);
      sim.tagFn = s => { const v = findVar(s, 'i'); return v && v.value < 4 ? [TAG(ab + 4 * v.value, 'i', 't2')] : []; };
      for (let k = 0; k < 4; k++) {
        sim.w(i, k); sim.r(arr); sim.w(ab + 4 * k, (k + 1) * 10);
        sim.step(at('arr[i] = (i + 1)'), L('i = ' + k + ': <code>arr[' + k + ']</code> is at ' + hex(ab) + ' + ' + k + '×4 = ' + hex(ab + 4 * k) + '. Write ' + ((k + 1) * 10) + '. Heap arrays are indexed exactly like stack arrays.', 'i = ' + k + ': <code>arr[' + k + ']</code> อยู่ที่ ' + hex(ab) + ' + ' + k + '×4 = ' + hex(ab + 4 * k) + ' เขียน ' + ((k + 1) * 10) + ' อาร์เรย์บน heap ใช้ดัชนีเหมือนอาร์เรย์บน stack ทุกอย่าง'));
      }
      sim.top().vars = sim.top().vars.filter(v => v.name !== 'i'); sim.tagFn = null;
      sim.r(arr); const v2 = sim.r(ab + 8); sim.r(p); sim.w(hb + 0, v2 + 1);
      sim.step(at('*p = arr[2] + 1'), L('Read arr[2] = 30 and write 31 through p.', 'อ่าน arr[2] = 30 แล้วเขียน 31 ผ่าน p'));
      sim.r(p); sim.free(hb);
      sim.step(at('delete p'), L(
        '<code>delete p;</code> hands the 4 bytes back to the allocator (shown faded, then removed). It does <b>not</b> change <code>p</code>: p still holds ' + hex(hb) + ', now pointing at memory that is no longer ours.',
        '<code>delete p;</code> คืน 4 ไบต์ให้ตัวจัดสรร (แสดงแบบจางแล้วหายไป) มัน<b>ไม่ได้</b>เปลี่ยน <code>p</code> เลย p ยังเก็บ ' + hex(hb) + ' ซึ่งตอนนี้ชี้ไปยังหน่วยความจำที่ไม่ใช่ของเราแล้ว'));
      sim.w(p, P(0));
      sim.step(at('p = nullptr'), L('Good habit: set it to nullptr so a later mistake crashes clearly instead of silently reading freed memory.', 'นิสัยที่ดี: ตั้งเป็น nullptr เพื่อให้ถ้าพลาดใช้ภายหลังจะแครชให้เห็นชัด แทนที่จะอ่านหน่วยความจำที่ถูกคืนไปแล้วแบบเงียบ ๆ'));
      const lb = sim.newArray('int', 2, undefined, { label: 'new int[2]', expr: 'new int[2]' });
      const leak = sim.local('leak', 'int*', P(lb));
      sim.step(at('new int[2]'), L('No <code>()</code> this time, so the two ints are <b>garbage</b> (?).', 'ครั้งนี้ไม่มี <code>()</code> int สองตัวจึงเป็น<b>ค่าขยะ</b> (?)'));
      sim.r(arr); sim.w(leak, P(ab));
      sim.setLabel(lb, L('LEAKED: no pointer reaches it', 'รั่ว: ไม่มีพอยน์เตอร์ไปถึงแล้ว'));
      sim.step(at('leak = arr'), L(
        '<code>leak = arr;</code> overwrites the only copy of ' + hex(lb) + '. That block is still reserved, but nothing points to it, so it can never be deleted: a <b>memory leak</b>. A few leaks are harmless; a leak inside a loop that runs 10⁶ times gives Memory Limit Exceeded.',
        '<code>leak = arr;</code> เขียนทับสำเนาเดียวของ ' + hex(lb) + ' บล็อกนั้นยังถูกจองอยู่ แต่ไม่มีอะไรชี้ไปถึง จึงไม่มีทาง delete ได้อีก นี่คือ<b>หน่วยความจำรั่ว</b> รั่วนิดหน่อยไม่เป็นไร แต่ถ้ารั่วในลูปที่ทำ 10⁶ รอบจะโดน Memory Limit Exceeded'), { cls: 'warn' });
      sim.r(arr); sim.free(ab);
      sim.step(at('delete[] arr'), L(
        'Memory from <code>new[]</code> must be freed with <code>delete[]</code> (the brackets matter). Now both <code>arr</code> and <code>leak</code> point to freed memory.',
        'หน่วยความจำจาก <code>new[]</code> ต้องคืนด้วย <code>delete[]</code> (วงเล็บเหลี่ยมสำคัญ) ตอนนี้ทั้ง <code>arr</code> และ <code>leak</code> ชี้ไปยังหน่วยความจำที่ถูกคืนแล้ว'));
      sim.step(at('return 0'), L(
        'Two dangling pointers, one leaked block. When the program ends, the OS reclaims everything, but inside a long-running program these are real bugs. Rule: <b>every new has exactly one delete</b>, and containers like vector exist to do this for you.',
        'พอยน์เตอร์ห้อยสองตัว บล็อกรั่วหนึ่งบล็อก เมื่อโปรแกรมจบ OS จะเก็บคืนทั้งหมด แต่ในโปรแกรมที่ทำงานนาน ๆ นี่คือบั๊กจริง กฎคือ <b>new หนึ่งครั้งต้องมี delete หนึ่งครั้งพอดี</b> และคอนเทนเนอร์อย่าง vector มีไว้ทำเรื่องนี้แทนคุณ'), { cls: 'warn' });
    }
  });
})();

// ------------------------------------------------------------------ classes and this
(() => {
  const code = `struct Point {
    int x, y;
    Point(int x0, int y0) : x(x0), y(y0) {}
    void move(int dx, int dy) {
        x += dx;          // really: this->x += dx
        y += dy;
    }
    int dist2() const { return x * x + y * y; }
};
int main() {
    Point a(1, 2);
    Point b = a;          // copies every field
    a.move(3, 4);         // passes this = &a
    Point* pp = &b;
    pp->x = 9;            // same as (*pp).x = 9
    cout << a.dist2() << " " << b.x << "\\n";
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'classes', part: 1, lesson: '03', lessonFile: '03-cp-vector.md',
    title: L('Objects, member functions and this', 'อ็อบเจกต์ ฟังก์ชันสมาชิก และ this'),
    summary: L('An object is its fields packed together in memory. A member function is a normal function with one hidden extra parameter: this, the address of the object it was called on. Every CP:: container method you write in student.h works this way.',
      'อ็อบเจกต์คือฟิลด์ของมันที่เรียงติดกันในหน่วยความจำ ฟังก์ชันสมาชิกก็คือฟังก์ชันธรรมดาที่มีพารามิเตอร์ลับเพิ่มมาหนึ่งตัว: this ซึ่งคือแอดเดรสของอ็อบเจกต์ที่ถูกเรียก ทุกเมธอดของคอนเทนเนอร์ CP:: ที่คุณเขียนใน student.h ทำงานแบบนี้'),
    blurb: L('Object layout, constructors, the hidden this pointer, ->.', 'เลย์เอาต์ของอ็อบเจกต์ คอนสตรักเตอร์ พอยน์เตอร์ this ที่ซ่อนอยู่ และ ->'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const a = sim.obj('a', 'Point', [['x', 'int', undefined], ['y', 'int', undefined]]);
      sim.step(at('Point a(1, 2)'), L(
        'First, space for <code>a</code> is reserved in main\'s frame: 8 bytes, <code>x</code> at offset 0 and <code>y</code> at offset 4. The fields are garbage until the constructor runs.',
        'ขั้นแรก พื้นที่ของ <code>a</code> ถูกจองในเฟรมของ main: 8 ไบต์ <code>x</code> อยู่ที่ offset 0 และ <code>y</code> ที่ offset 4 ฟิลด์ยังเป็นค่าขยะจนกว่าคอนสตรักเตอร์จะทำงาน'));
      sim.call('Point::Point(int x0, int y0)');
      sim.param('this', 'Point*', P(a)); sim.param('x0', 'int', 1); sim.param('y0', 'int', 2);
      sim.step(at('Point(int x0'), L(
        'The <b>constructor</b> is called like a function. Look at its frame: besides x0 and y0 there is a hidden parameter <code>this</code> = ' + hex(a) + ', the address of the object being built.',
        '<b>คอนสตรักเตอร์</b>ถูกเรียกเหมือนฟังก์ชัน ดูเฟรมของมัน: นอกจาก x0 กับ y0 ยังมีพารามิเตอร์ลับ <code>this</code> = ' + hex(a) + ' คือแอดเดรสของอ็อบเจกต์ที่กำลังสร้าง'));
      sim.wf(a, 'x', 1); sim.wf(a, 'y', 2);
      sim.step(at('Point(int x0'), L('The initialiser list <code>: x(x0), y(y0)</code> writes through this: this->x = 1, this->y = 2.', 'initialiser list <code>: x(x0), y(y0)</code> เขียนผ่าน this: this->x = 1, this->y = 2'));
      sim.ret(undefined, { show: false });
      sim.step(at('Point a(1, 2)'), L('Constructor done; a = {1, 2}.', 'คอนสตรักเตอร์เสร็จแล้ว a = {1, 2}'));
      const b = sim.obj('b', 'Point', [['x', 'int', sim.rf(a, 'x')], ['y', 'int', sim.rf(a, 'y')]]);
      sim.step(at('Point b = a'), L(
        '<code>Point b = a;</code> makes a <b>new object</b> and copies every field. Point has only ints, so the copy is complete and independent.',
        '<code>Point b = a;</code> สร้าง<b>อ็อบเจกต์ใหม่</b>และคัดลอกทุกฟิลด์ Point มีแค่ int การคัดลอกจึงครบและเป็นอิสระต่อกัน'));
      sim.step(at('a.move(3, 4)'), L('<code>a.move(3, 4)</code> is compiled as roughly <code>Point::move(&a, 3, 4)</code>.', '<code>a.move(3, 4)</code> ถูกคอมไพล์เป็นประมาณ <code>Point::move(&a, 3, 4)</code>'));
      sim.call('Point::move(int dx, int dy)');
      const th = sim.param('this', 'Point*', P(a)); sim.param('dx', 'int', 3); sim.param('dy', 'int', 4);
      sim.step(at('void move'), L('Inside <code>move</code>, <code>this</code> points at <code>a</code>. The function itself exists only once in the program; <code>this</code> is what tells it which object to work on.', 'ใน <code>move</code> ตัว <code>this</code> ชี้ไปที่ <code>a</code> ตัวฟังก์ชันมีอยู่ชุดเดียวในโปรแกรม <code>this</code> คือสิ่งที่บอกว่าจะทำงานกับอ็อบเจกต์ไหน'));
      sim.r(th); sim.wf(a, 'x', sim.rf(a, 'x') + 3);
      sim.step(at('x += dx'), L('<code>x</code> alone means <code>this->x</code>: follow this to ' + hex(a) + ', add 3. a.x = 4.', '<code>x</code> เฉย ๆ หมายถึง <code>this->x</code>: ตาม this ไปที่ ' + hex(a) + ' แล้วบวก 3 ได้ a.x = 4'));
      sim.r(th); sim.wf(a, 'y', sim.rf(a, 'y') + 4);
      sim.step(at('y += dy'), L('this->y += 4, so a.y = 6. b is untouched.', 'this->y += 4 ได้ a.y = 6 ส่วน b ไม่ถูกแตะเลย'));
      sim.ret(undefined, { show: false });
      sim.step(at('a.move(3, 4)'), L('move returns.', 'move คืนค่า'));
      const pp = sim.local('pp', 'Point*', P(b));
      sim.step(at('Point* pp = &b'), L('A pointer to an object points at its first byte: <code>pp</code> = ' + hex(b) + '.', 'พอยน์เตอร์ไปยังอ็อบเจกต์ชี้ที่ไบต์แรกของมัน: <code>pp</code> = ' + hex(b)));
      sim.r(pp); sim.wf(b, 'x', 9);
      sim.step(at('pp->x = 9'), L('<code>pp->x</code> = go to ' + hex(b) + ', then to field x (offset 0). b.x = 9.', '<code>pp->x</code> = ไปที่ ' + hex(b) + ' แล้วไปที่ฟิลด์ x (offset 0) ได้ b.x = 9'));
      sim.call('Point::dist2() const');
      sim.param('this', 'const Point*', P(a));
      const ax = sim.rf(a, 'x'), ay = sim.rf(a, 'y');
      sim.step(at('int dist2'), L('<code>a.dist2()</code>: this = &a. The <code>const</code> after the parentheses makes this a <i>const Point*</i>, so the function may read but not write the fields. 4×4 + 6×6 = 52.', '<code>a.dist2()</code>: this = &a คำว่า <code>const</code> หลังวงเล็บทำให้ this เป็น <i>const Point*</i> ฟังก์ชันจึงอ่านฟิลด์ได้แต่เขียนไม่ได้ 4×4 + 6×6 = 52'));
      sim.ret(ax * ax + ay * ay);
      sim.rf(b, 'x'); sim.print('52 9\n');
      sim.step(at('cout'), L('Output <code>52 9</code>. In student.h, <code>mData</code>, <code>mSize</code> and friends are fields reached through this exactly like x and y here.', 'ผลลัพธ์ <code>52 9</code> ใน student.h ตัว <code>mData</code>, <code>mSize</code> และฟิลด์อื่น ๆ ก็ถูกเข้าถึงผ่าน this แบบเดียวกับ x และ y ตรงนี้'));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();

// ------------------------------------------------------------------ deep copy / shallow copy
function boxScenario(shallow) {
  const code = shallow ? `class Box {
  public:
    int* data;
    int  n;
    Box(int n0) : n(n0) {
        data = new int[n]();
    }
    // no copy constructor written, so the compiler's
    // default copies each field, POINTER included
    ~Box() { delete[] data; }
};
int main() {
    Box a(3);
    a.data[0] = 5;
    Box b = a;          // default copy: same array!
    b.data[0] = 9;      // changes a's array too
    cout << a.data[0] << " " << b.data[0] << "\\n";
    return 0;
}                       // destructors: b, then a` : `class Box {
  public:
    int* data;
    int  n;
    Box(int n0) : n(n0) {
        data = new int[n]();
    }
    Box(const Box& o) : n(o.n) {   // deep copy
        data = new int[n];
        for (int i = 0; i < n; i++)
            data[i] = o.data[i];
    }
    ~Box() { delete[] data; }
};
int main() {
    Box a(3);
    a.data[0] = 5;
    Box b = a;          // calls the copy constructor
    b.data[0] = 9;      // only b's array changes
    cout << a.data[0] << " " << b.data[0] << "\\n";
    return 0;
}                       // destructors: b, then a`;
  const at = LN(code);
  def({
    id: shallow ? 'shallow-copy' : 'deep-copy', dangOK: true, part: 1, lesson: '03', lessonFile: '03-cp-vector.md',
    title: shallow ? L('The shallow-copy bug (double delete)', 'บั๊กการคัดลอกแบบตื้น (delete ซ้ำ)') : L('A class that owns heap memory', 'คลาสที่เป็นเจ้าของหน่วยความจำบน heap'),
    summary: shallow
      ? L('Same class without a copy constructor. The default copy duplicates the pointer, not the array, so two objects share one block. Changing one changes the other, and both destructors delete the same block.',
        'คลาสเดิมแต่ไม่มี copy constructor การคัดลอกแบบปริยายจะคัดลอกพอยน์เตอร์ ไม่ใช่อาร์เรย์ อ็อบเจกต์สองตัวจึงใช้บล็อกเดียวกัน แก้ตัวหนึ่งอีกตัวก็เปลี่ยน และ destructor ทั้งสองจะ delete บล็อกเดียวกัน')
      : L('A mini vector: the object on the stack holds a pointer to its array on the heap. Constructor allocates, destructor frees, copy constructor makes a real second array. This is the exact skeleton of CP::vector.',
        'vector ขนาดจิ๋ว: อ็อบเจกต์บน stack เก็บพอยน์เตอร์ไปยังอาร์เรย์บน heap คอนสตรักเตอร์จอง destructor คืน copy constructor สร้างอาร์เรย์ชุดที่สองจริง ๆ นี่คือโครงของ CP::vector เป๊ะ ๆ'),
    blurb: shallow ? L('What goes wrong without a copy constructor.', 'จะเกิดอะไรขึ้นถ้าไม่มี copy constructor') : L('Constructor, destructor, deep copy: the skeleton of CP::vector.', 'คอนสตรักเตอร์ destructor การคัดลอกแบบลึก: โครงของ CP::vector'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const a = sim.obj('a', 'Box', [['data', 'int*', undefined], ['n', 'int', undefined]]);
      sim.step(at('Box a(3)'), L('Space for <code>a</code> (16 bytes: an 8-byte pointer and a 4-byte int, plus 4 bytes of padding) is reserved in main\'s frame.', 'จองพื้นที่ของ <code>a</code> ในเฟรมของ main (16 ไบต์: พอยน์เตอร์ 8 ไบต์ int 4 ไบต์ และ padding 4 ไบต์)'));
      sim.call('Box::Box(int n0)');
      sim.param('this', 'Box*', P(a)); sim.param('n0', 'int', 3);
      sim.wf(a, 'n', 3);
      sim.step(at('Box(int n0)'), L('Constructor with this = &a. The initialiser list sets this->n = 3.', 'คอนสตรักเตอร์ที่มี this = &a initialiser list ตั้งค่า this->n = 3'));
      const da = sim.newArray('int', 3, 0, { label: L("a's array", 'อาร์เรย์ของ a'), expr: 'new int[3]()' });
      sim.wf(a, 'data', P(da));
      sim.step(at('data = new int[n]()', 1), L('The constructor allocates the real storage on the heap and stores its address in <code>this->data</code>. The object itself stays small (16 bytes) no matter how big the array is.', 'คอนสตรักเตอร์จองที่เก็บข้อมูลจริงบน heap แล้วเก็บแอดเดรสไว้ใน <code>this->data</code> ตัวอ็อบเจกต์ยังเล็กเท่าเดิม (16 ไบต์) ไม่ว่าอาร์เรย์จะใหญ่แค่ไหน'));
      sim.ret(undefined, { show: false });
      sim.step(at('Box a(3)'), L('a is built.', 'สร้าง a เสร็จ'));
      sim.rf(a, 'data'); sim.w(da, 5);
      sim.step(at('a.data[0] = 5'), L('Follow a.data to the heap and write 5 into element 0.', 'ตาม a.data ไปที่ heap แล้วเขียน 5 ลงช่องที่ 0'));
      let b, db;
      if (shallow) {
        b = sim.obj('b', 'Box', [['data', 'int*', P(da)], ['n', 'int', 3]]);
        sim.step(at('Box b = a'), L(
          'The default copy copies each field <b>bit for bit</b>. <code>b.data</code> gets the same address ' + hex(da) + ': two arrows to <b>one</b> array. Only the pointer was copied, not what it points to. This is a <b>shallow copy</b>.',
          'การคัดลอกแบบปริยายคัดลอกทุกฟิลด์<b>ทีละบิต</b> <code>b.data</code> จึงได้แอดเดรสเดียวกัน ' + hex(da) + ' ลูกศรสองอันชี้ไปที่อาร์เรย์<b>อันเดียว</b> คัดลอกแค่พอยน์เตอร์ ไม่ได้คัดลอกสิ่งที่มันชี้ นี่คือ<b>การคัดลอกแบบตื้น</b>'), { cls: 'warn' });
        sim.rf(b, 'data'); sim.w(da, 9);
        sim.step(at('b.data[0] = 9'), L('Writing through b changes the shared block, so a.data[0] is now 9 as well.', 'การเขียนผ่าน b เปลี่ยนบล็อกที่ใช้ร่วมกัน a.data[0] จึงเป็น 9 ไปด้วย'), { cls: 'warn' });
        sim.r(da); sim.r(da); sim.print('9 9\n');
        sim.step(at('cout'), L('Prints <code>9 9</code>, not 5 9.', 'พิมพ์ <code>9 9</code> ไม่ใช่ 5 9'));
        sim.step(at('return 0'), L('main ends. Local objects are destroyed in <b>reverse order</b> of construction: b first, then a.', 'main จบ อ็อบเจกต์ภายในถูกทำลายใน<b>ลำดับย้อนกลับ</b>ของการสร้าง: b ก่อน แล้วค่อย a'));
        sim.call('Box::~Box()'); sim.param('this', 'Box*', P(b));
        sim.free(da);
        sim.step(at('~Box()'), L('<code>~Box()</code> for b: <code>delete[] data</code> frees ' + hex(da) + '. Now a.data points to freed memory (dangling).', '<code>~Box()</code> ของ b: <code>delete[] data</code> คืน ' + hex(da) + ' ตอนนี้ a.data ชี้ไปที่หน่วยความจำที่ถูกคืนแล้ว (ห้อย)'));
        sim.ret(undefined, { show: false });
        sim.call('Box::~Box()'); sim.param('this', 'Box*', P(a));
        sim.step(at('~Box()'), L(
          '<code>~Box()</code> for a tries <code>delete[]</code> on ' + hex(da) + ' <b>again</b>. That is a <b>double free</b>: glibc aborts with "free(): double free detected", which the grader shows as a Runtime Error. The fix is the deep-copy constructor in the previous scenario (or deleting the copy constructor).',
          '<code>~Box()</code> ของ a พยายาม <code>delete[]</code> ที่ ' + hex(da) + ' <b>อีกครั้ง</b> นี่คือ <b>double free</b>: glibc จะหยุดโปรแกรมพร้อมข้อความ "free(): double free detected" ซึ่ง grader แสดงเป็น Runtime Error วิธีแก้คือ copy constructor แบบลึกในบทก่อนหน้า (หรือห้ามการคัดลอกไปเลย)'), { cls: 'warn' });
        sim.print('free(): double free detected in tcache 2\nAborted (core dumped)\n');
        sim.step(at('~Box()'), L('The program crashes.', 'โปรแกรมแครช'), { cls: 'warn' });
        return;
      }
      b = sim.obj('b', 'Box', [['data', 'int*', undefined], ['n', 'int', undefined]]);
      sim.step(at('Box b = a'), L('<code>Box b = a;</code> reserves space for b, then calls the <b>copy constructor</b> with <code>o</code> referring to a.', '<code>Box b = a;</code> จองพื้นที่ให้ b แล้วเรียก <b>copy constructor</b> โดยที่ <code>o</code> อ้างถึง a'));
      sim.call('Box::Box(const Box& o)');
      sim.param('this', 'Box*', P(b)); sim.ref('o', 'const Box', a, { param: true });
      sim.wf(b, 'n', sim.rf(a, 'n'));
      sim.step(at('Box(const Box& o)'), L('this = &b, o = alias of a. First copy the size: this->n = o.n = 3.', 'this = &b, o = ชื่อแฝงของ a ขั้นแรกคัดลอกขนาด: this->n = o.n = 3'));
      db = sim.newArray('int', 3, undefined, { label: L("b's own array", 'อาร์เรย์ของ b เอง'), expr: 'new int[3]' });
      sim.wf(b, 'data', P(db));
      sim.step(at('data = new int[n];'), L('Allocate a <b>second, separate</b> array for b (garbage for now).', 'จองอาร์เรย์<b>ชุดที่สองแยกต่างหาก</b>ให้ b (ตอนนี้ยังเป็นค่าขยะ)'));
      const i = sim.local('i', 'int', 0);
      sim.tagFn = s => { const v = findVar(s, 'i'); return v && v.value < 3 ? [TAG(db + 4 * v.value, 'i', 't2'), TAG(da + 4 * v.value, 'i', 't2')] : []; };
      for (let k = 0; k < 3; k++) {
        sim.w(i, k); sim.w(db + 4 * k, sim.r(da + 4 * k));
        sim.step(at('data[i] = o.data[i]'), L('Copy element ' + k + ': ' + fmtPlain(sim.peek(da + 4 * k)) + '.', 'คัดลอกช่องที่ ' + k + ': ' + fmtPlain(sim.peek(da + 4 * k))));
      }
      sim.tagFn = null; sim.ret(undefined, { show: false });
      sim.step(at('Box b = a'), L('b now has its <b>own</b> array with the same contents: a <b>deep copy</b>. CP::vector\'s copy constructor does exactly this.', 'ตอนนี้ b มีอาร์เรย์<b>ของตัวเอง</b>ที่มีข้อมูลเหมือนกัน เรียกว่า<b>การคัดลอกแบบลึก</b> copy constructor ของ CP::vector ทำแบบนี้เป๊ะ'));
      sim.rf(b, 'data'); sim.w(db, 9);
      sim.step(at('b.data[0] = 9'), L('Only b\'s array changes. a.data[0] is still 5.', 'มีแค่อาร์เรย์ของ b ที่เปลี่ยน a.data[0] ยังเป็น 5'));
      sim.r(da); sim.r(db); sim.print('5 9\n');
      sim.step(at('cout'), L('Prints <code>5 9</code>.', 'พิมพ์ <code>5 9</code>'));
      sim.step(at('return 0'), L('main ends. Destructors run automatically, in reverse order: b first, then a.', 'main จบ destructor ทำงานอัตโนมัติในลำดับย้อนกลับ: b ก่อน แล้ว a'));
      sim.call('Box::~Box()'); sim.param('this', 'Box*', P(b)); sim.free(db);
      sim.step(at('~Box()'), L('<code>~Box()</code> with this = &b frees b\'s array.', '<code>~Box()</code> ที่มี this = &b คืนอาร์เรย์ของ b'));
      sim.ret(undefined, { show: false });
      sim.call('Box::~Box()'); sim.param('this', 'Box*', P(a)); sim.free(da);
      sim.step(at('~Box()'), L('Then a\'s destructor frees a\'s array. Every new has exactly one delete. No leaks, no double free.', 'จากนั้น destructor ของ a คืนอาร์เรย์ของ a new ทุกครั้งมี delete หนึ่งครั้งพอดี ไม่รั่ว ไม่ delete ซ้ำ'));
      sim.ret(undefined, { show: false });
      sim.ret(0, { show: false });
      sim.step(at('}  '), L('main\'s frame is popped. The heap is empty again.', 'เฟรมของ main ถูก pop heap ว่างอีกครั้ง'));
    }
  });
}
boxScenario(false);
boxScenario(true);

// ------------------------------------------------------------------ templates
(() => {
  const code = `template <typename T>
T biggest(T a, T b) {
    return (a < b) ? b : a;
}
int main() {
    int i = biggest(3, 8);          // makes biggest<int>
    double d = biggest(2.5, 1.5);   // makes biggest<double>
    cout << i << " " << d << "\\n";
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'templates', part: 1, lesson: '03', lessonFile: '03-cp-vector.md',
    title: L('Templates are stamped out per type', 'เทมเพลตถูกปั๊มแยกตามชนิด'),
    summary: L('A template is a recipe, not code. When you call biggest(3, 8) the compiler writes a real function biggest<int>; biggest(2.5, 1.5) produces a different one, biggest<double>, with 8-byte parameters. CP::vector<T> works the same way.',
      'เทมเพลตคือสูตร ไม่ใช่โค้ด เมื่อเรียก biggest(3, 8) คอมไพเลอร์จะเขียนฟังก์ชันจริงชื่อ biggest<int> ส่วน biggest(2.5, 1.5) จะได้อีกฟังก์ชันคือ biggest<double> ที่มีพารามิเตอร์ 8 ไบต์ CP::vector<T> ก็ทำงานแบบเดียวกัน'),
    blurb: L('One recipe, separate functions for int and double.', 'สูตรเดียว ได้ฟังก์ชันแยกสำหรับ int และ double'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts. At compile time the compiler saw two calls and generated two versions of biggest.', 'main เริ่มทำงาน ตอนคอมไพล์ คอมไพเลอร์เห็นการเรียกสองแบบ จึงสร้าง biggest ขึ้นมาสองเวอร์ชัน'));
      sim.call('biggest<int>(int a, int b)');
      sim.param('a', 'int', 3); sim.param('b', 'int', 8);
      sim.step(at('T biggest'), L('<code>biggest&lt;int&gt;</code>: every T became <code>int</code>, so a and b are 4-byte boxes.', '<code>biggest&lt;int&gt;</code>: T ทุกตัวกลายเป็น <code>int</code> a และ b จึงเป็นกล่อง 4 ไบต์'));
      sim.step(at('return (a < b)'), L('3 &lt; 8, so return b = 8. The &lt; used here is int comparison.', '3 &lt; 8 จึงคืน b = 8 เครื่องหมาย &lt; ตรงนี้คือการเปรียบเทียบ int'));
      sim.ret(8);
      sim.local('i', 'int', 8);
      sim.step(at('int i = biggest'), L('i = 8.', 'i = 8'));
      sim.call('biggest<double>(double a, double b)');
      sim.param('a', 'double', 2.5); sim.param('b', 'double', 1.5);
      sim.step(at('T biggest'), L('<code>biggest&lt;double&gt;</code> is a <b>different function</b> in the compiled program, with 8-byte parameters and floating-point comparison.', '<code>biggest&lt;double&gt;</code> เป็น<b>คนละฟังก์ชัน</b>ในโปรแกรมที่คอมไพล์แล้ว มีพารามิเตอร์ 8 ไบต์และเปรียบเทียบแบบทศนิยม'));
      sim.step(at('return (a < b)'), L('2.5 &lt; 1.5 is false, so return a = 2.5.', '2.5 &lt; 1.5 เป็นเท็จ จึงคืน a = 2.5'));
      sim.ret(2.5, { type: 'double' });
      sim.local('d', 'double', 2.5);
      sim.step(at('double d = biggest'), L('d = 2.5.', 'd = 2.5'));
      sim.print('8 2.5\n');
      sim.step(at('cout'), L(
        'Output <code>8 2.5</code>. This is also why template code must use only operations every T supports: in a CP::priority_queue you compare with <code>mLess</code>, never with &lt;, because T might be a type whose order is defined by the comparator.',
        'ผลลัพธ์ <code>8 2.5</code> นี่คือเหตุผลที่โค้ดเทมเพลตต้องใช้เฉพาะสิ่งที่ T ทุกชนิดรองรับ ใน CP::priority_queue ต้องเปรียบเทียบด้วย <code>mLess</code> ห้ามใช้ &lt; เพราะ T อาจเป็นชนิดที่ลำดับถูกกำหนดโดย comparator'));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();

// ------------------------------------------------------------------ lambdas
(() => {
  const code = `struct Counter {
    int base = 100;
    int add(int k) {
        auto f = [this, k](int x) { return base + k + x; };
        return f(1);
    }
};
int main() {
    int total = 0;
    int step = 5;
    auto byRef = [&total](int x) { total += x; };
    auto byVal = [step](int x) { return x * step; };
    byRef(3);
    step = 50;              // byVal kept its own copy (5)
    int r = byVal(2);       // 10, not 100
    Counter c;
    int s = c.add(7);       // 100 + 7 + 1
    cout << total << " " << r << " " << s << "\\n";
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'lambdas', part: 1, lesson: '02', lessonFile: '02-stl.md',
    title: L('Lambdas and captures: [&], [=], [this]', 'แลมบ์ดาและการจับตัวแปร: [&], [=], [this]'),
    summary: L('A lambda is a small object the compiler builds for you. Each captured variable becomes a field: [step] copies the value in, [&total] stores total\'s address, and [this] stores the object\'s address. Calling the lambda calls its operator() with this = the lambda object.',
      'แลมบ์ดาคืออ็อบเจกต์เล็ก ๆ ที่คอมไพเลอร์สร้างให้ ตัวแปรที่ถูกจับแต่ละตัวกลายเป็นฟิลด์: [step] คัดลอกค่าเข้าไป [&total] เก็บแอดเดรสของ total และ [this] เก็บแอดเดรสของอ็อบเจกต์ การเรียกแลมบ์ดาคือการเรียก operator() ของมัน โดย this = อ็อบเจกต์แลมบ์ดานั้น'),
    blurb: L('Closure objects, capture by value vs reference, [this].', 'อ็อบเจกต์ closure การจับแบบค่า vs reference และ [this]'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const total = sim.local('total', 'int', 0), step = sim.local('step', 'int', 5);
      sim.step(at('int step'), L('Two ordinary ints.', 'int ธรรมดาสองตัว'));
      const br = sim.obj('byRef', 'lambda [&total]', [['total', 'int&', P(total)]]);
      sim.step(at('auto byRef'), L(
        'The compiler invents a class for this lambda and creates an object <code>byRef</code>. Capturing <code>&total</code> gives it one field holding <b>total\'s address</b>. No code has run yet; the body runs only when you call it.',
        'คอมไพเลอร์สร้างคลาสขึ้นมาให้แลมบ์ดานี้ แล้วสร้างอ็อบเจกต์ <code>byRef</code> การจับ <code>&total</code> ทำให้มันมีฟิลด์หนึ่งตัวที่เก็บ<b>แอดเดรสของ total</b> ยังไม่มีโค้ดใดทำงาน ตัวฟังก์ชันจะทำงานเมื่อถูกเรียกเท่านั้น'));
      const bv = sim.obj('byVal', 'lambda [step]', [['step', 'int', sim.r(step)]]);
      sim.step(at('auto byVal'), L('Capturing <code>step</code> by value <b>copies</b> 5 into a field of the lambda object, right now, at creation time.', 'การจับ <code>step</code> แบบค่าจะ<b>คัดลอก</b> 5 ลงในฟิลด์ของอ็อบเจกต์แลมบ์ดา ตอนนี้เลย ณ เวลาที่สร้าง'));
      sim.call('byRef.operator()(int x)');
      sim.param('this', 'closure*', P(br)); sim.param('x', 'int', 3);
      sim.step(at('byRef(3)'), L('Calling <code>byRef(3)</code> runs its <code>operator()</code>. Like any member function it gets a hidden <code>this</code>, here pointing at the lambda object.', 'การเรียก <code>byRef(3)</code> คือการรัน <code>operator()</code> ของมัน เหมือนฟังก์ชันสมาชิกทั่วไป มันได้ <code>this</code> ที่ซ่อนอยู่ ซึ่งชี้ไปที่อ็อบเจกต์แลมบ์ดา'));
      sim.rf(br, 'total'); sim.w(total, sim.r(total) + 3);
      sim.step(at('auto byRef'), L('<code>total += x</code>: follow this → field total → main\'s total, and add 3. main\'s variable really changes.', '<code>total += x</code>: ตาม this → ฟิลด์ total → total ของ main แล้วบวก 3 ตัวแปรของ main เปลี่ยนจริง'));
      sim.ret(undefined, { show: false });
      sim.step(at('byRef(3)'), L('Done: total = 3.', 'เสร็จแล้ว: total = 3'));
      sim.w(step, 50);
      sim.step(at('step = 50'), L('main\'s step becomes 50, but byVal\'s field is a separate copy and stays 5.', 'step ของ main กลายเป็น 50 แต่ฟิลด์ของ byVal เป็นสำเนาแยกจึงยังเป็น 5'));
      sim.call('byVal.operator()(int x)');
      sim.param('this', 'closure*', P(bv)); sim.param('x', 'int', 2);
      const sv = sim.rf(bv, 'step');
      sim.step(at('auto byVal'), L('Inside: <code>x * step</code> reads the lambda\'s own field (5), not main\'s step. 2 × 5 = 10.', 'ข้างใน: <code>x * step</code> อ่านฟิลด์ของแลมบ์ดาเอง (5) ไม่ใช่ step ของ main ได้ 2 × 5 = 10'));
      sim.ret(2 * sv);
      sim.local('r', 'int', 10);
      sim.step(at('int r = byVal'), L('r = 10. A value capture is a snapshot taken when the lambda was created.', 'r = 10 การจับแบบค่าคือภาพถ่ายที่ถ่ายไว้ตอนสร้างแลมบ์ดา'));
      const c = sim.obj('c', 'Counter', [['base', 'int', 100]]);
      sim.step(at('Counter c'), L('A Counter object with base = 100 (from its default member initialiser).', 'อ็อบเจกต์ Counter ที่มี base = 100 (จากค่าเริ่มต้นของสมาชิก)'));
      sim.step(at('int s = c.add(7)'), L('Call <code>c.add(7)</code>.', 'เรียก <code>c.add(7)</code>'));
      sim.call('Counter::add(int k)');
      sim.param('this', 'Counter*', P(c)); const k = sim.param('k', 'int', 7);
      sim.step(at('int add'), L('add\'s frame: this = &c, k = 7.', 'เฟรมของ add: this = &c, k = 7'));
      const f = sim.obj('f', 'lambda [this, k]', [['this', 'Counter*', P(c)], ['k', 'int', sim.r(k)]]);
      sim.step(at('auto f = [this, k]'), L(
        '<code>[this, k]</code> builds a lambda object with two fields: a <b>copy of the pointer</b> this (so it can reach c\'s members) and a copy of k. <code>[this]</code> never copies the object, only its address: if c died before f is called, f would dangle.',
        '<code>[this, k]</code> สร้างอ็อบเจกต์แลมบ์ดาที่มีสองฟิลด์: <b>สำเนาของพอยน์เตอร์</b> this (เพื่อเข้าถึงสมาชิกของ c) และสำเนาของ k ส่วน <code>[this]</code> ไม่ได้คัดลอกอ็อบเจกต์ คัดลอกแค่แอดเดรส ถ้า c ตายก่อนเรียก f แลมบ์ดาจะห้อย'));
      sim.call('f.operator()(int x)');
      sim.param('this', 'closure*', P(f)); sim.param('x', 'int', 1);
      sim.step(at('return f(1)'), L('Call <code>f(1)</code>. Now there are two different "this" pointers on the stack: add\'s points at c, and operator()\'s points at the lambda f.', 'เรียก <code>f(1)</code> ตอนนี้บน stack มีพอยน์เตอร์ "this" สองตัวที่ต่างกัน: ของ add ชี้ไปที่ c และของ operator() ชี้ไปที่แลมบ์ดา f'));
      sim.rf(f, 'this'); const bs = sim.rf(c, 'base'); const kk = sim.rf(f, 'k');
      sim.step(at('auto f = [this, k]'), L('<code>base</code> inside the lambda means <i>captured_this->base</i>: lambda → field this → c.base = 100. Plus k (7) plus x (1) = 108.', '<code>base</code> ในแลมบ์ดาหมายถึง <i>this_ที่จับไว้->base</i>: แลมบ์ดา → ฟิลด์ this → c.base = 100 บวก k (7) บวก x (1) = 108'));
      sim.ret(bs + kk + 1);
      sim.step(at('return f(1)'), L('add returns 108.', 'add คืนค่า 108'));
      sim.ret(108);
      sim.local('s', 'int', 108);
      sim.step(at('int s = c.add(7)'), L('s = 108. The lambda f died with add\'s frame.', 's = 108 แลมบ์ดา f ตายไปพร้อมเฟรมของ add'));
      sim.print('3 10 108\n');
      sim.step(at('cout'), L(
        'Output <code>3 10 108</code>. Cheat sheet: <code>[x]</code> copy now · <code>[&x]</code> store address · <code>[=]</code> copy everything used · <code>[&]</code> reference everything used · <code>[this]</code> copy the object\'s address. A sort comparator like <code>[&](int a, int b){ return score[a] &gt; score[b]; }</code> stores score\'s address.',
        'ผลลัพธ์ <code>3 10 108</code> สรุปย่อ: <code>[x]</code> คัดลอกตอนนี้ · <code>[&x]</code> เก็บแอดเดรส · <code>[=]</code> คัดลอกทุกตัวที่ใช้ · <code>[&]</code> อ้างอิงทุกตัวที่ใช้ · <code>[this]</code> คัดลอกแอดเดรสของอ็อบเจกต์ comparator ของ sort อย่าง <code>[&](int a, int b){ return score[a] &gt; score[b]; }</code> เก็บแอดเดรสของ score'));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();
