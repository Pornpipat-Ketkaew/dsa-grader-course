/* Part II · a hash table with separate chaining (how unordered_map works in principle) */
(() => {
  const CLS = `struct Node {
  int key;
  int val;
  Node* next;
};
class HashMap {
    Node** table;   // array of bucket heads
    int nb;         // number of buckets
    int n;          // number of keys stored
    int bucketOf(int key) { return key % nb; }
  public:
    HashMap() : table(new Node*[4]()), nb(4), n(0) { }
    void insert(int key, int val) {
      int b = bucketOf(key);
      for (Node* p = table[b]; p != NULL; p = p->next)
        if (p->key == key) { p->val = val; return; }
      if (n + 1 > nb) {          // load factor would pass 1
        rehash(nb * 2);
        b = bucketOf(key);
      }
      table[b] = new Node{key, val, table[b]};
      n++;
    }
    int* find(int key) {
      for (Node* p = table[bucketOf(key)]; p != NULL; p = p->next)
        if (p->key == key) return &p->val;
      return NULL;
    }
    void erase(int key) {
      Node** link = &table[bucketOf(key)];
      while (*link != NULL && (*link)->key != key)
        link = &(*link)->next;
      if (*link == NULL) return;
      Node* dead = *link;
      *link = dead->next;
      delete dead;
      n--;
    }
    void rehash(int newNb) {
      Node** old = table;
      int oldNb = nb;
      table = new Node*[newNb]();
      nb = newNb;
      for (int i = 0; i < oldNb; i++) {
        Node* p = old[i];
        while (p != NULL) {
          Node* nx = p->next;
          int b = bucketOf(p->key);
          p->next = table[b];
          table[b] = p;
          p = nx;
        }
      }
      delete[] old;
    }
    ~HashMap() {
      for (int i = 0; i < nb; i++)
        while (table[i] != NULL) { Node* d = table[i]; table[i] = d->next; delete d; }
      delete[] table;
    }
};
int main() {
  HashMap m;
`;
  const parse = str => {
    const ops = parseOps(str, 14).map(o => {
      const n = o[0];
      if (n === 'insert') {
        if (typeof o[1] !== 'number' || o[1] < 0 || o[1] > 999) throw userErr(L('insert needs a key from 0 to 999 (and an optional value).', 'insert ต้องมีคีย์ 0 ถึง 999 (และค่าถ้าต้องการ)'));
        return ['insert', o[1], typeof o[2] === 'number' ? o[2] : o[1] * 10];
      }
      if (n === 'find' || n === 'erase') { if (typeof o[1] !== 'number' || o[1] < 0 || o[1] > 999) throw userErr(L(n + ' needs a key from 0 to 999.', n + ' ต้องมีคีย์ 0 ถึง 999')); return [n, o[1]]; }
      throw userErr(L('Unknown operation "' + n + '". Use insert k [v], find k, erase k.', 'ไม่รู้จักคำสั่ง "' + n + '" ใช้ได้: insert k [v], find k, erase k'));
    });
    if (!ops.length) throw userErr(L('Type at least one operation.', 'ใส่คำสั่งอย่างน้อยหนึ่งคำสั่ง'));
    return ops;
  };
  const line = o => o[0] === 'insert' ? '  m.insert(' + o[1] + ', ' + o[2] + ');'
    : o[0] === 'find' ? '  { int* r = m.find(' + o[1] + '); cout << (r ? *r : -1) << "\\n"; }'
    : '  m.erase(' + o[1] + ');';
  const codeOf = ops => CLS + ops.map(line).join('\n') + '\n}\n';
  const DEF = 'insert 12, insert 7, insert 16, insert 4, find 16, find 3, insert 7 77, insert 9, erase 4';

  def({
    id: 'cp-hash', part: 2, lesson: '09', lessonFile: '09-sorting-hashing-counting.md', dangOK: true,
    title: L('Hash table: buckets, chains and rehash', 'ตารางแฮช: บักเก็ต สายโซ่ และการ rehash'),
    summary: L('This is the idea inside std::unordered_map. A key is turned into a bucket number (here key % nb). Each bucket holds a pointer to a short linked chain of nodes. Two keys that land in the same bucket are a collision and simply share the chain. When the number of keys would pass the number of buckets, the table doubles and every node is re-linked into its new bucket (the nodes themselves never move).',
      'นี่คือหลักการข้างใน std::unordered_map คีย์ถูกแปลงเป็นเลขบักเก็ต (ที่นี่คือ key % nb) แต่ละบักเก็ตเก็บพอยน์เตอร์ไปยังสายโซ่สั้นๆ ของโหนด คีย์สองตัวที่ตกบักเก็ตเดียวกันคือการชนกัน (collision) และแค่ใช้สายโซ่ร่วมกัน เมื่อจำนวนคีย์กำลังจะเกินจำนวนบักเก็ต ตารางจะขยายเป็นสองเท่า และทุกโหนดถูกต่อลิงก์ใหม่เข้าบักเก็ตใหม่ (ตัวโหนดไม่ย้ายที่)'),
    blurb: L('key % nb picks a bucket; collisions share a chain; rehash re-links nodes.', 'key % nb เลือกบักเก็ต คีย์ชนกันใช้สายโซ่ร่วม rehash ต่อลิงก์โหนดใหม่'),
    params: [{ id: 'ops', label: L('Operations', 'คำสั่ง'), value: DEF }],
    paramHint: L('insert k [v] · find k · erase k   (keys 0–999, value defaults to k×10)', 'insert k [v] · find k · erase k   (คีย์ 0–999 ค่าเริ่มต้นคือ k×10)'),
    code: codeOf(parse(DEF)),
    codeFn: p => { try { return codeOf(parse(p.ops)); } catch (e) { return CLS + '}\n'; } },
    build(sim, prm) {
      const ops = parse(prm.ops), code = codeOf(ops), at = LN(code);
      const mainL = at('int main');
      let m = 0;
      const tableOf = () => sim.pf(m, 'table').p, nbOf = () => sim.pf(m, 'nb');
      const fn = x => 'HashMap::' + x;
      const nodeLabel = () => { for (const b of sim.heap) if (b.kind === 'obj') b.label = L('node ' + b.fields[0].value, 'โหนด ' + b.fields[0].value); };
      let focus = null, oldChains = null, moved = new Set();   // {bucket, node, tagB, tagN, cls}

      sim.viewFn = S => {
        if (!m) return null;
        const mo = S.frames[0] && S.frames[0].vars.find(v => v.name === 'm'); if (!mo) return null;
        const tA = mo.fields.find(f => f.name === 'table').value, nb = mo.fields.find(f => f.name === 'nb').value;
        const tb = tA && S.heap.find(b => b.addr === tA.p && !b.freed); if (!tb) return null;
        const node = a => S.heap.find(b => b.addr === a && b.kind === 'obj' && !b.freed);
        const buckets = tb.cells.map((c, i) => {
          const nodes = []; let p = c, g = 0;
          while (p && p.p && g++ < 20) { const nd = node(p.p); if (!nd) break;
            nodes.push({ k: nd.fields[0].value, v: nd.fields[1].value, addr: nd.addr, cls: focus && focus.node === nd.addr ? (focus.cls || 'hl') : (nd.born ? 'ok' : 'hp'), tag: focus && focus.node === nd.addr ? focus.tagN : null });
            p = nd.fields[2].value; }
          return { addr: tA.p + i * 8, nodes, cls: focus && focus.bucket === i ? 'hl' : 'st', tag: focus && focus.bucket === i ? (focus.tagB || 'b') : null };
        });
        // nodes not in any chain (during rehash they live in the old table)
        const old = S.heap.find(b => b.kind === 'array' && b.addr !== tA.p && !b.freed);
        const parts = [{ kind: 'buckets', buckets, foot: L('nb = ' + nb + ' buckets · n = ' + mo.fields.find(f => f.name === 'n').value + ' keys · load factor n/nb = ' + (mo.fields.find(f => f.name === 'n').value / nb).toFixed(2), 'nb = ' + nb + ' บักเก็ต · n = ' + mo.fields.find(f => f.name === 'n').value + ' คีย์ · load factor n/nb = ' + (mo.fields.find(f => f.name === 'n').value / nb).toFixed(2)) }];
        if (old && oldChains) {
          const ob = oldChains.map((ch, i) => ({ addr: old.addr + i * 8, cls: 'dim', tag: focus && focus.oldB === i ? 'i' : null,
            nodes: ch.filter(a => !moved.has(a) && node(a)).map(a => { const nd = node(a); return { k: nd.fields[0].value, v: nd.fields[1].value, addr: a, cls: focus && focus.node === a ? 'hl' : 'dim', tag: focus && focus.node === a ? focus.tagN : null }; }) }));
          parts[0].cap = L('NEW table (' + nb + ' buckets)', 'ตารางใหม่ (' + nb + ' บักเก็ต)');
          parts.push({ kind: 'buckets', buckets: ob, cap: L('OLD table: nodes not moved yet (in memory old[i] still holds its old pointer; it is simply never used again)', 'ตารางเก่า: โหนดที่ยังไม่ถูกย้าย (ในหน่วยความจำ old[i] ยังเก็บพอยน์เตอร์เดิม แค่จะไม่ถูกใช้อีก)') });
          return { kind: 'multi', title: L('rehash in progress', 'กำลัง rehash'), parts };
        }
        return Object.assign(parts[0], { title: L('buckets and their chains', 'บักเก็ตและสายโซ่'), cap: L('Each row is one bucket: a slot of the table array holding a Node*. Arrows are next pointers. b marks the bucket being used; p marks the node being looked at.', 'แต่ละแถวคือหนึ่งบักเก็ต: ช่องหนึ่งของอาเรย์ table ที่เก็บ Node* ลูกศรคือพอยน์เตอร์ next b คือบักเก็ตที่กำลังใช้ p คือโหนดที่กำลังดู') });
      };
      sim.tagFn = S => {
        const tags = [];
        const top = S.frames[S.frames.length - 1];
        if (top) for (const nm of ['p', 'dead', 'nx']) { const v = top.vars.find(x => x.name === nm); if (v && isP(v.value) && v.value.p) tags.push(TAG(v.value.p, nm, 'ptr')); }
        return tags;
      };

      sim.call('main()');
      sim.step(mainL, L('main starts.', 'main เริ่มทำงาน'));
      m = sim.obj('m', 'HashMap', [['table', 'Node**', undefined], ['nb', 'int', undefined], ['n', 'int', undefined]]);
      sim.call(fn('HashMap()')); sim.param('this', 'HashMap*', P(m));
      const T0 = sim.newArray('Node*', 4, P(0), { label: L('table (bucket heads)', 'table (หัวบักเก็ต)'), expr: 'new Node*[4]()' });
      sim.wf(m, 'table', P(T0)); sim.wf(m, 'nb', 4); sim.wf(m, 'n', 0);
      sim.step(at('HashMap() :'), L(
        'The constructor allocates the <b>bucket array</b>: 4 pointers of 8 bytes, all NULL thanks to the <code>()</code> at the end of <code>new Node*[4]()</code>. Every bucket starts as an empty chain. The object m itself only holds the array\'s address and two counters.',
        'คอนสตรักเตอร์จอง<b>อาเรย์บักเก็ต</b>: พอยน์เตอร์ 4 ตัว ตัวละ 8 ไบต์ ทุกตัวเป็น NULL เพราะมี <code>()</code> ท้าย <code>new Node*[4]()</code> ทุกบักเก็ตเริ่มเป็นสายโซ่ว่าง ตัว m เองเก็บแค่แอดเดรสของอาเรย์กับตัวนับสองตัว'));
      sim.ret(undefined, { show: false });

      const bucketOf = (key, lineSub) => {
        const nb = sim.rf(m, 'nb');
        return key % nb;
      };
      const walk = (b, key, lineSub, onFound) => {
        // for (Node* p = table[b]; p != NULL; p = p->next) if (p->key == key) ...
        const T = sim.rf(m, 'table').p;
        let p = sim.r(T + b * 8).p;
        sim.local('p', 'Node*', P(p));
        if (!p) { sim.step(at(lineSub), L('p = table[' + b + '] = NULL: bucket ' + b + ' is empty, so the loop does not run at all.', 'p = table[' + b + '] = NULL: บักเก็ต ' + b + ' ว่าง ลูปจึงไม่ทำงานเลย')); return null; }
        let g = 0;
        while (p && g++ < 30) {
          focus = { bucket: b, node: p, tagN: 'p' };
          const k = sim.rf(p, 'key');
          if (k === key) { const r = onFound(p); return r == null ? p : r; }
          sim.step(at(lineSub) + 1, L('p->key = ' + k + ' ≠ ' + key + ' (a collision: different key, same bucket). Follow p->next.', 'p->key = ' + k + ' ≠ ' + key + ' (ชนกัน: คีย์ต่างกันแต่บักเก็ตเดียวกัน) ตามไปที่ p->next'));
          p = sim.rf(p, 'next').p; sim.w(findVar(sim, 'p').addr, P(p));
          if (!p) { focus = { bucket: b }; sim.step(at(lineSub), L('p = NULL: end of the chain. Key ' + key + ' is not in the table.', 'p = NULL: สุดสายโซ่ คีย์ ' + key + ' ไม่อยู่ในตาราง')); }
        }
        return null;
      };

      const rehash = newNb => {
        sim.call(fn('rehash(int newNb)')); sim.param('this', 'HashMap*', P(m)); sim.param('newNb', 'int', newNb);
        const old = sim.rf(m, 'table').p; sim.local('old', 'Node**', P(old));
        const oldNb = sim.rf(m, 'nb'); sim.local('oldNb', 'int', oldNb);
        focus = null;
        sim.step(at('Node** old = table'), L('rehash(' + newNb + '): keep the old array in <code>old</code> (' + hex(old) + ') and its size.', 'rehash(' + newNb + '): เก็บอาเรย์เก่าไว้ใน <code>old</code> (' + hex(old) + ') พร้อมขนาดของมัน'));
        const NT = sim.newArray('Node*', newNb, P(0), { label: L('new table', 'table ใหม่'), expr: 'new Node*[' + newNb + ']()' });
        sim.setLabel(old, L('old table', 'table เก่า'));
        sim.wf(m, 'table', P(NT));
        sim.step(at('table = new Node*[newNb]()'), L('A new, bigger bucket array (' + newNb + ' NULL pointers) at ' + hex(NT) + '. m.table now points to it. All nodes are still hanging off the <b>old</b> array.', 'อาเรย์บักเก็ตใหม่ที่ใหญ่กว่า (NULL ' + newNb + ' ตัว) ที่ ' + hex(NT) + ' ตอนนี้ m.table ชี้ไปที่มัน โหนดทั้งหมดยังห้อยอยู่กับอาเรย์<b>เก่า</b>'));
        sim.wf(m, 'nb', newNb);
        sim.step(at('nb = newNb;'), L('nb = ' + newNb + '. From now on bucketOf uses <code>key % ' + newNb + '</code>, so most keys get a different bucket number.', 'nb = ' + newNb + ' ต่อจากนี้ bucketOf ใช้ <code>key % ' + newNb + '</code> คีย์ส่วนใหญ่จึงได้เลขบักเก็ตใหม่'));
        const iA = sim.local('i', 'int', 0);
        const loc = (nm, ty, v) => { const e = sim.top().vars.find(x => x.name === nm); if (e) { sim.w(e.addr, v); return e.addr; } return sim.local(nm, ty, v); };
        oldChains = []; moved = new Set();
        for (let i = 0; i < oldNb; i++) { const ch = []; let q = sim.peek(old + i * 8).p; while (q) { ch.push(q); q = sim.pf(q, 'next').p; } oldChains.push(ch); }
        for (let i = 0; i < oldNb; i++) {
          sim.w(iA, i);
          let p = sim.r(old + i * 8).p;
          const pA = loc('p', 'Node*', P(p));
          focus = { oldB: i, node: p };
          if (!p) { sim.step(at('Node* p = old[i]'), L('old bucket ' + i + ' is empty. Nothing to move.', 'บักเก็ตเก่า ' + i + ' ว่าง ไม่มีอะไรต้องย้าย')); continue; }
          sim.step(at('Node* p = old[i]'), L('Old bucket ' + i + ': start at its first node (key ' + sim.pf(p, 'key') + ').', 'บักเก็ตเก่า ' + i + ': เริ่มที่โหนดแรก (คีย์ ' + sim.pf(p, 'key') + ')'));
          let g = 0;
          while (p && g++ < 30) {
            const nx = sim.rf(p, 'next').p;
            loc('nx', 'Node*', P(nx));
            const key = sim.rf(p, 'key'), b = key % newNb;
            loc('b', 'int', b);
            focus = { oldB: i, node: p, tagN: 'p', bucket: b, tagB: 'b' };
            sim.step(at('int b = bucketOf(p->key)'), L('Save nx = p->next first (we are about to overwrite p->next). Key ' + key + ' % ' + newNb + ' = <b>' + b + '</b>: its new bucket.', 'เก็บ nx = p->next ไว้ก่อน (เรากำลังจะเขียนทับ p->next) คีย์ ' + key + ' % ' + newNb + ' = <b>' + b + '</b>: บักเก็ตใหม่ของมัน'), { lines: [at('Node* nx = p->next')] });
            sim.wf(p, 'next', sim.r(NT + b * 8));
            sim.w(NT + b * 8, P(p));
            moved.add(p);
            focus = { oldB: i, node: p, tagN: 'p', bucket: b, tagB: 'b', cls: 'chg' };
            sim.step(at('table[b] = p;'), L('Two pointer writes push node ' + key + ' onto the <b>front</b> of new bucket ' + b + ': <code>p->next = table[b]</code>, then <code>table[b] = p</code>. The node stays at ' + hex(p) + '; only arrows change. No new, no copy.', 'เขียนพอยน์เตอร์สองครั้งเพื่อดันโหนด ' + key + ' ไปไว้<b>หน้าสุด</b>ของบักเก็ตใหม่ ' + b + ': <code>p->next = table[b]</code> แล้ว <code>table[b] = p</code> โหนดยังอยู่ที่ ' + hex(p) + ' เดิม เปลี่ยนแค่ลูกศร ไม่มี new ไม่มีการคัดลอก'), { lines: [at('p->next = table[b];')] });
            p = nx; sim.w(pA, P(p));
          }
        }
        focus = null; oldChains = null;
        sim.free(old);
        sim.step(at('delete[] old;'), L('Every node has been re-linked, so the old bucket array is freed with <code>delete[]</code>. The nodes were never copied: rehash costs O(n + nb) pointer work.', 'ทุกโหนดถูกต่อลิงก์ใหม่แล้ว อาเรย์บักเก็ตเก่าจึงถูกคืนด้วย <code>delete[]</code> โหนดไม่เคยถูกคัดลอกเลย rehash ใช้งานพอยน์เตอร์ O(n + nb)'));
        sim.ret(undefined, { show: false });
      };

      ops.forEach((o, k) => {
        const L0 = mainL + 2 + k;
        focus = null;
        if (o[0] === 'insert') {
          const [_, key, val] = o;
          sim.step(L0, L('<code>m.insert(' + key + ', ' + val + ')</code>.', '<code>m.insert(' + key + ', ' + val + ')</code>'));
          sim.call(fn('insert(int key, int val)')); sim.param('this', 'HashMap*', P(m)); sim.param('key', 'int', key); sim.param('val', 'int', val);
          const nb = sim.rf(m, 'nb'); const b = key % nb;
          const bA = sim.local('b', 'int', b);
          focus = { bucket: b };
          sim.step(at('int b = bucketOf(key);'), L('bucketOf(' + key + ') = ' + key + ' % ' + nb + ' = <b>' + b + '</b>. This is the "hash": it jumps straight to one bucket without looking at the others. That is why lookups are O(1) on average.', 'bucketOf(' + key + ') = ' + key + ' % ' + nb + ' = <b>' + b + '</b> นี่คือ "แฮช": กระโดดตรงไปที่บักเก็ตเดียวโดยไม่ดูบักเก็ตอื่นเลย นี่คือเหตุผลที่การค้นหาเฉลี่ย O(1)'));
          let updated = false;
          walk(b, key, 'for (Node* p = table[b]', p => {
            sim.wf(p, 'val', val); updated = true;
            focus = { bucket: b, node: p, tagN: 'p', cls: 'chg' };
            sim.step(at('if (p->key == key) { p->val'), L('Key ' + key + ' is already here, so insert only <b>updates</b> its value to ' + val + ' and returns. Keys in a map are unique.', 'คีย์ ' + key + ' มีอยู่แล้ว insert จึงแค่<b>อัปเดต</b>ค่าเป็น ' + val + ' แล้วคืนกลับ คีย์ใน map ไม่ซ้ำกัน'));
          });
          if (updated) { focus = null; sim.ret(undefined, { show: false }); return; }
          sim.drop('p');
          const n = sim.rf(m, 'n');
          if (n + 1 > nb) {
            focus = null;
            sim.step(at('if (n + 1 > nb)'), L('n + 1 = ' + (n + 1) + ' > nb = ' + nb + ': adding this key would make the load factor (keys per bucket) bigger than 1. Chains would get long and lookups slow, so <b>grow first</b>.', 'n + 1 = ' + (n + 1) + ' > nb = ' + nb + ': ถ้าเพิ่มคีย์นี้ load factor (คีย์ต่อบักเก็ต) จะเกิน 1 สายโซ่จะยาวและค้นหาช้า จึง<b>ขยายก่อน</b>'), { cls: 'warn' });
            rehash(nb * 2);
            const b2 = key % (nb * 2); sim.w(bA, b2);
            focus = { bucket: b2 };
            sim.step(at('b = bucketOf(key);'), L('Recompute the bucket with the new size: ' + key + ' % ' + (nb * 2) + ' = <b>' + b2 + '</b>.', 'คำนวณบักเก็ตใหม่ด้วยขนาดใหม่: ' + key + ' % ' + (nb * 2) + ' = <b>' + b2 + '</b>'));
          } else {
            sim.step(at('if (n + 1 > nb)'), L('n + 1 = ' + (n + 1) + ' ≤ nb = ' + nb + ': there is room, no rehash.', 'n + 1 = ' + (n + 1) + ' ≤ nb = ' + nb + ': ยังมีที่ ไม่ต้อง rehash'));
          }
          const bb = sim.r(bA), T = sim.rf(m, 'table').p;
          const head = sim.r(T + bb * 8);
          const nd = sim.newObj('Node', [['key', 'int', key], ['val', 'int', val], ['next', 'Node*', head]], { expr: 'new Node{' + key + ', ' + val + ', table[b]}' });
          nodeLabel();
          focus = { bucket: bb, node: nd, tagN: 'new', cls: 'ok' };
          sim.step(at('table[b] = new Node'), L('<code>new Node{...}</code> makes a 16-byte node (key, val, next) at ' + hex(nd) + '. Its next is the old head of bucket ' + bb + (head.p ? ' (' + hex(head.p) + '), so the existing chain hangs behind it' : ' (NULL)') + '.', '<code>new Node{...}</code> สร้างโหนด 16 ไบต์ (key, val, next) ที่ ' + hex(nd) + ' next ของมันคือหัวเดิมของบักเก็ต ' + bb + (head.p ? ' (' + hex(head.p) + ') สายโซ่เดิมจึงต่อท้ายมัน' : ' (NULL)')));
          sim.w(T + bb * 8, P(nd));
          sim.step(at('table[b] = new Node'), L('… and <code>table[' + bb + ']</code> now points to the new node: it is the new head. Inserting at the front is O(1); no need to walk to the end.', '… และ <code>table[' + bb + ']</code> ตอนนี้ชี้ไปที่โหนดใหม่ มันคือหัวใหม่ การแทรกที่หน้าสุดเป็น O(1) ไม่ต้องเดินไปท้ายสาย'));
          sim.wf(m, 'n', sim.rf(m, 'n') + 1);
          focus = null;
          sim.step(at('n++;'), L('n = ' + sim.pf(m, 'n') + '.', 'n = ' + sim.pf(m, 'n')));
          sim.ret(undefined, { show: false });
        } else if (o[0] === 'find') {
          const key = o[1];
          sim.step(L0, L('<code>m.find(' + key + ')</code> returns a pointer to the value, or NULL.', '<code>m.find(' + key + ')</code> คืนพอยน์เตอร์ไปยังค่า หรือ NULL'));
          sim.call(fn('find(int key)')); sim.param('this', 'HashMap*', P(m)); sim.param('key', 'int', key);
          const nb = sim.rf(m, 'nb'); const b = key % nb;
          focus = { bucket: b };
          let res = null;
          walk(b, key, 'for (Node* p = table[bucketOf(key)]', p => {
            res = p;
            focus = { bucket: b, node: p, tagN: 'p', cls: 'ok' };
            sim.step(at('if (p->key == key) return &p->val;'), L('bucket ' + key + ' % ' + nb + ' = ' + b + ', and p->key = ' + key + ': found. Return <code>&p->val</code> = ' + hex(sim.f(p, 'val')) + ', the address of the val field inside the node.', 'บักเก็ต ' + key + ' % ' + nb + ' = ' + b + ' และ p->key = ' + key + ': เจอแล้ว คืน <code>&p->val</code> = ' + hex(sim.f(p, 'val')) + ' คือแอดเดรสของฟิลด์ val ในโหนด'));
          });
          if (!res) sim.step(at('return NULL;'), L('Not found: return NULL. Only bucket ' + b + ' was searched.', 'ไม่เจอ: คืน NULL ค้นแค่บักเก็ต ' + b + ' เท่านั้น'));
          focus = null;
          sim.ret(res ? P(sim.f(res, 'val')) : P(0), { type: 'int*' });
          const r = sim.local('r', 'int*', res ? P(sim.f(res, 'val')) : P(0));
          const v = res ? sim.r(sim.f(res, 'val')) : -1;
          sim.print(v + '\n');
          sim.step(L0, res ? L('r points into the node. <code>*r</code> reads ' + v + ' and prints it.', 'r ชี้เข้าไปในโหนด <code>*r</code> อ่านได้ ' + v + ' แล้วพิมพ์ออก') : L('r is NULL, so the program prints -1.', 'r เป็น NULL โปรแกรมจึงพิมพ์ -1'));
          sim.drop('r');
        } else {
          const key = o[1];
          sim.step(L0, L('<code>m.erase(' + key + ')</code>.', '<code>m.erase(' + key + ')</code>'));
          sim.call(fn('erase(int key)')); sim.param('this', 'HashMap*', P(m)); sim.param('key', 'int', key);
          const nb = sim.rf(m, 'nb'); const b = key % nb; const T = sim.rf(m, 'table').p;
          const lkA = sim.local('link', 'Node**', P(T + b * 8));
          focus = { bucket: b };
          sim.step(at('Node** link = &table'), L('<code>link</code> is a <b>pointer to a pointer</b>: it holds the address of the slot table[' + b + '] (' + hex(T + b * 8) + '), not a node. Whatever link points at is the arrow we may need to rewrite.', '<code>link</code> คือ<b>พอยน์เตอร์ไปยังพอยน์เตอร์</b>: เก็บแอดเดรสของช่อง table[' + b + '] (' + hex(T + b * 8) + ') ไม่ใช่โหนด สิ่งที่ link ชี้อยู่คือลูกศรที่เราอาจต้องเขียนใหม่'));
          let g = 0, cur = sim.r(T + b * 8).p;
          while (cur && sim.pf(cur, 'key') !== key && g++ < 30) {
            sim.rf(cur, 'key');
            focus = { bucket: b, node: cur, tagN: '*link' };
            sim.step(at('while (*link != NULL'), L('*link = ' + hex(cur) + ', key ' + sim.pf(cur, 'key') + ' ≠ ' + key + '. Keep going.', '*link = ' + hex(cur) + ' คีย์ ' + sim.pf(cur, 'key') + ' ≠ ' + key + ' ไปต่อ'));
            sim.w(lkA, P(sim.f(cur, 'next')));
            sim.step(at('link = &(*link)->next;'), L('link = &(' + hex(cur) + ')->next = ' + hex(sim.f(cur, 'next')) + ': link now points at the <b>next field</b> inside that node.', 'link = &(' + hex(cur) + ')->next = ' + hex(sim.f(cur, 'next')) + ': ตอนนี้ link ชี้ไปที่<b>ฟิลด์ next</b> ในโหนดนั้น'));
            cur = sim.r(sim.f(cur, 'next')).p;
          }
          if (!cur) {
            focus = { bucket: b };
            sim.step(at('if (*link == NULL) return;'), L('*link is NULL: key ' + key + ' is not here. Nothing to erase.', '*link เป็น NULL: ไม่มีคีย์ ' + key + ' ไม่มีอะไรให้ลบ'));
          } else {
            sim.rf(cur, 'key');
            focus = { bucket: b, node: cur, tagN: '*link', cls: 'bad' };
            sim.step(at('while (*link != NULL'), L('*link points to the node with key ' + key + '. Stop.', '*link ชี้ไปยังโหนดที่มีคีย์ ' + key + ' หยุด'));
            sim.local('dead', 'Node*', P(cur));
            sim.step(at('Node* dead = *link;'), L('Remember the node as <code>dead</code>.', 'จำโหนดไว้ใน <code>dead</code>'));
            const lk = sim.r(lkA).p;
            sim.w(lk, sim.rf(cur, 'next'));
            focus = { bucket: b, node: cur, tagN: 'dead', cls: 'bad' };
            sim.step(at('*link = dead->next;'), L('<code>*link = dead->next</code> rewrites the arrow at ' + hex(lk) + ' to skip over the dead node. Because link pointed at the arrow itself, the same line works whether that arrow is a bucket head or a next field: no special case for the first node.', '<code>*link = dead->next</code> เขียนลูกศรที่ ' + hex(lk) + ' ใหม่ให้ข้ามโหนด dead ไป เพราะ link ชี้ไปที่ตัวลูกศรเอง บรรทัดเดียวกันใช้ได้ไม่ว่าลูกศรนั้นจะเป็นหัวบักเก็ตหรือฟิลด์ next ไม่ต้องมีกรณีพิเศษสำหรับโหนดแรก'));
            sim.free(cur);
            focus = null;
            sim.step(at('delete dead;'), L('<code>delete dead</code> frees the 16-byte node. (dead is now a dangling pointer; it dies with the frame.)', '<code>delete dead</code> คืนโหนด 16 ไบต์ (dead กลายเป็นพอยน์เตอร์ห้อย และหายไปพร้อมเฟรม)'));
            sim.wf(m, 'n', sim.rf(m, 'n') - 1);
            sim.step(at('n--;'), L('n = ' + sim.pf(m, 'n') + '.', 'n = ' + sim.pf(m, 'n')));
          }
          focus = null;
          sim.ret(undefined, { show: false });
        }
      });
      // destructor
      focus = null;
      sim.step(mainL + 2 + ops.length, L('main ends, so m\'s destructor runs.', 'main จบ destructor ของ m จึงทำงาน'));
      sim.call(fn('~HashMap()')); sim.param('this', 'HashMap*', P(m));
      const T = sim.pf(m, 'table').p, nb = sim.pf(m, 'nb');
      for (let i = 0; i < nb; i++) { let p = sim.peek(T + i * 8).p; while (p) { const nx = sim.pf(p, 'next').p; sim.free(p); p = nx; } sim.w(T + i * 8, P(0)); }
      sim.step(at('while (table[i] != NULL)'), L('The destructor walks every bucket and deletes every node in its chain.', 'destructor เดินทุกบักเก็ตและลบทุกโหนดในสายโซ่'));
      sim.free(T);
      sim.step(at('delete[] table;'), L('Finally the bucket array itself. No leaks.', 'สุดท้ายคืนอาเรย์บักเก็ตเอง ไม่มีหน่วยความจำรั่ว'));
      sim.ret(undefined, { show: false });
    }
  });
})();
