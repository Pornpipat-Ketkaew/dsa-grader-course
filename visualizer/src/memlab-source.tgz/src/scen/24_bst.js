/* Part II · CP::map_bst (real code from map_bst.h) */
(() => {
  const CLS = `namespace CP {
template <typename KeyT, typename MappedT,
          typename CompareT = std::less<KeyT> >
class map_bst {
  protected:
    typedef std::pair<KeyT,MappedT> ValueT;
    class node {
      public:
        ValueT data;
        node  *left;
        node  *right;
        node  *parent;
        node(const ValueT& data, node* left, node* right, node* parent) :
          data ( data ), left( left ), right( right ), parent( parent ) { }
    };
    node     *mRoot;
    CompareT  mLess;
    size_t    mSize;

    node* &child_link(node* parent, const KeyT& k) {
      if (parent == NULL) return mRoot;
      return mLess(k, parent->data.first) ?
             parent->left : parent->right;
    }
    node* find_node(const KeyT& k,node* r, node* &parent) {
      node *ptr = r;
      while (ptr != NULL) {
        int cmp = compare(k, ptr->data.first);
        if (cmp == 0) return ptr;
        parent = ptr;
        ptr = cmp < 0 ? ptr->left : ptr->right;
      }
      return NULL;
    }
    node* find_min_node(node* r) {
      node *min = r;
      while (min->left != NULL) min = min->left;
      return min;
    }
  public:
    map_bst() : mRoot(NULL), mSize(0) { }

    std::pair<iterator,bool> insert(const ValueT& val) {
      node *parent = NULL;
      node *ptr = find_node(val.first,mRoot,parent);
      bool not_found = (ptr==NULL);
      if (not_found) {
        ptr = new node(val,NULL,NULL,parent);
        child_link(parent, val.first) = ptr;
        mSize++;
      }
      return std::make_pair(iterator(ptr), not_found);
    }
    iterator find(const KeyT &key) {
      node *parent;
      node *ptr = find_node(key,mRoot,parent);
      return ptr == NULL ? end() : iterator(ptr);
    }
    size_t erase(const KeyT &key) {
      if (mRoot == NULL) return 0;
      node *parent = NULL;
      node *ptr = find_node(key,mRoot,parent);
      if (ptr == NULL) return 0;
      if (ptr->left != NULL && ptr->right != NULL) {
        node *min = find_min_node(ptr->right);
        node * &link = child_link(min->parent, min->data.first);
        link = (min->left == NULL) ? min->right : min->left;
        if (link != NULL) link->parent = min->parent;
        std::swap(ptr->data.first, min->data.first);
        std::swap(ptr->data.second, min->data.second);
        ptr = min;
      } else {
        node * &link = child_link(ptr->parent, key);
        link = (ptr->left == NULL) ? ptr->right : ptr->left;
        if (link != NULL) link->parent = ptr->parent;
      }
      delete ptr;
      mSize--;
      return 1;
    }
};
}
int main() {
  CP::map_bst<int,int> m;
`;
  const parse = str => {
    const ops = parseOps(str, 16).map(o => {
      if (['insert', 'find', 'erase'].includes(o[0])) { if (typeof o[1] !== 'number') throw userErr(L(o[0] + ' needs a key.', o[0] + ' ต้องมี key')); return [o[0], o[1]]; }
      throw userErr(L('Unknown operation "' + o[0] + '". Use insert k, find k, erase k.', 'ไม่รู้จักคำสั่ง "' + o[0] + '" ใช้ได้: insert k, find k, erase k'));
    });
    if (!ops.length) throw userErr(L('Type at least one operation.', 'ใส่คำสั่งอย่างน้อยหนึ่งคำสั่ง'));
    return ops;
  };
  const line = o => o[0] === 'insert' ? '  m.insert({' + o[1] + ', ' + (o[1] * 10) + '});' : o[0] === 'find' ? '  cout << (m.find(' + o[1] + ') != m.end()) << "\\n";' : '  m.erase(' + o[1] + ');';
  const codeOf = ops => CLS + ops.map(line).join('\n') + '\n}\n';
  const DEF = 'insert 50, insert 30, insert 70, insert 20, insert 40, insert 60, insert 80, insert 35, find 40, erase 20, erase 30, erase 50';
  def({
    id: 'cp-bst', part: 2, lesson: '07', lessonFile: '07-trees-bst.md', dangOK: true,
    title: L('CP::map_bst: a binary search tree of nodes', 'CP::map_bst: ต้นไม้ค้นหาแบบทวิภาคจากโหนด'),
    summary: L('Each key lives in its own heap node with left, right and parent pointers. find_node walks down comparing keys; insert hangs a new node on the right link using child_link, which returns a reference to a pointer; erase handles the 0/1-child case and the two-children case (swap with the successor).',
      'key แต่ละตัวอยู่ในโหนดของตัวเองบน heap พร้อมพอยน์เตอร์ left, right และ parent find_node เดินลงไปโดยเปรียบเทียบ key insert แขวนโหนดใหม่ไว้ที่ลิงก์ที่ถูกต้องผ่าน child_link ซึ่งคืน reference ไปยังพอยน์เตอร์ ส่วน erase จัดการกรณีลูก 0/1 ตัว และกรณีลูกสองตัว (สลับกับ successor)'),
    blurb: L('find_node, child_link (node*&), insert, erase with the successor.', 'find_node, child_link (node*&), insert และ erase ด้วย successor'),
    params: [{ id: 'ops', label: L('Operations', 'คำสั่ง'), value: DEF }],
    paramHint: L('insert k · find k · erase k   (the mapped value is k × 10)', 'insert k · find k · erase k   (ค่าที่ผูกคือ k × 10)'),
    code: codeOf(parse(DEF)),
    codeFn: p => { try { return codeOf(parse(p.ops)); } catch (e) { return CLS + '}\n'; } },
    build(sim, prm) {
      const ops = parse(prm.ops), code = codeOf(ops), at = LN(code);
      const mainL = at('int main');
      let m;
      const fn = x => 'map_bst<int,int>::' + x;
      const NF = (a, f) => sim.pf(a, f);
      const key = a => NF(a, 'data.first');
      const root = () => sim.pf(m, 'mRoot').p;
      const relabel = () => { for (const b of sim.heap) if (b.kind === 'obj') b.label = L('node ' + fmtPlain(b.fields[0].value), 'โหนด ' + fmtPlain(b.fields[0].value)); };
      sim.viewFn = S => {
        if (!m) return null;
        const r = S.pf(m, 'mRoot'); if (!isP(r)) return null;
        const live = new Map(S.heap.filter(b => b.kind === 'obj' && !b.freed).map(b => [b.addr, b]));
        const fv = (b, f) => b.fields.find(x => x.name === f).value;
        const top = S.top(); const loc = nm => { for (let k = S.frames.length - 1; k >= 0; k--) { const v = S.frames[k].vars.find(x => x.name === nm); if (v) return v.value; } };
        const ptr = loc('ptr'), par = loc('parent'), mn = loc('min');
        const nodes = {};
        const walk = (a, depth) => {
          if (!a || !live.has(a) || nodes[a] || depth > 40) return;
          const b = live.get(a);
          const l = fv(b, 'left').p, rr = fv(b, 'right').p;
          let cls = '', tag = '';
          if (isP(ptr) && ptr.p === a) { cls = 'hl'; tag = 'ptr'; }
          if (isP(par) && par.p === a) { cls = cls || 'cmp'; tag = tag ? tag + ',parent' : 'parent'; }
          if (isP(mn) && mn.p === a) { cls = 'chg'; tag = tag ? tag + ',min' : 'min'; }
          nodes[a] = { label: fmtPlain(fv(b, 'data.first')), sub: hex(a), cls, tag, kids: [l && live.has(l) ? l : null, rr && live.has(rr) ? rr : null] };
          walk(l, depth + 1); walk(rr, depth + 1);
        };
        walk(r.p, 0);
        return { kind: 'tree', binary: true, root: r.p && nodes[r.p] ? r.p : null, nodes, title: L('the tree', 'ต้นไม้'), cap: L('Left subtree keys &lt; node &lt; right subtree keys. Teal = ptr, violet = parent, yellow = min (the successor).', 'key ในต้นไม้ย่อยซ้าย &lt; โหนด &lt; key ในต้นไม้ย่อยขวา ฟ้าอมเขียว = ptr ม่วง = parent เหลือง = min (successor)'), empty: L('(empty tree: mRoot == NULL)', '(ต้นไม้ว่าง: mRoot == NULL)') };
      };
      sim.call('main()');
      sim.step(mainL, L('main starts.', 'main เริ่มทำงาน'));
      m = sim.obj('m', 'CP::map_bst<int,int>', [['mRoot', 'node*', P(0)], ['mLess', 'char', '{}'], ['mSize', 'size_t', 0]]);
      sim.step(mainL + 1, L('An empty map: mRoot = NULL and mSize = 0. Unlike vector and list, an empty BST allocates nothing at all.', 'map ว่าง: mRoot = NULL และ mSize = 0 ต่างจาก vector และ list ตรงที่ BST ว่างไม่จองอะไรเลย'));

      // find_node: returns node addr or 0; parentRef = address of caller's parent variable
      const findNode = (k, parentRef) => {
        sim.call(fn('find_node(const KeyT& k, node* r, node*& parent)'));
        sim.param('this', 'map_bst*', P(m)); sim.param('k', 'int', k); sim.param('r', 'node*', P(root()));
        sim.ref('parent', 'node*', parentRef, { param: true });
        const ptrA = sim.local('ptr', 'node*', P(root()));
        sim.step(at('node *ptr = r;'), L('Start the search at the root (' + (root() ? hex(root()) : 'NULL') + ').', 'เริ่มค้นที่ราก (' + (root() ? hex(root()) : 'NULL') + ')'));
        let p = root();
        while (p) {
          const kk = sim.r(sim.f(p, 'data.first'));
          const cmp = k < kk ? -1 : k > kk ? 1 : 0;
          if (cmp === 0) {
            sim.step(at('if (cmp == 0) return ptr'), L('compare(' + k + ', ' + kk + ') = 0: <b>found</b> it at ' + hex(p) + '.', 'compare(' + k + ', ' + kk + ') = 0: <b>เจอแล้ว</b>ที่ ' + hex(p)));
            sim.ret(P(p), { type: 'node*', show: false });
            return p;
          }
          sim.w(parentRef, P(p));
          sim.step(at('parent = ptr;'), L('compare(' + k + ', ' + kk + ') = ' + cmp + ' (' + k + (cmp < 0 ? ' &lt; ' : ' &gt; ') + kk + '). Remember this node as <code>parent</code>; since parent is a <b>reference</b>, this writes the caller\'s variable.', 'compare(' + k + ', ' + kk + ') = ' + cmp + ' (' + k + (cmp < 0 ? ' &lt; ' : ' &gt; ') + kk + ') จำโหนดนี้ไว้เป็น <code>parent</code> เนื่องจาก parent เป็น <b>reference</b> จึงเขียนลงตัวแปรของผู้เรียกโดยตรง'));
          const nx = sim.r(sim.f(p, cmp < 0 ? 'left' : 'right')).p;
          sim.w(ptrA, P(nx)); p = nx;
          sim.step(at('ptr = cmp < 0 ?'), L('Go ' + (cmp < 0 ? '<b>left</b>' : '<b>right</b>') + ': ptr = ' + (nx ? hex(nx) : 'NULL') + '.', 'ไปทาง' + (cmp < 0 ? '<b>ซ้าย</b>' : '<b>ขวา</b>') + ': ptr = ' + (nx ? hex(nx) : 'NULL')));
        }
        sim.step(at('return NULL;'), L('ptr is NULL: ' + k + ' is not in the tree. <code>parent</code> is now the node under which ' + k + ' would hang.', 'ptr เป็น NULL: ไม่มี ' + k + ' ในต้นไม้ ตอนนี้ <code>parent</code> คือโหนดที่ ' + k + ' จะถูกแขวนไว้ใต้มัน'));
        sim.ret(P(0), { type: 'node*', show: false });
        return 0;
      };
      // child_link(parent, k): returns address of the pointer field to write
      const childLink = (par, k, why) => {
        sim.call(fn('child_link(node* parent, const KeyT& k)'));
        sim.param('this', 'map_bst*', P(m)); sim.param('parent', 'node*', P(par)); sim.param('k', 'int', k);
        let target, desc;
        if (!par) { target = sim.f(m, 'mRoot'); desc = 'mRoot'; sim.step(at('if (parent == NULL) return mRoot'), L('parent is NULL, so the link to change is <b>mRoot itself</b>. child_link returns <code>node*&</code>: a reference to the pointer variable, not a copy of it.', 'parent เป็น NULL ลิงก์ที่ต้องเปลี่ยนคือ <b>mRoot เอง</b> child_link คืน <code>node*&</code>: reference ไปยังตัวแปรพอยน์เตอร์ ไม่ใช่สำเนา')); }
        else {
          const pk = sim.r(sim.f(par, 'data.first'));
          const left = k < pk;
          target = sim.f(par, left ? 'left' : 'right'); desc = 'node ' + pk + '->' + (left ? 'left' : 'right');
          sim.step(at('return mLess(k, parent->data.first)'), L('mLess(' + k + ', ' + pk + ') = ' + left + ', so return a reference to <b>' + desc + '</b> (the field at ' + hex(target) + '). ' + (why || ''), 'mLess(' + k + ', ' + pk + ') = ' + left + ' จึงคืน reference ไปยัง <b>' + desc + '</b> (ฟิลด์ที่ ' + hex(target) + ') ' + (why || '')));
        }
        sim.ret(P(target), { type: 'node*&', show: false });
        return { target, desc };
      };

      ops.forEach((o, k) => {
        const L0 = mainL + 2 + k;
        const K = o[1];
        if (o[0] === 'insert') {
          sim.step(L0, L('<code>m.insert({' + K + ', ' + K * 10 + '})</code>.', '<code>m.insert({' + K + ', ' + K * 10 + '})</code>'));
          sim.call(fn('insert(const ValueT& val)')); sim.param('this', 'map_bst*', P(m)); sim.param('val', 'pair<int,int>', '(' + K + ',' + K * 10 + ')');
          const parA = sim.local('parent', 'node*', P(0));
          sim.step(at('node *parent = NULL;', 1), L('parent = NULL to begin with.', 'เริ่มด้วย parent = NULL'));
          const found = findNode(K, parA);
          const ptrA = sim.local('ptr', 'node*', P(found));
          sim.local('not_found', 'bool', !found);
          sim.step(at('bool not_found'), found ? L(K + ' already exists: a map keeps unique keys, so insert changes nothing.', 'มี ' + K + ' อยู่แล้ว map เก็บ key ไม่ซ้ำ insert จึงไม่เปลี่ยนอะไร') : L('Not found, so we will create a node.', 'ไม่เจอ จึงจะสร้างโหนดใหม่'));
          if (!found) {
            const par = sim.peek(parA).p;
            const n = sim.newObj('node', [['data.first', 'int', K], ['data.second', 'int', K * 10], ['left', 'node*', P(0)], ['right', 'node*', P(0)], ['parent', 'node*', P(par)]], { expr: 'new node(…)' });
            sim.w(ptrA, P(n)); relabel();
            sim.step(at('ptr = new node(val,NULL,NULL,parent)'), L('A new 32-byte node: data = (' + K + ', ' + K * 10 + '), no children, parent = ' + (par ? hex(par) : 'NULL') + '. It already points up to its parent, but nothing points down to it yet.', 'โหนดใหม่ 32 ไบต์: data = (' + K + ', ' + K * 10 + ') ไม่มีลูก parent = ' + (par ? hex(par) : 'NULL') + ' มันชี้ขึ้นไปที่พ่อแล้ว แต่ยังไม่มีใครชี้ลงมาที่มัน'));
            const cl = childLink(par, K);
            sim.w(cl.target, P(n));
            sim.step(at('child_link(parent, val.first) = ptr'), L('Assign through the returned reference: <b>' + cl.desc + ' = ' + hex(n) + '</b>. One line handles both "empty tree" and "hang under a parent".', 'กำหนดค่าผ่าน reference ที่ได้มา: <b>' + cl.desc + ' = ' + hex(n) + '</b> บรรทัดเดียวรองรับทั้งกรณี "ต้นไม้ว่าง" และ "แขวนใต้พ่อ"'));
            sim.wf(m, 'mSize', sim.rf(m, 'mSize') + 1);
            sim.step(at('mSize++'), L('mSize = ' + sim.pf(m, 'mSize') + '. Cost: one comparison per level, O(height).', 'mSize = ' + sim.pf(m, 'mSize') + ' ต้นทุน: เปรียบเทียบชั้นละครั้ง O(ความสูง)'));
          }
          sim.ret(undefined, { show: false });
          sim.step(L0, L('insert done.', 'insert เสร็จ'));
        } else if (o[0] === 'find') {
          sim.step(L0, L('<code>m.find(' + K + ')</code>.', '<code>m.find(' + K + ')</code>'));
          sim.call(fn('find(const KeyT& key)')); sim.param('this', 'map_bst*', P(m)); sim.param('key', 'int', K);
          const parA = sim.local('parent', 'node*', undefined);
          const f = findNode(K, parA);
          sim.local('ptr', 'node*', P(f));
          sim.step(at('return ptr == NULL ? end() : iterator(ptr)'), f ? L('Found: return an iterator wrapping ' + hex(f) + '.', 'เจอ: คืน iterator ที่ห่อ ' + hex(f)) : L('Not found: return end(), which is iterator(NULL).', 'ไม่เจอ: คืน end() ซึ่งคือ iterator(NULL)'));
          sim.ret(undefined, { show: false });
          sim.print((f ? 1 : 0) + '\n');
          sim.step(L0, L('Prints ' + (f ? 1 : 0) + '.', 'พิมพ์ ' + (f ? 1 : 0)));
        } else {
          sim.step(L0, L('<code>m.erase(' + K + ')</code>.', '<code>m.erase(' + K + ')</code>'));
          sim.call(fn('erase(const KeyT& key)')); sim.param('this', 'map_bst*', P(m)); sim.param('key', 'int', K);
          if (!root()) { sim.step(at('if (mRoot == NULL) return 0'), L('Empty tree: return 0.', 'ต้นไม้ว่าง: คืน 0')); sim.ret(0, { show: false }); sim.step(L0, L('Nothing erased.', 'ไม่ได้ลบอะไร')); return; }
          const parA = sim.local('parent', 'node*', P(0));
          const f = findNode(K, parA);
          const ptrA = sim.local('ptr', 'node*', P(f));
          if (!f) { sim.step(at('if (ptr == NULL) return 0'), L(K + ' is not in the tree: return 0.', 'ไม่มี ' + K + ' ในต้นไม้: คืน 0')); sim.ret(0, { show: false }); sim.step(L0, L('Nothing erased.', 'ไม่ได้ลบอะไร')); return; }
          let victim = f;
          const l = sim.r(sim.f(f, 'left')).p, r = sim.r(sim.f(f, 'right')).p;
          if (l && r) {
            sim.step(at('if (ptr->left != NULL && ptr->right != NULL)'), L('Node ' + K + ' has <b>two children</b>. We cannot just unlink it. Plan: find its successor (the smallest key in the right subtree), move that key here, and delete the successor\'s node instead.', 'โหนด ' + K + ' มี<b>ลูกสองตัว</b> ปลดออกตรง ๆ ไม่ได้ แผนคือ: หา successor (key น้อยสุดในต้นไม้ย่อยขวา) ย้าย key นั้นมาไว้ที่นี่ แล้วลบโหนดของ successor แทน'));
            sim.call(fn('find_min_node(node* r)')); sim.param('this', 'map_bst*', P(m)); sim.param('r', 'node*', P(r));
            const minA = sim.local('min', 'node*', P(r));
            let mn = r;
            sim.step(at('node *min = r;'), L('Start at the right child ' + key(r) + '.', 'เริ่มที่ลูกขวา ' + key(r)));
            while (sim.r(sim.f(mn, 'left')).p) { mn = sim.peek(sim.f(mn, 'left')).p; sim.w(minA, P(mn)); sim.step(at('while (min->left != NULL) min = min->left'), L('Go left to ' + key(mn) + '.', 'ไปทางซ้ายถึง ' + key(mn))); }
            sim.step(at('while (min->left != NULL) min = min->left'), L('No left child: the successor is ' + key(mn) + '.', 'ไม่มีลูกซ้าย: successor คือ ' + key(mn)));
            sim.ret(P(mn), { type: 'node*', show: false });
            sim.local('min', 'node*', P(mn));
            sim.step(at('node *min = find_min_node(ptr->right)'), L('min = ' + hex(mn) + ' (key ' + key(mn) + '). A successor never has a left child.', 'min = ' + hex(mn) + ' (key ' + key(mn) + ') successor ไม่มีลูกซ้ายเสมอ'));
            const mp = sim.r(sim.f(mn, 'parent')).p;
            const cl = childLink(mp, key(mn));
            sim.local('link', 'node*&', P(cl.target), { ref: true });
            sim.step(at('node * &link = child_link(min->parent'), L('<code>link</code> is a reference to <b>' + cl.desc + '</b>, the pointer that currently points at min.', '<code>link</code> คือ reference ไปยัง <b>' + cl.desc + '</b> ซึ่งเป็นพอยน์เตอร์ที่ชี้ไปที่ min อยู่ตอนนี้'));
            const mr = sim.r(sim.f(mn, 'right')).p;
            sim.w(cl.target, P(mr));
            sim.step(at('link = (min->left == NULL) ? min->right : min->left'), L('Bypass min: ' + cl.desc + ' = min->right = ' + (mr ? hex(mr) : 'NULL') + '.', 'ข้าม min ไป: ' + cl.desc + ' = min->right = ' + (mr ? hex(mr) : 'NULL')));
            if (mr) { sim.wf(mr, 'parent', P(mp)); sim.step(at('if (link != NULL) link->parent = min->parent', 1), L('min\'s right child moves up, so fix its parent pointer to ' + hex(mp) + '.', 'ลูกขวาของ min เลื่อนขึ้น จึงแก้ parent ของมันเป็น ' + hex(mp))); }
            else sim.step(at('if (link != NULL) link->parent = min->parent', 1), L('link is NULL, no parent pointer to fix.', 'link เป็น NULL ไม่มี parent ให้แก้'));
            const k1 = sim.r(sim.f(f, 'data.first')), k2 = sim.r(sim.f(mn, 'data.first'));
            sim.wf(f, 'data.first', k2); sim.wf(mn, 'data.first', k1);
            sim.step(at('std::swap(ptr->data.first, min->data.first)'), L('Swap keys: node ' + hex(f) + ' now holds ' + k2 + '. The tree is still ordered, because ' + k2 + ' is the smallest key bigger than everything on the left.', 'สลับ key: โหนด ' + hex(f) + ' ตอนนี้เก็บ ' + k2 + ' ต้นไม้ยังเรียงถูก เพราะ ' + k2 + ' คือ key ที่น้อยที่สุดที่มากกว่าทุกตัวทางซ้าย'));
            const v1 = sim.r(sim.f(f, 'data.second')), v2 = sim.r(sim.f(mn, 'data.second'));
            sim.wf(f, 'data.second', v2); sim.wf(mn, 'data.second', v1); relabel();
            sim.step(at('std::swap(ptr->data.second, min->data.second)'), L('Swap the mapped values too.', 'สลับค่าที่ผูกไว้ด้วย'));
            sim.w(ptrA, P(mn)); victim = mn;
            sim.step(at('ptr = min;'), L('Now delete <b>min\'s node</b> (holding the old key ' + K + ') instead. It is already unlinked.', 'ตอนนี้ลบ<b>โหนดของ min</b> (ที่เก็บ key เดิม ' + K + ') แทน มันถูกปลดออกแล้ว'));
          } else {
            sim.step(at('if (ptr->left != NULL && ptr->right != NULL)'), L('Node ' + K + ' has ' + (l || r ? 'one child' : 'no children') + ': easy case.', 'โหนด ' + K + ' มี' + (l || r ? 'ลูกตัวเดียว' : 'ไม่มีลูก') + ': กรณีง่าย'));
            const pp = sim.r(sim.f(f, 'parent')).p;
            const cl = childLink(pp, K);
            sim.local('link', 'node*&', P(cl.target), { ref: true });
            sim.step(at('node * &link = child_link(ptr->parent, key)'), L('<code>link</code> refers to <b>' + cl.desc + '</b>.', '<code>link</code> อ้างถึง <b>' + cl.desc + '</b>'));
            const repl = l || r;
            sim.w(cl.target, P(repl));
            sim.step(at('link = (ptr->left == NULL) ? ptr->right : ptr->left'), L(cl.desc + ' = ' + (repl ? hex(repl) + ' (the only child moves up)' : 'NULL') + '.', cl.desc + ' = ' + (repl ? hex(repl) + ' (ลูกตัวเดียวเลื่อนขึ้นมา)' : 'NULL')));
            if (repl) { sim.wf(repl, 'parent', P(pp)); sim.step(at('if (link != NULL) link->parent = ptr->parent'), L('Fix the child\'s parent pointer to ' + (pp ? hex(pp) : 'NULL') + '. Forgetting this line is exactly what checkParent() catches in the exams.', 'แก้ parent ของลูกเป็น ' + (pp ? hex(pp) : 'NULL') + ' การลืมบรรทัดนี้คือสิ่งที่ checkParent() ในข้อสอบจับได้')); }
          }
          sim.free(victim);
          sim.step(at('delete ptr;'), L('Free the node.', 'คืนโหนด'));
          sim.wf(m, 'mSize', sim.rf(m, 'mSize') - 1);
          sim.step(at('mSize--'), L('mSize = ' + sim.pf(m, 'mSize') + '.', 'mSize = ' + sim.pf(m, 'mSize')));
          sim.ret(1, { show: false });
          sim.step(L0, L('erase done.', 'erase เสร็จ'));
        }
      });
      sim.step(mainL + 2 + ops.length, L('Done. An inorder walk (left, node, right) of this tree visits the keys in sorted order.', 'เสร็จ การเดินแบบ inorder (ซ้าย โหนด ขวา) จะได้ key เรียงจากน้อยไปมาก'));
    }
  });
})();
