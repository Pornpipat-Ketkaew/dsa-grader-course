/* Part III · greedy interval scheduling (lesson 13) */
(() => {
  const code = iv => `struct Iv { int s, e; };              // start, end
int main() {
  Iv a[${iv.length}] = {${iv.map(x => '{' + x[0] + ',' + x[1] + '}').join(', ')}};
  sort(a, a + ${iv.length}, [](const Iv& x, const Iv& y) { return x.e < y.e; });
  int cnt = 0, lastEnd = -1;
  for (int i = 0; i < ${iv.length}; i++)
    if (a[i].s >= lastEnd) {            // fits after the last chosen one
      cnt++;
      lastEnd = a[i].e;
    }
  cout << cnt << "\\n";
}
`;
  const parse = p => {
    const parts = String(p.iv).split(/[,;\n]+/).map(x => x.trim()).filter(Boolean).slice(0, 8);
    const iv = parts.map(x => { const m = x.match(/^(\d+)\s*-\s*(\d+)$/); if (!m || +m[1] >= +m[2] || +m[2] > 20) throw userErr(L('Cannot read "' + x + '". Write start-end with start < end ≤ 20, e.g. 1-4.', 'อ่าน "' + x + '" ไม่ได้ ให้เขียน start-end โดย start < end ≤ 20 เช่น 1-4')); return [+m[1], +m[2]]; });
    if (iv.length < 2) throw userErr(L('Give 2 to 8 intervals.', 'ใส่ช่วง 2 ถึง 8 ช่วง'));
    return iv;
  };
  const DEF = '5-9, 1-4, 6-10, 3-5, 8-11, 0-6, 5-7, 3-9';
  def({
    id: 'interval-greedy', part: 3, lesson: '13', lessonFile: '13-greedy.md',
    title: L('Greedy: pick the interval that ends first', 'Greedy: เลือกช่วงที่จบก่อน'),
    summary: L('To fit the most non-overlapping intervals, sort by end time and take every interval that starts after the last one you took. Ending early leaves the most room for the rest; that exchange argument is why the greedy choice is safe. In memory, an array of structs stores s and e side by side.',
      'เพื่อให้ได้ช่วงที่ไม่ทับกันมากที่สุด ให้เรียงตามเวลาจบ แล้วเลือกทุกช่วงที่เริ่มหลังช่วงสุดท้ายที่เลือกไว้ การจบเร็วเหลือพื้นที่ให้ช่วงอื่นมากที่สุด เหตุผลแบบแลกเปลี่ยนนี้ทำให้การเลือกแบบโลภปลอดภัย ในหน่วยความจำ อาเรย์ของ struct เก็บ s และ e เรียงคู่กัน'),
    blurb: L('Sort by end, one pass, an array of structs.', 'เรียงตามจุดจบ วนรอบเดียว อาเรย์ของ struct'),
    params: [{ id: 'iv', label: L('Intervals', 'ช่วง'), value: DEF }],
    paramHint: L('start-end pairs, 0–20', 'คู่ start-end ค่า 0–20'),
    code: code(parse({ iv: DEF })),
    codeFn: p => { try { return code(parse(p)); } catch (e) { return code([[0, 1], [1, 2]]); } },
    build(sim, prm) {
      const iv = parse(prm), n = iv.length, src = code(iv), at = LN(src);
      let order = iv.map((x, k) => k), state = {}, cur = null, lastEnd = null;   // state[k] = 'take' | 'skip'
      const vals = () => { const b = sim.top().vars.find(v => v.name === 'a'); const out = []; for (let i = 0; i < n; i++) out.push([b.fields[2 * i].value, b.fields[2 * i + 1].value]); return out; };
      sim.viewFn = S => {
        const a = S.frames[0] && S.frames[0].vars.find(v => v.name === 'a'); if (!a) return null;
        const X = t => 46 + t * 22, rowH = 26, W = X(Math.max(12, ...iv.map(x => x[1]))) + 30;
        let s = '<svg width="' + W + '" height="' + (n * rowH + 40) + '" viewBox="0 0 ' + W + ' ' + (n * rowH + 40) + '">';
        const maxT = Math.max(12, ...iv.map(x => x[1]));
        for (let t = 0; t <= maxT; t++) s += '<line x1="' + X(t) + '" y1="4" x2="' + X(t) + '" y2="' + (n * rowH + 12) + '" style="stroke:var(--line);stroke-width:' + (t % 5 ? 0.6 : 1.2) + '"/><text x="' + X(t) + '" y="' + (n * rowH + 26) + '" text-anchor="middle" font-size="10" style="fill:var(--muted)">' + t + '</text>';
        for (let i = 0; i < n; i++) {
          const st = a.fields[2 * i].value, en = a.fields[2 * i + 1].value, y = 8 + i * rowH;
          const c = vc(state[i] === 'take' ? 'ok' : state[i] === 'skip' ? 'bad' : (i === cur ? 'hl' : 'hp'));
          s += '<text x="4" y="' + (y + 15) + '" font-size="11" style="fill:var(--muted)">a[' + i + ']</text>';
          s += '<rect x="' + X(st) + '" y="' + y + '" width="' + (X(en) - X(st)) + '" height="' + (rowH - 8) + '" rx="5" style="fill:' + c.f + ';stroke:' + c.s + ';stroke-width:' + (i === cur ? 2.4 : 1.4) + (state[i] === 'skip' ? ';stroke-dasharray:4 3' : '') + '"/>';
          s += '<text x="' + ((X(st) + X(en)) / 2) + '" y="' + (y + 13) + '" text-anchor="middle" font-size="11">' + st + '–' + en + '</text>';
        }
        if (lastEnd != null && lastEnd >= 0) s += '<line x1="' + X(lastEnd) + '" y1="0" x2="' + X(lastEnd) + '" y2="' + (n * rowH + 12) + '" style="stroke:var(--ptr);stroke-width:2;stroke-dasharray:5 3"/><text x="' + (X(lastEnd) + 4) + '" y="10" font-size="11" font-weight="700" style="fill:var(--ptr)">lastEnd</text>';
        return { kind: 'html', title: L('timeline', 'เส้นเวลา'), cap: L('Rows follow the array order. Green = taken, red dashed = overlaps the last taken one, teal = being checked.', 'แถวเรียงตามลำดับในอาเรย์ เขียว = เลือก แดงเส้นประ = ทับกับช่วงที่เลือกล่าสุด ฟ้าอมเขียว = กำลังตรวจ'), html: s + '</svg>' };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const fields = []; iv.forEach((x, i) => { fields.push(['[' + i + '].s', 'int', x[0]]); fields.push(['[' + i + '].e', 'int', x[1]]); });
      const A = sim.obj('a', 'Iv[' + n + ']', fields);
      sim.step(at('Iv a['), L('An array of ' + n + ' structs. Each Iv is 8 bytes (two ints), and they sit back to back: a[0].s, a[0].e, a[1].s, a[1].e, … So a[i].e lives at base + i×8 + 4.', 'อาเรย์ของ struct ' + n + ' ตัว Iv แต่ละตัวมี 8 ไบต์ (int สองตัว) และเรียงติดกัน: a[0].s, a[0].e, a[1].s, a[1].e, … ดังนั้น a[i].e อยู่ที่ base + i×8 + 4'));
      const sorted = iv.slice().sort((x, y) => x[1] - y[1]);
      sorted.forEach((x, i) => { sim.wf(A, '[' + i + '].s', x[0]); sim.wf(A, '[' + i + '].e', x[1]); });
      sim.step(at('sort(a'), L('sort with a lambda comparator reorders the structs by end time e (writes shown all at once). Each struct moves as a whole 8-byte unit. Cost: O(n log n), the most expensive part.', 'sort ที่มี lambda เป็นตัวเปรียบเทียบ จัดเรียง struct ตามเวลาจบ e (แสดงการเขียนทั้งหมดรวมกัน) struct แต่ละตัวย้ายเป็นก้อน 8 ไบต์ทั้งก้อน ราคา O(n log n) ซึ่งเป็นส่วนที่แพงที่สุด'));
      const cA = sim.local('cnt', 'int', 0), lA = sim.local('lastEnd', 'int', -1);
      lastEnd = -1;
      sim.step(at('int cnt = 0'), L('Nothing chosen yet: cnt = 0, lastEnd = −1 (so the first interval always fits).', 'ยังไม่ได้เลือกอะไร: cnt = 0, lastEnd = −1 (ช่วงแรกจึงใส่ได้เสมอ)'));
      const iA = sim.local('i', 'int', 0);
      let cnt = 0;
      for (let i = 0; i < n; i++) {
        sim.w(iA, i); cur = i;
        const s = sim.rf(A, '[' + i + '].s'), le = sim.r(lA);
        if (s >= le) {
          state[i] = 'take'; cnt++; sim.w(cA, cnt);
          const e = sim.rf(A, '[' + i + '].e'); sim.w(lA, e); lastEnd = e;
          sim.step(at('lastEnd = a[i].e'), L('a[' + i + '] = ' + s + '–' + e + ': it starts at ' + s + ' ≥ lastEnd ' + le + ', so it fits. <b>Take it</b>: cnt = ' + cnt + ', lastEnd = ' + e + '.', 'a[' + i + '] = ' + s + '–' + e + ': เริ่มที่ ' + s + ' ≥ lastEnd ' + le + ' จึงใส่ได้ <b>เลือก</b>: cnt = ' + cnt + ', lastEnd = ' + e), { lines: [at('if (a[i].s >= lastEnd)'), at('cnt++;')] });
        } else {
          state[i] = 'skip';
          sim.step(at('if (a[i].s >= lastEnd)'), L('a[' + i + '] starts at ' + s + ' &lt; lastEnd ' + le + ': it overlaps the interval we already took. Skip. (Taking it instead could never help: it ends later.)', 'a[' + i + '] เริ่มที่ ' + s + ' &lt; lastEnd ' + le + ': ทับกับช่วงที่เลือกไว้แล้ว ข้าม (เลือกมันแทนก็ไม่ช่วย เพราะมันจบช้ากว่า)'), { lines: [at('for (int i = 0')] });
        }
      }
      cur = null; sim.drop('i');
      sim.print(sim.r(cA) + '\n');
      sim.step(at('cout << cnt'), L('Maximum number of non-overlapping intervals: <b>' + cnt + '</b>.', 'จำนวนช่วงที่ไม่ทับกันมากที่สุด: <b>' + cnt + '</b>'));
      sim.ret(0, { show: false });
    }
  });
})();
