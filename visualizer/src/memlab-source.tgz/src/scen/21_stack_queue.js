/* Part II · CP::stack and CP::queue (real code from stack.h / queue.h) */

// shared: ensureCapacity + expand for array-backed CP containers.
// opts: {obj, fn, at, label, queue}  (queue → logical copy with mFront and reset mFront = 0)
function cpGrow(sim, need, o) {
  const { obj, fn, at } = o;
  sim.call(fn('ensureCapacity(size_t capacity)'));
  sim.param('this', o.cls + '*', P(obj)); sim.param('capacity', 'size_t', need);
  const cap = sim.rf(obj, 'mCap');
  if (need <= cap) {
    sim.step(at('if (capacity > mCap)'), L(need + ' &gt; mCap (' + cap + ')? No, there is room.', need + ' &gt; mCap (' + cap + ') หรือไม่? ไม่ ยังมีที่ว่าง'));
    sim.ret(undefined, { show: false });
    return false;
  }
  sim.step(at('if (capacity > mCap)'), L(need + ' &gt; mCap (' + cap + ')? <b>Yes</b>: full, so grow.', need + ' &gt; mCap (' + cap + ') หรือไม่? <b>ใช่</b>: เต็มแล้ว ต้องขยาย'));
  const s = need > 2 * cap ? need : 2 * cap;
  sim.local('s', 'size_t', s);
  sim.step(at('size_t s ='), L('New capacity: ' + s + ' (double).', 'ความจุใหม่: ' + s + ' (สองเท่า)'));
  sim.call(fn('expand(size_t capacity)'));
  sim.param('this', o.cls + '*', P(obj)); sim.param('capacity', 'size_t', s);
  const old = sim.pf(obj, 'mData').p;
  const nb = sim.newArray('int', s, 0, { expr: 'new int[' + s + ']()', label: L('arr: the new buffer', 'arr: บัฟเฟอร์ใหม่'), used: 0 });
  sim.local('arr', 'int*', P(nb));
  sim.step(at('T *arr = new T[capacity]()'), L('Allocate a new buffer of ' + s + ' slots.', 'จองบัฟเฟอร์ใหม่ ' + s + ' ช่อง'));
  const n = sim.rf(obj, 'mSize');
  const front = o.queue ? sim.rf(obj, 'mFront') : 0;
  const ia = sim.local('i', 'size_t', 0);
  for (let k = 0; k < n; k++) {
    sim.w(ia, k);
    const src = (front + k) % cap;
    const val = sim.r(old + 4 * src); sim.w(nb + 4 * k, val);
    sim.block(nb).used = k + 1;
    sim.step(at(o.queue ? 'arr[i] = mData[(mFront + i) % mCap]' : 'arr[i] = mData[i]'), o.queue
      ? L('i = ' + k + ': logical element ' + k + ' sits at physical (' + front + ' + ' + k + ') % ' + cap + ' = ' + src + '. Copy ' + val + ' to arr[' + k + '].', 'i = ' + k + ': สมาชิกลำดับที่ ' + k + ' อยู่ที่ตำแหน่งจริง (' + front + ' + ' + k + ') % ' + cap + ' = ' + src + ' คัดลอก ' + val + ' ไป arr[' + k + ']')
      : L('i = ' + k + ': copy ' + val + '.', 'i = ' + k + ': คัดลอก ' + val));
  }
  sim.drop('i');
  sim.free(old);
  sim.step(at('delete [] mData'), L('Free the old buffer.', 'คืนบัฟเฟอร์เก่า'));
  sim.wf(obj, 'mData', P(nb));
  sim.step(at('mData = arr'), L('mData now points at the new buffer.', 'mData ชี้ไปที่บัฟเฟอร์ใหม่'));
  sim.wf(obj, 'mCap', s);
  o.sync && o.sync();
  sim.step(at('mCap = capacity'), L('mCap = ' + s + '.', 'mCap = ' + s));
  if (o.queue) {
    sim.wf(obj, 'mFront', 0); o.sync && o.sync();
    sim.step(at('mFront = 0'), L('<b>mFront = 0</b>: the copy put the elements back in logical order starting at slot 0, so the wrap-around is "undone".', '<b>mFront = 0</b>: การคัดลอกเรียงสมาชิกใหม่ตามลำดับเชิงตรรกะเริ่มที่ช่อง 0 การวนรอบจึงถูก "คลาย" ออก'));
  }
  sim.ret(undefined, { show: false });
  sim.ret(undefined, { show: false });
  return true;
}

// ------------------------------------------------------------------ CP::stack
(() => {
  const CLS = `namespace CP {
template <typename T>
class stack {
  protected:
    T *mData;
    size_t mCap;
    size_t mSize;

    void expand(size_t capacity) {
      T *arr = new T[capacity]();
      for (size_t i = 0;i < mSize;i++) {
        arr[i] = mData[i];
      }
      delete [] mData;
      mData = arr;
      mCap = capacity;
    }
    void ensureCapacity(size_t capacity) {
      if (capacity > mCap) {
        size_t s = (capacity > 2 * mCap) ? capacity : 2 * mCap;
        expand(s);
      }
    }
  public:
    stack() {
      int cap = 1;
      mData = new T[cap]();
      mCap = cap;
      mSize = 0;
    }
    const T& top() const {
      return mData[mSize-1];
    }
    void push(const T& element) {
      ensureCapacity(mSize + 1);
      mData[mSize] = element;
      mSize++;
    }
    void pop() {
      mSize--;
    }
};
}
int main() {
  CP::stack<int> s;
`;
  const parse = str => {
    const ops = parseOps(str, 14).map(o => {
      if (o[0] === 'push') { if (typeof o[1] !== 'number') throw userErr(L('push needs a number.', 'push ต้องมีตัวเลข')); return ['push', o[1]]; }
      if (o[0] === 'pop') return ['pop'];
      if (o[0] === 'top') return ['top'];
      throw userErr(L('Unknown operation "' + o[0] + '". Use push x, pop, top.', 'ไม่รู้จักคำสั่ง "' + o[0] + '" ใช้ได้: push x, pop, top'));
    });
    if (!ops.length) throw userErr(L('Type at least one operation.', 'ใส่คำสั่งอย่างน้อยหนึ่งคำสั่ง'));
    return ops;
  };
  const line = o => o[0] === 'push' ? '  s.push(' + o[1] + ');' : o[0] === 'pop' ? '  s.pop();' : '  cout << s.top() << "\\n";';
  const codeOf = ops => CLS + ops.map(line).join('\n') + '\n}\n';
  const DEF = 'push 10, push 20, push 30, top, pop, push 40, push 50, top';
  def({
    id: 'cp-stack', part: 2, lesson: '04', lessonFile: '04-cp-stack-queue.md', dangOK: true,
    title: L('CP::stack: the top is the end of an array', 'CP::stack: top คือท้ายอาร์เรย์'),
    summary: L('CP::stack is a dynamic array where only the last slot is visible. push writes mData[mSize] and pop just does mSize--. The tower on top shows the LIFO picture; the memory below shows that it is really a plain array.',
      'CP::stack คืออาร์เรย์แบบยืดได้ที่มองเห็นแค่ช่องสุดท้าย push เขียนที่ mData[mSize] ส่วน pop แค่ mSize-- ภาพหอคอยด้านบนแสดงแนวคิด LIFO ส่วนหน่วยความจำด้านล่างแสดงว่าจริง ๆ มันคืออาร์เรย์ธรรมดา'),
    blurb: L('push, pop, top and "k-th from the top = mData[mSize-1-k]".', 'push, pop, top และ "ตัวที่ k จากบน = mData[mSize-1-k]"'),
    params: [{ id: 'ops', label: L('Operations', 'คำสั่ง'), value: DEF }],
    paramHint: L('push x · pop · top', 'push x · pop · top'),
    code: codeOf(parse(DEF)),
    codeFn: p => { try { return codeOf(parse(p.ops)); } catch (e) { return CLS + '}\n'; } },
    build(sim, prm) {
      const ops = parse(prm.ops), code = codeOf(ops), at = LN(code);
      const mainL = at('int main');
      let s;
      const fn = x => 'stack<int>::' + x;
      const buf = () => sim.pf(s, 'mData').p;
      const sync = () => { const b = sim.block(buf()); if (b) { b.used = sim.pf(s, 'mSize'); b.label = L('s.mData buffer · mCap = ' + sim.pf(s, 'mCap'), 'บัฟเฟอร์ของ s.mData · mCap = ' + sim.pf(s, 'mCap')); } };
      sim.viewFn = S => {
        if (!s) return null;
        const mD = S.pf(s, 'mData'); if (!isP(mD)) return null;
        const b = S.heap.find(x => x.addr === mD.p); if (!b) return null;
        const n = S.pf(s, 'mSize');
        let h = '<div style="display:flex;gap:36px;align-items:flex-end;flex-wrap:wrap"><div style="display:flex;flex-direction:column-reverse;gap:3px;min-width:150px">';
        for (let i = 0; i < b.n; i++) {
          const used = i < n;
          h += '<div style="display:flex;align-items:center;gap:8px;font-family:var(--font-mono);font-size:13px"><span style="width:58px;text-align:right;color:var(--muted);font-size:11px">mData[' + i + ']</span><span style="width:70px;height:30px;display:grid;place-items:center;border:1.5px ' + (used ? 'solid var(--heap)' : 'dashed var(--line)') + ';background:' + (used ? 'var(--heap-tint)' : 'transparent') + ';border-radius:5px;color:' + (used ? 'var(--ink)' : 'var(--muted)') + '">' + (used ? fmtPlain(b.cells[i]) : '') + '</span>' + (used && i === n - 1 ? '<b style="color:var(--ptr);font-size:12px">← top (k=0)</b>' : used ? '<span style="color:var(--muted);font-size:11px">k=' + (n - 1 - i) + '</span>' : '') + '</div>';
        }
        h += '</div><div style="font-size:13px;color:var(--muted);max-width:36ch">' + tr(L('The k-th element from the top (k = 0 is the top) is <b>mData[mSize − 1 − k]</b>. Dashed slots are allocated but empty. Stack problems such as deep_push and mitosis are about translating "from the top" into these indices.', 'สมาชิกตัวที่ k จากด้านบน (k = 0 คือ top) อยู่ที่ <b>mData[mSize − 1 − k]</b> ช่องเส้นประคือจองแล้วแต่ยังว่าง โจทย์ stack อย่าง deep_push และ mitosis คือการแปล "นับจากด้านบน" เป็นดัชนีเหล่านี้')) + '</div></div>';
        return { kind: 'html', title: L('the stack as a tower', 'stack ในรูปหอคอย'), html: h };
      };
      sim.call('main()');
      sim.step(mainL, L('main starts.', 'main เริ่มทำงาน'));
      s = sim.obj('s', 'CP::stack<int>', [['mData', 'int*', undefined], ['mCap', 'size_t', undefined], ['mSize', 'size_t', undefined]]);
      sim.call(fn('stack()')); sim.param('this', 'stack*', P(s));
      const b0 = sim.newArray('int', 1, 0, { used: 0, expr: 'new int[1]()' });
      sim.wf(s, 'mData', P(b0)); sim.wf(s, 'mCap', 1); sim.wf(s, 'mSize', 0); sync();
      sim.step(at('stack() {'), L('The constructor gives s a 1-slot buffer: mCap = 1, mSize = 0. Same three fields as CP::vector.', 'คอนสตรักเตอร์ให้บัฟเฟอร์ 1 ช่องแก่ s: mCap = 1, mSize = 0 ฟิลด์สามตัวเหมือน CP::vector'));
      sim.ret(undefined, { show: false });
      sim.step(mainL + 1, L('s is ready (empty).', 's พร้อมใช้ (ว่าง)'));
      ops.forEach((o, k) => {
        const L0 = mainL + 2 + k;
        const n = sim.pf(s, 'mSize');
        if (o[0] === 'push') {
          const t = sim.local('temp', 'int', o[1]);
          sim.step(L0, L('<code>s.push(' + o[1] + ')</code>.', '<code>s.push(' + o[1] + ')</code>'));
          sim.call(fn('push(const T& element)')); sim.param('this', 'stack*', P(s)); sim.ref('element', 'const int', t, { param: true });
          sim.step(at('void push'), L('push starts by making sure there is room for mSize + 1 = ' + (n + 1) + ' elements.', 'push เริ่มจากตรวจว่ามีที่ให้ mSize + 1 = ' + (n + 1) + ' ตัวหรือไม่'));
          cpGrow(sim, n + 1, { obj: s, fn, at, cls: 'stack', sync });
          sim.r(t); sim.w(buf() + 4 * n, o[1]);
          sim.step(at('mData[mSize] = element'), L('Write ' + o[1] + ' at mData[mSize] = mData[' + n + ']: the slot just past the current top. No shifting, O(1).', 'เขียน ' + o[1] + ' ที่ mData[mSize] = mData[' + n + '] คือช่องถัดจาก top ปัจจุบัน ไม่ต้องเลื่อนอะไร O(1)'));
          sim.wf(s, 'mSize', n + 1); sync();
          sim.step(at('mSize++'), L('mSize = ' + (n + 1) + '. ' + o[1] + ' is the new top.', 'mSize = ' + (n + 1) + ' ตอนนี้ ' + o[1] + ' คือ top ตัวใหม่'));
          sim.ret(undefined, { show: false }); sim.drop('temp');
          sim.step(L0, L('push done.', 'push เสร็จ'));
        } else if (o[0] === 'pop') {
          if (n === 0) throw userErr(L('pop on an empty stack throws out_of_range in the real CP::stack.', 'pop ตอน stack ว่าง CP::stack ตัวจริงจะโยน out_of_range'));
          sim.step(L0, L('<code>s.pop()</code>.', '<code>s.pop()</code>'));
          sim.call(fn('pop()')); sim.param('this', 'stack*', P(s));
          sim.wf(s, 'mSize', n - 1); sync();
          sim.step(at('mSize--'), L('pop is just <code>mSize--</code>. The value ' + fmtPlain(sim.peek(buf() + 4 * (n - 1))) + ' stays in memory but is no longer part of the stack; the next push will overwrite it.', 'pop คือ <code>mSize--</code> เท่านั้น ค่า ' + fmtPlain(sim.peek(buf() + 4 * (n - 1))) + ' ยังอยู่ในหน่วยความจำแต่ไม่นับเป็นสมาชิกแล้ว push ครั้งหน้าจะเขียนทับ'));
          sim.ret(undefined, { show: false });
          sim.step(L0, L('pop done.', 'pop เสร็จ'));
        } else {
          if (n === 0) throw userErr(L('top on an empty stack throws out_of_range.', 'top ตอน stack ว่างจะโยน out_of_range'));
          sim.call(fn('top() const')); sim.param('this', 'const stack*', P(s));
          const val = sim.r(buf() + 4 * (n - 1)); sim.rf(s, 'mSize');
          sim.step(at('return mData[mSize-1]'), L('top() returns a reference to mData[mSize − 1] = mData[' + (n - 1) + '] = ' + val + '.', 'top() คืน reference ไปยัง mData[mSize − 1] = mData[' + (n - 1) + '] = ' + val));
          sim.ret(val);
          sim.print(val + '\n');
          sim.step(L0, L('Print ' + val + '.', 'พิมพ์ ' + val));
        }
      });
      sim.step(mainL + 2 + ops.length, L('Final stack (bottom → top): [' + cellsOf(sim, buf()).slice(0, sim.pf(s, 'mSize')).join(', ') + '].', 'stack สุดท้าย (ล่าง → บน): [' + cellsOf(sim, buf()).slice(0, sim.pf(s, 'mSize')).join(', ') + ']'));
    }
  });
})();

// ------------------------------------------------------------------ CP::queue (circular buffer)
(() => {
  const CLS = `namespace CP {
template <typename T>
class queue {
  protected:
    T *mData;
    size_t mCap;
    size_t mSize;
    size_t mFront;

    void expand(size_t capacity) {
      T *arr = new T[capacity]();
      for (size_t i = 0;i < mSize;i++) {
        arr[i] = mData[(mFront + i) % mCap];
      }
      delete [] mData;
      mData = arr;
      mCap = capacity;
      mFront = 0;
    }
    void ensureCapacity(size_t capacity) {
      if (capacity > mCap) {
        size_t s = (capacity > 2 * mCap) ? capacity : 2 * mCap;
        expand(s);
      }
    }
  public:
    queue() {
      int cap = 1;
      mData = new T[cap]();
      mCap = cap;
      mSize = 0;
      mFront = 0;
    }
    const T& front() const {
      return mData[mFront];
    }
    const T& back() const {
      return mData[(mFront + mSize - 1) % mCap];
    }
    void push(const T& element) {
      ensureCapacity(mSize+1);
      mData[(mFront + mSize) % mCap] = element;
      mSize++;
    }
    void pop() {
      mFront = (mFront + 1) % mCap;
      mSize--;
    }
};
}
int main() {
  CP::queue<int> q;
`;
  const parse = str => {
    const ops = parseOps(str, 16).map(o => {
      if (o[0] === 'push') { if (typeof o[1] !== 'number') throw userErr(L('push needs a number.', 'push ต้องมีตัวเลข')); return ['push', o[1]]; }
      if (['pop', 'front', 'back'].includes(o[0])) return [o[0]];
      throw userErr(L('Unknown operation "' + o[0] + '". Use push x, pop, front, back.', 'ไม่รู้จักคำสั่ง "' + o[0] + '" ใช้ได้: push x, pop, front, back'));
    });
    if (!ops.length) throw userErr(L('Type at least one operation.', 'ใส่คำสั่งอย่างน้อยหนึ่งคำสั่ง'));
    return ops;
  };
  const line = o => o[0] === 'push' ? '  q.push(' + o[1] + ');' : o[0] === 'pop' ? '  q.pop();' : '  cout << q.' + o[0] + '() << "\\n";';
  const codeOf = ops => CLS + ops.map(line).join('\n') + '\n}\n';
  const DEF = 'push 1, push 2, push 3, pop, pop, push 4, push 5, push 6, front, back, push 7';
  def({
    id: 'cp-queue', part: 2, lesson: '04', lessonFile: '04-cp-stack-queue.md', dangOK: true,
    title: L('CP::queue: a circular buffer', 'CP::queue: บัฟเฟอร์วงกลม'),
    summary: L('Popping from the front of an array would shift everything (O(n)). CP::queue instead moves mFront forward and lets new elements wrap around to slot 0. Logical position i lives at physical slot (mFront + i) % mCap. Watch push 5 wrap around, and push 7 un-wrap it while growing.',
      'การ pop จากหน้าอาร์เรย์ต้องเลื่อนทุกตัว (O(n)) CP::queue จึงขยับ mFront ไปข้างหน้าแทน และให้สมาชิกใหม่วนกลับไปที่ช่อง 0 สมาชิกลำดับที่ i อยู่ที่ช่องจริง (mFront + i) % mCap ดู push 5 วนรอบ และ push 7 คลายการวนตอนขยาย'),
    blurb: L('mFront, wrap-around, (mFront + i) % mCap, re-linearising on growth.', 'mFront การวนรอบ (mFront + i) % mCap และการเรียงใหม่ตอนขยาย'),
    params: [{ id: 'ops', label: L('Operations', 'คำสั่ง'), value: DEF }],
    paramHint: L('push x · pop · front · back', 'push x · pop · front · back'),
    code: codeOf(parse(DEF)),
    codeFn: p => { try { return codeOf(parse(p.ops)); } catch (e) { return CLS + '}\n'; } },
    build(sim, prm) {
      const ops = parse(prm.ops), code = codeOf(ops), at = LN(code);
      const mainL = at('int main');
      let q;
      const fn = x => 'queue<int>::' + x;
      const F = n => sim.pf(q, n);
      const buf = () => F('mData').p;
      const sync = () => { const b = sim.block(buf()); if (b) { b.used = null; b.label = L('q.mData buffer · mCap = ' + F('mCap'), 'บัฟเฟอร์ของ q.mData · mCap = ' + F('mCap')); } };
      const logical = () => { const b = sim.block(buf()), f = F('mFront'), n = F('mSize'), c = F('mCap'); return Array.from({ length: n }, (_, i) => b.cells[(f + i) % c]); };
      sim.tagFn = S => {
        if (!q) return [];
        const mD = S.pf(q, 'mData'); if (!isP(mD)) return [];
        const b = S.heap.find(x => x.addr === mD.p && !x.freed); if (!b) return [];
        const f = S.pf(q, 'mFront'), n = S.pf(q, 'mSize'), c = S.pf(q, 'mCap');
        if (f == null || c == null || c !== b.n) return [];
        const t = [TAG(b.addr + 4 * f, 'front', 't2')];
        if (n > 0) t.push(TAG(b.addr + 4 * ((f + n - 1) % c), 'back', 't3'));
        return t;
      };
      sim.viewFn = S => {
        if (!q) return null;
        const mD = S.pf(q, 'mData'); if (!isP(mD)) return null;
        const b = S.heap.find(x => x.addr === mD.p && !x.freed); if (!b) return null;
        const f = S.pf(q, 'mFront'), n = S.pf(q, 'mSize'), c = S.pf(q, 'mCap');
        if (c !== b.n) return null;
        const cls = b.cells.map((x, i) => ((i - f + c) % c) < n ? 'hp' : 'dim');
        const lg = Array.from({ length: n }, (_, i) => fmtPlain(b.cells[(f + i) % c]));
        const phys = Array.from({ length: n }, (_, i) => '→' + ((f + i) % c));
        return {
          kind: 'multi', title: L('ring and logical order', 'วงแหวนและลำดับเชิงตรรกะ'), parts: [
            { kind: 'ring', n: c, front: f, size: n, cells: b.cells.map(x => fmtPlain(x)), cls },
            { kind: 'array', cap: L('Logical order (what front/pop see). Row 2: the physical slot of each element = (mFront + i) % mCap.', 'ลำดับเชิงตรรกะ (สิ่งที่ front/pop เห็น) แถวที่สอง: ช่องจริงของแต่ละตัว = (mFront + i) % mCap'), rows: [{ label: L('logical', 'เชิงตรรกะ'), cells: lg.length ? lg : ['∅'], cls: lg.map(() => 'hp') }, { label: L('slot', 'ช่องจริง'), cells: phys.length ? phys : [''], idx: false }] }
          ]
        };
      };
      sim.call('main()');
      sim.step(mainL, L('main starts.', 'main เริ่มทำงาน'));
      q = sim.obj('q', 'CP::queue<int>', [['mData', 'int*', undefined], ['mCap', 'size_t', undefined], ['mSize', 'size_t', undefined], ['mFront', 'size_t', undefined]]);
      sim.call(fn('queue()')); sim.param('this', 'queue*', P(q));
      const b0 = sim.newArray('int', 1, 0, { expr: 'new int[1]()' });
      sim.wf(q, 'mData', P(b0)); sim.wf(q, 'mCap', 1); sim.wf(q, 'mSize', 0); sim.wf(q, 'mFront', 0); sync();
      sim.step(at('queue() {'), L('A queue has a <b>fourth</b> field, <code>mFront</code>: the physical slot of the front element. It starts at 0 with a 1-slot buffer.', 'queue มีฟิลด์ที่<b>สี่</b> คือ <code>mFront</code>: ช่องจริงของสมาชิกตัวหน้าสุด เริ่มที่ 0 พร้อมบัฟเฟอร์ 1 ช่อง'));
      sim.ret(undefined, { show: false });
      sim.step(mainL + 1, L('q is ready (empty).', 'q พร้อมใช้ (ว่าง)'));
      ops.forEach((o, k) => {
        const L0 = mainL + 2 + k;
        const n = F('mSize');
        if (o[0] === 'push') {
          const t = sim.local('temp', 'int', o[1]);
          sim.step(L0, L('<code>q.push(' + o[1] + ')</code>.', '<code>q.push(' + o[1] + ')</code>'));
          sim.call(fn('push(const T& element)')); sim.param('this', 'queue*', P(q)); sim.ref('element', 'const int', t, { param: true });
          sim.step(at('void push'), L('push: first make room for mSize + 1 = ' + (n + 1) + '.', 'push: ก่อนอื่นตรวจว่ามีที่ให้ mSize + 1 = ' + (n + 1) + ' ตัว'));
          cpGrow(sim, n + 1, { obj: q, fn, at, cls: 'queue', queue: true, sync });
          const f = sim.rf(q, 'mFront'), c = sim.rf(q, 'mCap'); sim.rf(q, 'mSize');
          const slot = (f + n) % c;
          sim.r(t); sim.w(buf() + 4 * slot, o[1]);
          sim.step(at('mData[(mFront + mSize) % mCap] = element'), L('The back of the queue is logical position mSize = ' + n + ', so write at physical slot (' + f + ' + ' + n + ') % ' + c + ' = <b>' + slot + '</b>.' + (f + n >= c ? ' <b>It wrapped around</b> to the start of the array, reusing a slot freed by an earlier pop.' : ''), 'ท้ายคิวคือตำแหน่งเชิงตรรกะ mSize = ' + n + ' จึงเขียนที่ช่องจริง (' + f + ' + ' + n + ') % ' + c + ' = <b>' + slot + '</b>' + (f + n >= c ? ' <b>มันวนกลับ</b>ไปต้นอาร์เรย์ ใช้ช่องที่ pop ก่อนหน้านี้ทิ้งไว้' : '')));
          sim.wf(q, 'mSize', n + 1); sync();
          sim.step(at('mSize++'), L('mSize = ' + (n + 1) + '.', 'mSize = ' + (n + 1)));
          sim.ret(undefined, { show: false }); sim.drop('temp');
          sim.step(L0, L('Queue (front → back): [' + logical().join(', ') + '].', 'คิว (หน้า → ท้าย): [' + logical().join(', ') + ']'));
        } else if (o[0] === 'pop') {
          if (n === 0) throw userErr(L('pop on an empty queue throws out_of_range.', 'pop ตอนคิวว่างจะโยน out_of_range'));
          sim.step(L0, L('<code>q.pop()</code>.', '<code>q.pop()</code>'));
          sim.call(fn('pop()')); sim.param('this', 'queue*', P(q));
          const f = sim.rf(q, 'mFront'), c = sim.rf(q, 'mCap');
          sim.wf(q, 'mFront', (f + 1) % c);
          sim.step(at('mFront = (mFront + 1) % mCap'), L('No shifting at all: mFront moves from ' + f + ' to (' + f + ' + 1) % ' + c + ' = ' + ((f + 1) % c) + '. The old front value ' + fmtPlain(sim.peek(buf() + 4 * f)) + ' is simply left behind. O(1).', 'ไม่ต้องเลื่อนอะไรเลย: mFront ขยับจาก ' + f + ' เป็น (' + f + ' + 1) % ' + c + ' = ' + ((f + 1) % c) + ' ค่าหน้าเดิม ' + fmtPlain(sim.peek(buf() + 4 * f)) + ' ถูกทิ้งไว้เฉย ๆ O(1)'));
          sim.wf(q, 'mSize', n - 1); sync();
          sim.step(at('mSize--'), L('mSize = ' + (n - 1) + '.', 'mSize = ' + (n - 1)));
          sim.ret(undefined, { show: false });
          sim.step(L0, L('Queue (front → back): [' + logical().join(', ') + '].', 'คิว (หน้า → ท้าย): [' + logical().join(', ') + ']'));
        } else {
          if (n === 0) throw userErr(L(o[0] + ' on an empty queue throws out_of_range.', o[0] + ' ตอนคิวว่างจะโยน out_of_range'));
          const f = F('mFront'), c = F('mCap');
          const slot = o[0] === 'front' ? f : (f + n - 1) % c;
          sim.call(fn(o[0] + '() const')); sim.param('this', 'const queue*', P(q));
          const val = sim.r(buf() + 4 * slot); sim.rf(q, 'mFront');
          sim.step(at(o[0] === 'front' ? 'return mData[mFront]' : 'return mData[(mFront + mSize - 1) % mCap]'), o[0] === 'front'
            ? L('front() = mData[mFront] = mData[' + f + '] = ' + val + '.', 'front() = mData[mFront] = mData[' + f + '] = ' + val)
            : L('back() is logical position mSize − 1, at physical slot (' + f + ' + ' + n + ' − 1) % ' + c + ' = ' + slot + ': value ' + val + '.', 'back() คือตำแหน่งเชิงตรรกะ mSize − 1 อยู่ที่ช่องจริง (' + f + ' + ' + n + ' − 1) % ' + c + ' = ' + slot + ': ค่า ' + val));
          sim.ret(val); sim.print(val + '\n');
          sim.step(L0, L('Print ' + val + '.', 'พิมพ์ ' + val));
        }
      });
      sim.step(mainL + 2 + ops.length, L('Final queue (front → back): [' + logical().join(', ') + '], mFront = ' + F('mFront') + ', mCap = ' + F('mCap') + '. The master formula for every queue problem: logical i ↔ physical (mFront + i) % mCap.', 'คิวสุดท้าย (หน้า → ท้าย): [' + logical().join(', ') + '] mFront = ' + F('mFront') + ', mCap = ' + F('mCap') + ' สูตรหลักของโจทย์คิวทุกข้อ: ตำแหน่งเชิงตรรกะ i ↔ ช่องจริง (mFront + i) % mCap'));
    }
  });
})();
