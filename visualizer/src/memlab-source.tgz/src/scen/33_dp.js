/* Part III · bottom-up DP on a 2-D table: LCS (lesson 15) and 0/1 knapsack in 1-D (lesson 15) */
(() => {
  const mainVar = (S, nm) => S.frames[0] && S.frames[0].vars.find(q => q.name === nm);

  // ---------------------------------------------------------------- LCS
  const lcsCode = (a, b) => `int main() {
  char a[] = "${a}";
  char b[] = "${b}";
  int n = ${a.length}, m = ${b.length};
  int dp[${a.length + 1}][${b.length + 1}] = {};   // dp[i][j] = LCS length of a[0..i) and b[0..j)
  for (int i = 1; i <= n; i++)
    for (int j = 1; j <= m; j++)
      if (a[i - 1] == b[j - 1]) dp[i][j] = dp[i - 1][j - 1] + 1;
      else dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
  cout << dp[n][m] << "\\n";
}
`;
  const lcsParse = p => {
    const a = String(p.a).toUpperCase().replace(/[^A-Z]/g, '').slice(0, 6), b = String(p.b).toUpperCase().replace(/[^A-Z]/g, '').slice(0, 6);
    if (!a.length || !b.length) throw userErr(L('Both strings need 1 to 6 letters.', 'สตริงทั้งสองต้องมี 1 ถึง 6 ตัวอักษร'));
    return { a, b };
  };
  def({
    id: 'lcs', part: 3, lesson: '15', lessonFile: '15-dp-states.md',
    title: L('DP table: longest common subsequence', 'ตาราง DP: ลำดับย่อยร่วมที่ยาวที่สุด (LCS)'),
    summary: L('Each cell dp[i][j] is filled from three neighbours that are already known: up-left, up, and left. Filling row by row guarantees that. In memory the 2-D table is one flat block, row after row (row-major): dp[i][j] lives at base + (i × cols + j) × 4.',
      'แต่ละช่อง dp[i][j] ถูกเติมจากเพื่อนบ้านสามช่องที่รู้ค่าแล้ว: ซ้ายบน บน และซ้าย การเติมทีละแถวรับประกันข้อนี้ ในหน่วยความจำตาราง 2 มิติคือบล็อกแบนก้อนเดียว เรียงแถวต่อแถว (row-major): dp[i][j] อยู่ที่ base + (i × cols + j) × 4'),
    blurb: L('Fill order, dependencies, and how a 2-D array sits in memory.', 'ลำดับการเติม การพึ่งพา และอาเรย์ 2 มิติในหน่วยความจำ'),
    params: [{ id: 'a', label: 'a', value: 'ABCBDA', w: 110 }, { id: 'b', label: 'b', value: 'BDCAB', w: 110 }],
    paramHint: L('letters only, up to 6 each', 'ตัวอักษรเท่านั้น ไม่เกิน 6 ตัวต่อสตริง'),
    code: lcsCode('ABCBDA', 'BDCAB'),
    codeFn: p => { try { const { a, b } = lcsParse(p); return lcsCode(a, b); } catch (e) { return lcsCode('A', 'A'); } },
    build(sim, prm) {
      const { a, b } = lcsParse(prm), n = a.length, m = b.length, cols = m + 1, code = lcsCode(a, b), at = LN(code);
      let ci = null, cj = null, src = null, path = null;
      let D = 0;
      sim.viewFn = S => {
        const dv = mainVar(S, 'dp'); if (!dv) return null;
        const cells = [], cls = [];
        for (let i = 0; i <= n; i++) {
          cells.push([]); cls.push([]);
          for (let j = 0; j <= m; j++) {
            const v = dv.cells[i * cols + j];
            cells[i].push(v === undefined ? '?' : v);
            let c = (i === 0 || j === 0) ? 'dim' : '';
            if (src && src.some(([x, y]) => x === i && y === j)) c = 'cmp';
            if (i === ci && j === cj) c = 'chg';
            if (path && path.some(([x, y]) => x === i && y === j)) c = 'ok';
            cls[i].push(c);
          }
        }
        return { kind: 'table', title: L('dp table', 'ตาราง dp'), corner: 'i\\j', rows: ['0 ·'].concat(a.split('').map((c, k) => (k + 1) + ' ' + c)), cols: ['0 ·'].concat(b.split('').map((c, k) => (k + 1) + ' ' + c)), cells, cls };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const A = sim.arr('a', 'char', n + 1, a.split('').map(c => CH(c)).concat([CH('\0')]));
      sim.step(at('char a[]'), L('<code>char a[] = "' + a + '"</code> is ' + (n + 1) + ' bytes: one per letter plus the terminating <code>\\0</code>.', '<code>char a[] = "' + a + '"</code> มีขนาด ' + (n + 1) + ' ไบต์: ตัวอักษรละหนึ่งไบต์ บวก <code>\\0</code> ปิดท้าย'));
      const B = sim.arr('b', 'char', m + 1, b.split('').map(c => CH(c)).concat([CH('\0')]));
      sim.step(at('char b[]'), L('Same for b.', 'เช่นเดียวกันกับ b'));
      sim.local('n', 'int', n); sim.local('m', 'int', m);
      sim.step(at('int n ='), L('The lengths.', 'ความยาว'));
      D = sim.arr('dp', 'int', (n + 1) * cols, 0);
      const dv = sim.top().vars.find(v => v.name === 'dp'); dv.type = 'int[' + (n + 1) + '][' + cols + ']'; dv.cols = cols;
      sim.step(at('int dp['), L('<code>int dp[' + (n + 1) + '][' + cols + '] = {}</code>: ' + (n + 1) + ' × ' + cols + ' = ' + ((n + 1) * cols) + ' ints in <b>one flat block</b>. In memory, row 1 starts right after row 0 ends. Row 0 and column 0 (comparing with an empty string) stay 0.', '<code>int dp[' + (n + 1) + '][' + cols + '] = {}</code>: int ' + (n + 1) + ' × ' + cols + ' = ' + ((n + 1) * cols) + ' ตัว ใน<b>บล็อกแบนก้อนเดียว</b> ในหน่วยความจำ แถว 1 เริ่มต่อจากท้ายแถว 0 ทันที แถว 0 และคอลัมน์ 0 (เทียบกับสตริงว่าง) เป็น 0 ตลอด'));
      const iA = sim.local('i', 'int', 1);
      const jA = sim.local('j', 'int', 1);
      const cell = (i, j) => D + 4 * (i * cols + j);
      for (let i = 1; i <= n; i++) {
        sim.w(iA, i);
        for (let j = 1; j <= m; j++) {
          sim.w(jA, j); ci = i; cj = j;
          const x = sim.r(A + i - 1), y = sim.r(B + j - 1);
          const addr = cell(i, j);
          if (x.ch === y.ch) {
            const d = sim.r(cell(i - 1, j - 1));
            src = [[i - 1, j - 1]];
            sim.w(addr, d + 1);
            sim.step(at('if (a[i - 1] == b[j - 1])'), L('dp[' + i + '][' + j + ']: a[' + (i - 1) + '] = \'' + x.ch + '\' equals b[' + (j - 1) + '] = \'' + y.ch + '\'. Extend the diagonal: dp[' + (i - 1) + '][' + (j - 1) + '] + 1 = <b>' + (d + 1) + '</b>. (Address ' + hex(D) + ' + (' + i + '×' + cols + ' + ' + j + ')×4 = ' + hex(addr) + '.)', 'dp[' + i + '][' + j + ']: a[' + (i - 1) + '] = \'' + x.ch + '\' เท่ากับ b[' + (j - 1) + '] = \'' + y.ch + '\' ต่อจากแนวทแยง: dp[' + (i - 1) + '][' + (j - 1) + '] + 1 = <b>' + (d + 1) + '</b> (แอดเดรส ' + hex(D) + ' + (' + i + '×' + cols + ' + ' + j + ')×4 = ' + hex(addr) + ')'), { lines: [at('for (int j')] });
          } else {
            const up = sim.r(cell(i - 1, j)), left = sim.r(cell(i, j - 1));
            src = [[i - 1, j], [i, j - 1]];
            sim.w(addr, Math.max(up, left));
            sim.step(at('else dp[i][j] = max'), L('dp[' + i + '][' + j + ']: \'' + x.ch + '\' ≠ \'' + y.ch + '\'. Drop one letter: best of up (' + up + ') and left (' + left + ') = <b>' + Math.max(up, left) + '</b>.', 'dp[' + i + '][' + j + ']: \'' + x.ch + '\' ≠ \'' + y.ch + '\' ทิ้งตัวอักษรหนึ่งตัว: ค่ามากสุดของบน (' + up + ') กับซ้าย (' + left + ') = <b>' + Math.max(up, left) + '</b>'), { lines: [at('for (int j')] });
          }
        }
      }
      ci = cj = null; src = null;
      sim.drop('j'); sim.drop('i');
      // trace back one LCS (view only)
      path = []; let i = n, j = m, s = '';
      while (i > 0 && j > 0) { if (a[i - 1] === b[j - 1]) { path.push([i, j]); s = a[i - 1] + s; i--; j--; } else if (sim.peek(cell(i - 1, j)) >= sim.peek(cell(i, j - 1))) i--; else j--; }
      const ans = sim.r(cell(n, m));
      sim.print(ans + '\n');
      sim.step(at('cout << dp[n][m]'), L('dp[' + n + '][' + m + '] = <b>' + ans + '</b>. Green cells show one common subsequence found by walking back from the corner: "' + s + '". Time and memory: O(n × m).', 'dp[' + n + '][' + m + '] = <b>' + ans + '</b> ช่องสีเขียวแสดงลำดับย่อยร่วมหนึ่งแบบที่ได้จากการเดินย้อนจากมุม: "' + s + '" เวลาและหน่วยความจำ: O(n × m)'));
      sim.ret(0, { show: false });
    }
  });

  // ---------------------------------------------------------------- 0/1 knapsack, 1-D
  const ksCode = (w, v, W) => `int main() {
  int w[${w.length}] = {${w.join(', ')}};   // weights
  int v[${v.length}] = {${v.join(', ')}};   // values
  int dp[${W + 1}] = {};          // dp[c] = best value with capacity c
  for (int k = 0; k < ${w.length}; k++)
    for (int c = ${W}; c >= w[k]; c--)        // right to left!
      dp[c] = max(dp[c], dp[c - w[k]] + v[k]);
  cout << dp[${W}] << "\\n";
}
`;
  const ksParse = p => {
    const w = parseNums(p.w, 5), v = parseNums(p.v, 5), W = parseNums(p.W, 1)[0];
    if (!w.length || w.length !== v.length) throw userErr(L('Give the same number of weights and values (1 to 5).', 'ใส่น้ำหนักและมูลค่าจำนวนเท่ากัน (1 ถึง 5)'));
    if (w.some(x => x < 1 || x > 10)) throw userErr(L('Weights must be 1 to 10.', 'น้ำหนักต้องอยู่ระหว่าง 1 ถึง 10'));
    if (!(W >= 1 && W <= 10)) throw userErr(L('Capacity must be 1 to 10.', 'ความจุต้องอยู่ระหว่าง 1 ถึง 10'));
    return { w, v, W };
  };
  def({
    id: 'knapsack', part: 3, lesson: '15', lessonFile: '15-dp-states.md',
    title: L('0/1 knapsack with one row', '0/1 knapsack ด้วยแถวเดียว'),
    summary: L('dp[c] = the best value that fits in capacity c using the items seen so far. For each item we sweep c from right to left, so dp[c − w] still holds the value from before this item: every item is used at most once. Sweep left to right and you would get the unbounded version by accident.',
      'dp[c] = มูลค่าที่ดีที่สุดที่ใส่ได้ในความจุ c โดยใช้ของที่เห็นมาแล้ว สำหรับของแต่ละชิ้น เรากวาด c จากขวาไปซ้าย dp[c − w] จึงยังเป็นค่าก่อนของชิ้นนี้: ของแต่ละชิ้นใช้ได้ไม่เกินครั้งเดียว ถ้ากวาดซ้ายไปขวาจะได้แบบใช้ซ้ำได้โดยไม่ตั้งใจ'),
    blurb: L('Space-saving DP and why the loop runs backwards.', 'DP แบบประหยัดพื้นที่ และทำไมลูปต้องวิ่งถอยหลัง'),
    params: [{ id: 'w', label: L('weights', 'น้ำหนัก'), value: '2 3 4', w: 110 }, { id: 'v', label: L('values', 'มูลค่า'), value: '3 4 6', w: 110 }, { id: 'W', label: L('capacity', 'ความจุ'), value: '7', w: 60 }],
    paramHint: L('up to 5 items · weights and capacity 1–10', 'ไม่เกิน 5 ชิ้น · น้ำหนักและความจุ 1–10'),
    code: ksCode([2, 3, 4], [3, 4, 6], 7),
    codeFn: p => { try { const { w, v, W } = ksParse(p); return ksCode(w, v, W); } catch (e) { return ksCode([1], [1], 1); } },
    build(sim, prm) {
      const { w, v, W } = ksParse(prm), N = w.length, code = ksCode(w, v, W), at = LN(code);
      let cc = null, from = null, kk = null, hist = [];
      sim.viewFn = S => {
        const dv = mainVar(S, 'dp'); if (!dv) return null;
        const rows = hist.map((h, k) => ({ label: L('after item ' + k, 'หลังชิ้น ' + k), cells: h, cls: h.map(() => 'dim'), w: 40 }));
        rows.push({ label: 'dp', cells: dv.cells.map(fmtPlain), cls: dv.cells.map((_, c) => c === cc ? 'chg' : (c === from ? 'cmp' : (kk != null && c < w[kk] ? 'dim' : ''))), marks: cc != null ? Object.assign({ [cc]: ['c'] }, from != null ? { [from]: ['c−w'] } : {}) : {}, w: 40 });
        return { kind: 'array', title: L('the dp row', 'แถว dp'), cap: kk != null ? L('Item ' + kk + ': weight ' + w[kk] + ', value ' + v[kk] + '. Grey rows are snapshots after earlier items (for comparison only, they are not in memory).', 'ชิ้นที่ ' + kk + ': น้ำหนัก ' + w[kk] + ' มูลค่า ' + v[kk] + ' แถวสีเทาคือภาพหลังของชิ้นก่อน ๆ (ไว้เทียบเท่านั้น ไม่ได้อยู่ในหน่วยความจำ)') : '', rows };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const Wt = sim.arr('w', 'int', N, w), V = sim.arr('v', 'int', N, v);
      sim.step(at('int v['), L(N + ' items. Item k weighs w[k] and is worth v[k].', 'ของ ' + N + ' ชิ้น ชิ้นที่ k หนัก w[k] และมีมูลค่า v[k]'), { lines: [at('int w[')] });
      const D = sim.arr('dp', 'int', W + 1, 0);
      sim.step(at('int dp['), L('One row of ' + (W + 1) + ' ints, all 0: with no items, every capacity is worth 0.', 'แถวเดียว int ' + (W + 1) + ' ตัว เป็น 0 ทั้งหมด: ยังไม่มีของ ทุกความจุมีมูลค่า 0'));
      const kA = sim.local('k', 'int', 0), cA = sim.local('c', 'int', W);
      for (let k = 0; k < N; k++) {
        sim.w(kA, k); kk = k;
        for (let c = W; c >= w[k]; c--) {
          sim.w(cA, c); cc = c; from = c - w[k];
          sim.r(Wt + 4 * k);
          const keep = sim.r(D + 4 * c), take = sim.r(D + 4 * (c - w[k])) + sim.r(V + 4 * k);
          sim.w(D + 4 * c, Math.max(keep, take));
          sim.step(at('dp[c] = max('), L('c = ' + c + ': skip item ' + k + ' → ' + keep + ', or take it → dp[' + (c - w[k]) + '] + ' + v[k] + ' = ' + take + '. dp[' + c + '] = <b>' + Math.max(keep, take) + '</b>. dp[' + (c - w[k]) + '] was not touched yet for this item, so it does not already include item ' + k + '.', 'c = ' + c + ': ไม่เอาชิ้น ' + k + ' → ' + keep + ' หรือเอา → dp[' + (c - w[k]) + '] + ' + v[k] + ' = ' + take + ' dp[' + c + '] = <b>' + Math.max(keep, take) + '</b> dp[' + (c - w[k]) + '] ยังไม่ถูกแตะในรอบของชิ้นนี้ จึงยังไม่รวมชิ้น ' + k), { lines: [at('for (int c')] });
        }
        cc = from = null;
        hist.push(sim.top().vars.find(x => x.name === 'dp').cells.map(fmtPlain));
        sim.step(at('for (int c'), L('c &lt; w[' + k + '] = ' + w[k] + ': smaller capacities cannot hold item ' + k + ', so they keep their old values. Item ' + k + ' is done.', 'c &lt; w[' + k + '] = ' + w[k] + ': ความจุที่เล็กกว่าใส่ชิ้น ' + k + ' ไม่ได้ จึงคงค่าเดิม ชิ้น ' + k + ' เสร็จ'));
      }
      kk = null; sim.drop('c'); sim.drop('k');
      const ans = sim.r(D + 4 * W); sim.print(ans + '\n');
      sim.step(at('cout << dp['), L('Best value with capacity ' + W + ': <b>' + ans + '</b>. Memory O(W) instead of O(N × W).', 'มูลค่าดีที่สุดที่ความจุ ' + W + ': <b>' + ans + '</b> หน่วยความจำ O(W) แทน O(N × W)'));
      sim.ret(0, { show: false });
    }
  });
})();
