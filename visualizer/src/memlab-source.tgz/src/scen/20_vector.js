/* Part II · CP::vector (real code from vector.h in the course folder) */

const VEC_CLASS = `namespace CP {
template <typename T>
class vector {
  public:
    typedef T* iterator;
  protected:
    T *mData;
    size_t mCap;
    size_t mSize;

    void expand(size_t capacity) {
      T *arr = new T[capacity]();
      for (size_t i = 0;i < mSize;i++) {
        arr[i] = mData[i];
      }
      delete [] mData;
      mData = arr;
      mCap = capacity;
    }
    void ensureCapacity(size_t capacity) {
      if (capacity > mCap) {
        size_t s = (capacity > 2 * mCap) ? capacity : 2 * mCap;
        expand(s);
      }
    }
  public:
    vector() {
      int cap = 1;
      mData = new T[cap]();
      mCap = cap;
      mSize = 0;
    }
    ~vector() { delete [] mData; }
    iterator begin() { return &mData[0]; }
    iterator end() { return begin()+mSize; }
    T& operator[](int index) { return mData[index]; }
    void push_back(const T& element) {
      insert(end(),element);
    }
    void pop_back() {
      mSize--;
    }
    iterator insert(iterator it,const T& element) {
      size_t pos = it - begin();
      ensureCapacity(mSize + 1);
      for(size_t i = mSize;i > pos;i--) {
        mData[i] = mData[i-1];
      }
      mData[pos] = element;
      mSize++;
      return begin()+pos;
    }
    void erase(iterator it) {
      while((it+1)!=end()) {
        *it = *(it+1);
        it++;
      }
      mSize--;
    }
};
}
int main() {
  CP::vector<int> v;
`;

function parseVecOps(str) {
  const ops = parseOps(str, 14).map(o => {
    const n = o[0];
    if (['push_back', 'push', 'pb'].includes(n)) { if (typeof o[1] !== 'number') throw userErr(L('push_back needs a number, e.g. "push_back 7".', 'push_back ต้องมีตัวเลข เช่น "push_back 7"')); return ['push_back', o[1]]; }
    if (['pop_back', 'pop'].includes(n)) return ['pop_back'];
    if (n === 'insert') { if (typeof o[1] !== 'number' || typeof o[2] !== 'number') throw userErr(L('insert needs a position and a value, e.g. "insert 1 99".', 'insert ต้องมีตำแหน่งและค่า เช่น "insert 1 99"')); return ['insert', o[1], o[2]]; }
    if (n === 'erase') { if (typeof o[1] !== 'number') throw userErr(L('erase needs a position, e.g. "erase 0".', 'erase ต้องมีตำแหน่ง เช่น "erase 0"')); return ['erase', o[1]]; }
    if (n === 'set') { if (typeof o[1] !== 'number' || typeof o[2] !== 'number') throw userErr(L('set needs an index and a value, e.g. "set 0 5".', 'set ต้องมีดัชนีและค่า เช่น "set 0 5"')); return ['set', o[1], o[2]]; }
    if (n === 'keep') { if (typeof o[1] !== 'number') throw userErr(L('keep needs an index, e.g. "keep 0".', 'keep ต้องมีดัชนี เช่น "keep 0"')); return ['keep', o[1]]; }
    throw userErr(L('Unknown operation "' + n + '". Use push_back, pop_back, insert, erase, set, keep.', 'ไม่รู้จักคำสั่ง "' + n + '" ใช้ได้: push_back, pop_back, insert, erase, set, keep'));
  });
  if (!ops.length) throw userErr(L('Type at least one operation.', 'ใส่คำสั่งอย่างน้อยหนึ่งคำสั่ง'));
  if (ops.filter(o => o[0] === 'keep').length > 1) throw userErr(L('Use keep at most once.', 'ใช้ keep ได้ครั้งเดียว'));
  return ops;
}
function vecOpLine(o) {
  switch (o[0]) {
    case 'push_back': return '  v.push_back(' + o[1] + ');';
    case 'pop_back': return '  v.pop_back();';
    case 'insert': return '  v.insert(v.begin() + ' + o[1] + ', ' + o[2] + ');';
    case 'erase': return '  v.erase(v.begin() + ' + o[1] + ');';
    case 'set': return '  v[' + o[1] + '] = ' + o[2] + ';';
    case 'keep': return '  int* p = &v[' + o[1] + '];   // keep a pointer into the buffer';
  }
}
function vecCode(ops) { return VEC_CLASS + ops.map(vecOpLine).join('\n') + '\n}   // v is destroyed here\n'; }

function vectorScenario(cfg) {
  def({
    id: cfg.id, part: 2, lesson: '03', lessonFile: '03-cp-vector.md', dangOK: true,
    title: cfg.title, summary: cfg.summary, blurb: cfg.blurb,
    params: [{ id: 'ops', label: L('Operations (comma separated)', 'คำสั่ง (คั่นด้วยจุลภาค)'), value: cfg.ops }],
    paramHint: L('push_back x · pop_back · insert pos x · erase pos · set i x · keep i (declares int* p = &v[i] so you can watch it break when the buffer moves)',
      'push_back x · pop_back · insert pos x · erase pos · set i x · keep i (ประกาศ int* p = &v[i] เพื่อดูว่ามันพังเมื่อบัฟเฟอร์ย้ายที่)'),
    code: vecCode(parseVecOps(cfg.ops)),
    codeFn: p => { try { return vecCode(parseVecOps(p.ops)); } catch (e) { return VEC_CLASS + '}\n'; } },
    build(sim, prm) {
      const ops = parseVecOps(prm.ops);
      const code = vecCode(ops), at = LN(code);
      const mainL = at('int main'), opL = k => mainL + 2 + k;
      let v, keepP = null;
      const F = n => sim.pf(v, n);
      const buf = () => F('mData').p;
      const sync = () => { const b = sim.block(buf()); if (b) { b.used = F('mSize'); b.label = L('v.mData buffer · mCap = ' + F('mCap'), 'บัฟเฟอร์ของ v.mData · mCap = ' + F('mCap')); } };
      const fn = s => 'vector<int>::' + s;

      sim.viewFn = s => {
        if (!v) return null;
        const mD = s.pf(v, 'mData'), mS = s.pf(v, 'mSize'), mC = s.pf(v, 'mCap');
        if (!isP(mD) || mD.p === 0) return null;
        const b = s.heap.find(x => x.addr === mD.p);
        if (!b) return null;
        const marks = {}, mk = (k, l) => { (marks[k] = marks[k] || []).push(l); };
        const top = s.top();
        const rows = [];
        if (top && top.sig !== 'main()') {
          for (const x of top.vars) {
            if ((x.name === 'pos' || x.name === 'i') && typeof x.value === 'number') mk(x.value, x.name);
            if (x.name === 'it' && isP(x.value) && x.value.p >= b.addr && x.value.p <= b.addr + b.size) mk((x.value.p - b.addr) / 4, 'it');
          }
        }
        if (mS != null && !marks[mS]) mk(mS, 'mSize');
        rows.push({ label: 'mData', cells: b.cells.map(c => fmtPlain(c)), cls: b.cells.map((c, i) => i < mS ? 'hp' : 'dim'), marks });
        const arr = top && top.vars.find(x => x.name === 'arr');
        if (arr && isP(arr.value)) {
          const nb = s.heap.find(x => x.addr === arr.value.p);
          if (nb) { const m2 = {}; const iv = top.vars.find(x => x.name === 'i'); if (iv) m2[iv.value] = ['i']; rows.push({ label: 'arr (new)', cells: nb.cells.map(c => fmtPlain(c)), cls: nb.cells.map((c, i) => iv && i < iv.value ? 'ok' : 'dim'), marks: m2 }); }
        }
        return { kind: 'array', title: L('logical view', 'มุมมองเชิงตรรกะ'), cap: L('mSize = ' + mS + ' · mCap = ' + mC + '. Amber cells hold elements; grey cells are allocated but unused.', 'mSize = ' + mS + ' · mCap = ' + mC + ' ช่องสีอำพันคือข้อมูลจริง ช่องสีเทาคือจองไว้แต่ยังไม่ใช้'), rows };
      };

      sim.call('main()');
      sim.step(mainL, L('main starts.', 'main เริ่มทำงาน'));
      v = sim.obj('v', 'CP::vector<int>', [['mData', 'int*', undefined], ['mCap', 'size_t', undefined], ['mSize', 'size_t', undefined]]);
      sim.step(mainL + 1, L(
        '<code>CP::vector&lt;int&gt; v;</code> reserves <b>24 bytes</b> in main\'s frame for the three fields. This small object is <i>all</i> of v that lives on the stack; the elements will live on the heap.',
        '<code>CP::vector&lt;int&gt; v;</code> จอง <b>24 ไบต์</b> ในเฟรมของ main สำหรับฟิลด์ทั้งสาม อ็อบเจกต์เล็ก ๆ นี้คือส่วน<i>ทั้งหมด</i>ของ v ที่อยู่บน stack ข้อมูลจริงจะอยู่บน heap'));
      sim.call(fn('vector()'));
      sim.param('this', 'vector*', P(v));
      const capA = sim.local('cap', 'int', 1);
      sim.step(at('int cap = 1'), L('The default constructor runs with this = &v. It starts with capacity 1.', 'คอนสตรักเตอร์ปริยายทำงานโดย this = &v เริ่มด้วยความจุ 1'));
      const b0 = sim.newArray('int', 1, 0, { used: 0, expr: 'new int[1]()' });
      sim.wf(v, 'mData', P(b0));
      sim.step(at('mData = new T[cap]()'), L('Allocate a 1-slot buffer on the heap and store its address in <code>mData</code>.', 'จองบัฟเฟอร์ 1 ช่องบน heap แล้วเก็บแอดเดรสไว้ใน <code>mData</code>'));
      sim.wf(v, 'mCap', 1); sim.step(at('mCap = cap'), L('mCap = 1.', 'mCap = 1'));
      sim.wf(v, 'mSize', 0); sync(); sim.step(at('mSize = 0'), L('mSize = 0: one slot allocated, zero elements stored. That slot is shown hatched (unused).', 'mSize = 0: จองไว้ 1 ช่อง แต่ยังไม่มีข้อมูล ช่องนั้นจึงแสดงเป็นลายขีด (ยังไม่ใช้)'));
      sim.ret(undefined, { show: false });
      sim.step(mainL + 1, L('v is ready.', 'v พร้อมใช้งาน'));

      const ensure = (need) => {
        sim.call(fn('ensureCapacity(size_t capacity)'));
        sim.param('this', 'vector*', P(v)); sim.param('capacity', 'size_t', need);
        const cap = sim.rf(v, 'mCap');
        if (need <= cap) {
          sim.step(at('if (capacity > mCap)'), L('Is ' + need + ' &gt; mCap (' + cap + ')? No: there is room, nothing to do.', '' + need + ' &gt; mCap (' + cap + ') หรือไม่? ไม่: ยังมีที่ว่าง ไม่ต้องทำอะไร'));
          sim.ret(undefined, { show: false });
          return false;
        }
        sim.step(at('if (capacity > mCap)'), L('Is ' + need + ' &gt; mCap (' + cap + ')? <b>Yes</b>: the buffer is full and must grow.', '' + need + ' &gt; mCap (' + cap + ') หรือไม่? <b>ใช่</b>: บัฟเฟอร์เต็มแล้ว ต้องขยาย'));
        const s = need > 2 * cap ? need : 2 * cap;
        sim.local('s', 'size_t', s);
        sim.step(at('size_t s ='), L('New capacity = max(' + need + ', 2 × ' + cap + ') = <b>' + s + '</b>. Doubling is what makes push_back amortized O(1): copies cost 1 + 2 + 4 + … &lt; 2n in total.', 'ความจุใหม่ = max(' + need + ', 2 × ' + cap + ') = <b>' + s + '</b> การขยายเป็นสองเท่าทำให้ push_back เป็น O(1) แบบเฉลี่ย: การคัดลอกรวมทั้งหมด 1 + 2 + 4 + … &lt; 2n'));
        sim.call(fn('expand(size_t capacity)'));
        sim.param('this', 'vector*', P(v)); sim.param('capacity', 'size_t', s);
        const old = buf();
        const nb = sim.newArray('int', s, 0, { expr: 'new int[' + s + ']()', label: L('arr: the new buffer', 'arr: บัฟเฟอร์ใหม่'), used: 0 });
        sim.local('arr', 'int*', P(nb));
        sim.step(at('T *arr = new T[capacity]()'), L('Allocate a brand-new buffer of ' + s + ' ints at ' + hex(nb) + '. A heap block can never be stretched in place, so growing always means <b>allocate, copy, free</b>.', 'จองบัฟเฟอร์ใหม่ ' + s + ' ช่องที่ ' + hex(nb) + ' บล็อกบน heap ยืดออกในที่เดิมไม่ได้ การขยายจึงต้อง<b>จองใหม่ คัดลอก แล้วคืนของเก่า</b>เสมอ'));
        const n = sim.rf(v, 'mSize');
        const ia = sim.local('i', 'size_t', 0);
        for (let k = 0; k < n; k++) {
          sim.w(ia, k);
          const val = sim.r(old + 4 * k); sim.w(nb + 4 * k, val);
          const blk = sim.block(nb); blk.used = k + 1;
          sim.step(at('arr[i] = mData[i]'), L('i = ' + k + ': copy ' + val + ' from the old buffer to arr[' + k + '].', 'i = ' + k + ': คัดลอก ' + val + ' จากบัฟเฟอร์เก่าไป arr[' + k + ']'));
        }
        sim.drop('i');
        sim.r(sim.f(v, 'mData')); sim.free(old);
        sim.step(at('delete [] mData'), L('Free the old buffer. For a moment v.mData points at freed memory (red), and so does <b>any pointer or iterator</b> into the old buffer.', 'คืนบัฟเฟอร์เก่า ชั่วขณะหนึ่ง v.mData ชี้ไปยังหน่วยความจำที่ถูกคืนแล้ว (สีแดง) รวมถึง<b>พอยน์เตอร์หรือ iterator ใด ๆ</b> ที่ชี้เข้าไปในบัฟเฟอร์เก่าด้วย'));
        sim.wf(v, 'mData', P(nb));
        sim.step(at('mData = arr'), L('Point mData at the new buffer.', 'ให้ mData ชี้ไปที่บัฟเฟอร์ใหม่'));
        sim.wf(v, 'mCap', s); sync();
        sim.step(at('mCap = capacity'), L('mCap = ' + s + '. Growth done: same elements, new home.', 'mCap = ' + s + ' ขยายเสร็จ: ข้อมูลเดิม บ้านใหม่'));
        sim.ret(undefined, { show: false });
        sim.ret(undefined, { show: false });
        return true;
      };

      const insert = (pos, val, tempA, viaPush) => {
        sim.call(fn('insert(iterator it, const T& element)'));
        sim.param('this', 'vector*', P(v));
        const itA = sim.param('it', 'int*', P(buf() + 4 * pos));
        sim.ref('element', 'const int', tempA, { param: true });
        sim.step(at('iterator insert'), L('insert receives <code>it</code> = ' + hex(buf() + 4 * pos) + ', a raw pointer into the buffer (an iterator <i>is</i> a T*).', 'insert ได้รับ <code>it</code> = ' + hex(buf() + 4 * pos) + ' ซึ่งเป็นพอยน์เตอร์ดิบที่ชี้เข้าไปในบัฟเฟอร์ (iterator <i>คือ</i> T*)'));
        sim.r(itA);
        const posA = sim.local('pos', 'size_t', pos);
        sim.step(at('size_t pos = it - begin()'), L('<b>Convert the iterator to an index first</b>: pos = (it − begin()) = ' + pos + '. The next line may move the buffer, and an index survives that while a pointer does not.', '<b>แปลง iterator เป็นดัชนีก่อน</b>: pos = (it − begin()) = ' + pos + ' บรรทัดถัดไปอาจย้ายบัฟเฟอร์ ดัชนียังใช้ได้หลังย้าย แต่พอยน์เตอร์ใช้ไม่ได้'));
        const grew = ensure(sim.pf(v, 'mSize') + 1);
        sim.step(at('ensureCapacity(mSize + 1)'), grew
          ? L('Back in insert. Look at <code>it</code>: it still holds the <b>old</b> address and is now dangling. That is why the code uses <code>pos</code> from here on.', 'กลับมาที่ insert ดู <code>it</code>: มันยังเก็บแอดเดรส<b>เก่า</b> และตอนนี้ห้อยแล้ว นี่คือเหตุผลที่โค้ดใช้ <code>pos</code> ต่อจากนี้')
          : L('Back in insert. There was room, so the buffer did not move.', 'กลับมาที่ insert มีที่ว่างพอ บัฟเฟอร์จึงไม่ย้าย'));
        const n = sim.rf(v, 'mSize');
        const ia = sim.local('i', 'size_t', n);
        if (n === pos) sim.step(at('for(size_t i = mSize'), L('i = mSize = ' + n + ', and i &gt; pos is false at once: inserting at the end shifts nothing. That is why push_back is cheap.', 'i = mSize = ' + n + ' และ i &gt; pos เป็นเท็จทันที การแทรกท้ายสุดไม่ต้องเลื่อนอะไร push_back จึงถูก'));
        for (let k = n; k > pos; k--) {
          sim.w(ia, k);
          const b = buf(); const x = sim.r(b + 4 * (k - 1)); sim.w(b + 4 * k, x);
          sim.step(at('mData[i] = mData[i-1]'), L('i = ' + k + ': shift right, mData[' + k + '] = mData[' + (k - 1) + '] = ' + x + '. Walking from the back means we never overwrite a value we still need.', 'i = ' + k + ': เลื่อนไปทางขวา mData[' + k + '] = mData[' + (k - 1) + '] = ' + x + ' การเดินจากท้ายมาหน้าทำให้ไม่เขียนทับค่าที่ยังต้องใช้'));
        }
        if (n > pos) { sim.w(ia, pos); sim.step(at('for(size_t i = mSize'), L('i = ' + pos + ': i &gt; pos is false, stop. ' + (n - pos) + ' element(s) moved: inserting at position p costs O(n − p).', 'i = ' + pos + ': i &gt; pos เป็นเท็จ หยุด เลื่อนไป ' + (n - pos) + ' ตัว การแทรกที่ตำแหน่ง p ใช้เวลา O(n − p)')); }
        sim.drop('i');
        sim.r(posA); sim.r(tempA); sim.w(buf() + 4 * pos, val);
        sim.step(at('mData[pos] = element'), L('Write ' + val + ' into the gap at mData[' + pos + '].', 'เขียน ' + val + ' ลงช่องว่างที่ mData[' + pos + ']'));
        sim.wf(v, 'mSize', n + 1); sync();
        sim.step(at('mSize++'), L('mSize = ' + (n + 1) + '.', 'mSize = ' + (n + 1)));
        sim.step(at('return begin()+pos'), L('Return a <i>fresh</i> iterator begin() + pos, computed from the current buffer.', 'คืน iterator <i>ตัวใหม่</i> begin() + pos ที่คำนวณจากบัฟเฟอร์ปัจจุบัน'));
        sim.ret(P(buf() + 4 * pos), { type: 'int*', show: !viaPush });
      };

      const withTemp = (val, body) => { const t = sim.local('temp', 'int', val); body(t); sim.drop('temp'); };

      ops.forEach((o, k) => {
        const L0 = opL(k);
        const size = sim.pf(v, 'mSize');
        if (o[0] === 'push_back') {
          withTemp(o[1], t => {
            sim.step(L0, L('<code>v.push_back(' + o[1] + ')</code>: the literal ' + o[1] + ' is put in a temporary box so it can be passed by reference.', '<code>v.push_back(' + o[1] + ')</code>: ค่า ' + o[1] + ' ถูกใส่ในกล่องชั่วคราวเพื่อส่งแบบ reference ได้'));
            sim.call(fn('push_back(const T& element)'));
            sim.param('this', 'vector*', P(v)); sim.ref('element', 'const int', t, { param: true });
            sim.step(at('void push_back'), L('push_back is one line: insert at end().', 'push_back มีแค่บรรทัดเดียว: insert ที่ end()'));
            sim.rf(v, 'mData'); sim.rf(v, 'mSize');
            sim.step(at('insert(end(),element)'), L('end() = begin() + mSize = ' + hex(buf()) + ' + ' + size + '×4 = ' + hex(buf() + 4 * size) + '.', 'end() = begin() + mSize = ' + hex(buf()) + ' + ' + size + '×4 = ' + hex(buf() + 4 * size)));
            insert(size, o[1], t, true);
            sim.step(at('insert(end(),element)'), L('insert returned.', 'insert คืนค่าแล้ว'));
            sim.ret(undefined, { show: false });
          });
          sim.step(L0, L('Done: v = [' + cellsOf(sim, buf()).slice(0, sim.pf(v, 'mSize')).join(', ') + '], mSize = ' + sim.pf(v, 'mSize') + ', mCap = ' + sim.pf(v, 'mCap') + '. The temporary is gone.', 'เสร็จ: v = [' + cellsOf(sim, buf()).slice(0, sim.pf(v, 'mSize')).join(', ') + '] mSize = ' + sim.pf(v, 'mSize') + ', mCap = ' + sim.pf(v, 'mCap') + ' กล่องชั่วคราวหายไปแล้ว'));
        } else if (o[0] === 'insert') {
          if (o[1] < 0 || o[1] > size) throw userErr(L('insert position ' + o[1] + ' is outside 0…' + size + ' (the current size).', 'ตำแหน่ง insert ' + o[1] + ' อยู่นอกช่วง 0…' + size + ' (ขนาดปัจจุบัน)'));
          withTemp(o[2], t => {
            sim.step(L0, L('<code>v.begin() + ' + o[1] + '</code> = ' + hex(buf() + 4 * o[1]) + ' is computed in main, and ' + o[2] + ' goes into a temporary.', '<code>v.begin() + ' + o[1] + '</code> = ' + hex(buf() + 4 * o[1]) + ' ถูกคำนวณใน main และ ' + o[2] + ' ใส่ในกล่องชั่วคราว'));
            insert(o[1], o[2], t, false);
          });
          sim.step(L0, L('Done: v = [' + cellsOf(sim, buf()).slice(0, sim.pf(v, 'mSize')).join(', ') + '].', 'เสร็จ: v = [' + cellsOf(sim, buf()).slice(0, sim.pf(v, 'mSize')).join(', ') + ']'));
        } else if (o[0] === 'erase') {
          if (o[1] < 0 || o[1] >= size) throw userErr(L('erase position ' + o[1] + ' is outside 0…' + (size - 1) + '.', 'ตำแหน่ง erase ' + o[1] + ' อยู่นอกช่วง 0…' + (size - 1)));
          sim.step(L0, L('<code>v.erase(v.begin() + ' + o[1] + ')</code>.', '<code>v.erase(v.begin() + ' + o[1] + ')</code>'));
          sim.call(fn('erase(iterator it)'));
          sim.param('this', 'vector*', P(v));
          const itA = sim.param('it', 'int*', P(buf() + 4 * o[1]));
          sim.step(at('void erase'), L('erase gets <code>it</code> pointing at element ' + o[1] + '.', 'erase ได้ <code>it</code> ที่ชี้ไปยังสมาชิกตัวที่ ' + o[1]));
          for (let j = o[1]; j + 1 < size; j++) {
            const b = buf();
            sim.r(itA);
            sim.step(at('while((it+1)!=end())'), L('it + 1 = ' + hex(b + 4 * (j + 1)) + ' is not end() (' + hex(b + 4 * size) + '), so keep shifting.', 'it + 1 = ' + hex(b + 4 * (j + 1)) + ' ยังไม่ใช่ end() (' + hex(b + 4 * size) + ') จึงเลื่อนต่อ'));
            const x = sim.r(b + 4 * (j + 1)); sim.w(b + 4 * j, x);
            sim.step(at('*it = *(it+1)'), L('Copy the right neighbour left: mData[' + j + '] = ' + x + '.', 'คัดลอกเพื่อนบ้านทางขวามาทางซ้าย: mData[' + j + '] = ' + x));
            sim.w(itA, P(b + 4 * (j + 1)));
            sim.step(at('it++;'), L('it moves one int (4 bytes) right.', 'it เลื่อนไปทางขวาหนึ่ง int (4 ไบต์)'));
          }
          sim.r(itA);
          sim.step(at('while((it+1)!=end())'), L('it + 1 == end(): stop. The old last value is still physically there, but it will no longer count.', 'it + 1 == end(): หยุด ค่าตัวสุดท้ายเดิมยังอยู่ในหน่วยความจำจริง แต่จะไม่ถูกนับแล้ว'));
          sim.wf(v, 'mSize', size - 1); sync();
          sim.step(at('mSize--;', 2), L('mSize = ' + (size - 1) + '. Erasing at position p costs O(n − p) shifts; the capacity never shrinks.', 'mSize = ' + (size - 1) + ' การลบที่ตำแหน่ง p ต้องเลื่อน O(n − p) ครั้ง ความจุไม่เคยลดลง'));
          sim.ret(undefined, { show: false });
          sim.step(L0, L('Done: v = [' + cellsOf(sim, buf()).slice(0, sim.pf(v, 'mSize')).join(', ') + '].', 'เสร็จ: v = [' + cellsOf(sim, buf()).slice(0, sim.pf(v, 'mSize')).join(', ') + ']'));
        } else if (o[0] === 'pop_back') {
          if (size === 0) throw userErr(L('pop_back on an empty vector: mSize is size_t, so 0 − 1 would wrap around to 18446744073709551615. The real CP::vector does not check this!', 'pop_back ตอน vector ว่าง: mSize เป็น size_t ดังนั้น 0 − 1 จะวนกลายเป็น 18446744073709551615 CP::vector ตัวจริงไม่ได้ตรวจกรณีนี้!'));
          sim.step(L0, L('<code>v.pop_back()</code>.', '<code>v.pop_back()</code>'));
          sim.call(fn('pop_back()')); sim.param('this', 'vector*', P(v));
          sim.wf(v, 'mSize', size - 1); sync();
          sim.step(at('mSize--;', 1), L('pop_back only does <code>mSize--</code>. The value ' + fmtPlain(sim.peek(buf() + 4 * (size - 1))) + ' is not erased from memory; it just stops counting as an element. O(1).', 'pop_back ทำแค่ <code>mSize--</code> ค่า ' + fmtPlain(sim.peek(buf() + 4 * (size - 1))) + ' ไม่ได้ถูกลบออกจากหน่วยความจำ แค่ไม่ถูกนับเป็นสมาชิกแล้ว O(1)'));
          sim.ret(undefined, { show: false });
          sim.step(L0, L('Done: v = [' + cellsOf(sim, buf()).slice(0, size - 1).join(', ') + '].', 'เสร็จ: v = [' + cellsOf(sim, buf()).slice(0, size - 1).join(', ') + ']'));
        } else if (o[0] === 'set') {
          if (o[1] < 0 || o[1] >= size) throw userErr(L('index ' + o[1] + ' is outside 0…' + (size - 1) + '. operator[] does not check bounds, so this would be undefined behaviour.', 'ดัชนี ' + o[1] + ' อยู่นอกช่วง 0…' + (size - 1) + ' operator[] ไม่ตรวจขอบเขต จึงเป็น undefined behaviour'));
          sim.rf(v, 'mData'); sim.w(buf() + 4 * o[1], o[2]);
          sim.step(L0, L('<code>v[' + o[1] + ']</code> returns a <b>reference</b> to mData[' + o[1] + '] at ' + hex(buf() + 4 * o[1]) + ', and we write ' + o[2] + ' through it. O(1).', '<code>v[' + o[1] + ']</code> คืน <b>reference</b> ไปยัง mData[' + o[1] + '] ที่ ' + hex(buf() + 4 * o[1]) + ' แล้วเราเขียน ' + o[2] + ' ผ่านมัน O(1)'));
        } else if (o[0] === 'keep') {
          if (o[1] < 0 || o[1] >= size) throw userErr(L('keep index must be inside 0…' + (size - 1) + '.', 'ดัชนีของ keep ต้องอยู่ในช่วง 0…' + (size - 1)));
          keepP = sim.local('p', 'int*', P(buf() + 4 * o[1]));
          sim.step(L0, L('<code>p</code> stores the address ' + hex(buf() + 4 * o[1]) + ' of v[' + o[1] + ']. Fine for now. Watch what happens to p the next time the vector has to grow.', '<code>p</code> เก็บแอดเดรส ' + hex(buf() + 4 * o[1]) + ' ของ v[' + o[1] + '] ตอนนี้ยังใช้ได้ ดูว่าจะเกิดอะไรกับ p ครั้งถัดไปที่ vector ต้องขยาย'));
        }
      });
      const endL = opL(ops.length);
      sim.step(endL, L('End of main. v holds [' + cellsOf(sim, buf()).slice(0, sim.pf(v, 'mSize')).join(', ') + '] with mSize = ' + sim.pf(v, 'mSize') + ' and mCap = ' + sim.pf(v, 'mCap') + '.' + (keepP ? ' Is p still pointing at a live buffer? If it is red, any *p would be undefined behaviour.' : ''), 'จบ main v เก็บ [' + cellsOf(sim, buf()).slice(0, sim.pf(v, 'mSize')).join(', ') + '] โดย mSize = ' + sim.pf(v, 'mSize') + ' และ mCap = ' + sim.pf(v, 'mCap') + (keepP ? ' p ยังชี้ไปยังบัฟเฟอร์ที่ใช้ได้อยู่ไหม? ถ้าเป็นสีแดง การใช้ *p คือ undefined behaviour' : '')));
      sim.call(fn('~vector()')); sim.param('this', 'vector*', P(v));
      sim.free(buf());
      sim.step(at('~vector()'), L('The destructor runs automatically when v goes out of scope: <code>delete [] mData</code>. No leak, and you never wrote delete yourself.', 'destructor ทำงานอัตโนมัติเมื่อ v หมดขอบเขต: <code>delete [] mData</code> ไม่รั่ว และคุณไม่ต้องเขียน delete เอง'));
      sim.ret(undefined, { show: false });
      sim.ret(0, { show: false });
      sim.step(endL, L('main\'s frame is popped. Everything is cleaned up.', 'เฟรมของ main ถูก pop ทุกอย่างถูกเก็บกวาดเรียบร้อย'));
    }
  });
}

vectorScenario({
  id: 'cp-vector', ops: 'push_back 10, push_back 20, push_back 30, insert 1 15, erase 0, pop_back, push_back 40',
  title: L('CP::vector: push_back, growth, insert, erase', 'CP::vector: push_back, การขยาย, insert, erase'),
  summary: L('The real CP::vector code from your course, running. Watch the 24-byte object on the stack, its buffer on the heap, the doubling growth (allocate, copy, free), and the element shifting inside insert and erase. Type your own operations and press Run.',
    'โค้ด CP::vector ตัวจริงจากคอร์สของคุณกำลังทำงาน ดูอ็อบเจกต์ 24 ไบต์บน stack บัฟเฟอร์บน heap การขยายเป็นสองเท่า (จองใหม่ คัดลอก คืนของเก่า) และการเลื่อนสมาชิกใน insert และ erase ลองพิมพ์คำสั่งของคุณเองแล้วกด Run'),
  blurb: L('mData / mSize / mCap, doubling, shifting. Your own operations.', 'mData / mSize / mCap การขยายสองเท่า การเลื่อนข้อมูล ใส่คำสั่งเองได้')
});
vectorScenario({
  id: 'vector-invalidation', ops: 'push_back 1, push_back 2, keep 0, push_back 3',
  title: L('Iterator invalidation: when the buffer moves', 'Iterator ใช้ไม่ได้: เมื่อบัฟเฟอร์ย้ายที่'),
  summary: L('A pointer or iterator into a vector is only an address inside the current buffer. When push_back has to grow, the whole buffer moves and every old address dangles. This is trap 1 of lesson 03 and the reason insert() converts it to pos first.',
    'พอยน์เตอร์หรือ iterator ที่ชี้เข้าไปใน vector เป็นแค่แอดเดรสในบัฟเฟอร์ปัจจุบัน เมื่อ push_back ต้องขยาย บัฟเฟอร์ทั้งก้อนย้ายที่ และแอดเดรสเก่าทั้งหมดห้อย นี่คือกับดักข้อ 1 ของบทที่ 03 และเป็นเหตุผลที่ insert() แปลงเป็น pos ก่อน'),
  blurb: L('Why pointers into a vector break after it grows.', 'ทำไมพอยน์เตอร์ที่ชี้เข้า vector พังหลังมันขยาย')
});
