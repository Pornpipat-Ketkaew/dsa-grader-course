/* Part III · Kadane (lesson 10), backtracking permutations (lesson 11), memoized Fibonacci (lesson 14) */
(() => {
  const mainVar = (S, nm) => S.frames[0] && S.frames[0].vars.find(q => q.name === nm);

  // ---------------------------------------------------------------- Kadane
  const kdCode = a => `int main() {
  int a[${a.length}] = {${a.join(', ')}};
  int best = a[0], cur = 0;
  for (int i = 0; i < ${a.length}; i++) {
    cur = max(a[i], cur + a[i]);   // extend the run, or restart at i
    best = max(best, cur);
  }
  cout << best << "\\n";
}
`;
  def({
    id: 'kadane', part: 3, lesson: '10', lessonFile: '10-sweep-two-pointers-kadane.md',
    title: L('Kadane: the best subarray in one pass', 'Kadane: subarray ที่ดีที่สุดในรอบเดียว'),
    summary: L('cur is the best sum of a run that ends exactly at i. At each i there are only two choices: extend the previous run, or start fresh at a[i]. best remembers the largest cur ever seen.',
      'cur คือผลรวมที่ดีที่สุดของช่วงที่จบที่ i พอดี ที่แต่ละ i มีแค่สองทางเลือก: ต่อช่วงเดิม หรือเริ่มใหม่ที่ a[i] best จำค่า cur ที่มากที่สุดที่เคยเห็น'),
    blurb: L('Two variables replace an O(n²) search.', 'ตัวแปรสองตัวแทนการค้นหา O(n²)'),
    params: [{ id: 'arr', label: L('Array', 'อาเรย์'), value: '-2 1 -3 4 -1 2 1 -5 4' }],
    paramHint: L('2 to 12 numbers, mix positives and negatives', '2 ถึง 12 ตัว ผสมบวกและลบ'),
    code: kdCode([-2, 1, -3, 4, -1, 2, 1, -5, 4]),
    codeFn: p => { const a = parseNums(p.arr, 12); return kdCode(a.length >= 2 ? a : [1, -1]); },
    build(sim, prm) {
      const a = parseNums(prm.arr, 12);
      if (a.length < 2) throw userErr(L('Give 2 to 12 numbers.', 'ใส่ตัวเลข 2 ถึง 12 ตัว'));
      const n = a.length, code = kdCode(a), at = LN(code);
      let iv = null, runStart = 0, bestR = null;
      sim.viewFn = S => {
        const v = mainVar(S, 'a'); if (!v) return null;
        const ranges = [];
        if (iv != null) ranges.push({ a: runStart, b: iv, label: L('run ending at i (cur)', 'ช่วงที่จบที่ i (cur)') });
        if (bestR) ranges.push({ a: bestR[0], b: bestR[1], label: L('best so far', 'ดีที่สุดจนถึงตอนนี้'), cls: 'ok' });
        return { kind: 'array', title: L('runs', 'ช่วงต่อเนื่อง'), rows: [{ label: 'a', cells: v.cells.map(fmtPlain), cls: v.cells.map((_, k) => k === iv ? 'hl' : (iv != null && k >= runStart && k < iv ? 'cmp' : '')), marks: iv != null ? { [iv]: ['i'] } : {}, ranges }] };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const A = sim.arr('a', 'int', n, a);
      sim.step(at('int a['), L('The input.', 'อินพุต'));
      let best = sim.r(A), cur = 0;
      const bA = sim.local('best', 'int', best), cA = sim.local('cur', 'int', 0);
      bestR = [0, 0];
      sim.step(at('int best ='), L('best starts as a[0] = ' + best + ' (the answer must contain at least one element), cur = 0.', 'best เริ่มที่ a[0] = ' + best + ' (คำตอบต้องมีสมาชิกอย่างน้อยหนึ่งตัว) cur = 0'));
      const iA = sim.local('i', 'int', 0);
      for (let i = 0; i < n; i++) {
        sim.w(iA, i); iv = i;
        const ai = sim.r(A + 4 * i), c0 = sim.r(cA);
        const restart = ai > c0 + ai;
        cur = restart ? ai : c0 + ai; if (restart) runStart = i;
        sim.w(cA, cur);
        sim.step(at('cur = max('), L('i = ' + i + ': extend gives ' + c0 + ' + ' + ai + ' = ' + (c0 + ai) + ', restart gives ' + ai + '. ' + (restart ? '<b>Restart</b>: the old run had a negative sum and would only drag a[' + i + '] down.' : '<b>Extend</b> the run.') + ' cur = ' + cur + '.', 'i = ' + i + ': ต่อช่วงได้ ' + c0 + ' + ' + ai + ' = ' + (c0 + ai) + ' เริ่มใหม่ได้ ' + ai + ' ' + (restart ? '<b>เริ่มใหม่</b>: ช่วงเดิมมีผลรวมติดลบ มีแต่จะดึง a[' + i + '] ลง' : '<b>ต่อ</b>ช่วงเดิม') + ' cur = ' + cur), { lines: [at('for (int i')] });
        const b0 = sim.r(bA);
        if (cur > b0) { best = cur; sim.w(bA, best); bestR = [runStart, i]; }
        sim.step(at('best = max('), cur > b0 ? L('cur = ' + cur + ' beats best = ' + b0 + ', so best = ' + cur + ' (a[' + runStart + '..' + i + ']).', 'cur = ' + cur + ' ชนะ best = ' + b0 + ' best จึงเป็น ' + cur + ' (a[' + runStart + '..' + i + '])') : L('cur = ' + cur + ' does not beat best = ' + b0 + '. Keep best.', 'cur = ' + cur + ' ไม่ชนะ best = ' + b0 + ' คง best ไว้'));
      }
      iv = null; sim.drop('i');
      sim.print(sim.r(bA) + '\n');
      sim.step(at('cout << best'), L('One pass, O(n) time, O(1) extra memory: best = ' + best + '.', 'รอบเดียว เวลา O(n) หน่วยความจำเพิ่ม O(1): best = ' + best));
      sim.ret(0, { show: false });
    }
  });

  // ---------------------------------------------------------------- permutations
  const pmCode = n => `void perm(int pos, int n, int cur[], bool used[]) {
  if (pos == n) {                       // a full permutation is built
    for (int k = 0; k < n; k++) cout << cur[k];
    cout << "\\n";
    return;
  }
  for (int v = 1; v <= n; v++) {
    if (used[v - 1]) continue;          // v is already in cur
    used[v - 1] = true;  cur[pos] = v;  // choose
    perm(pos + 1, n, cur, used);        // explore
    used[v - 1] = false;                // un-choose (backtrack)
  }
}
int main() {
  int cur[${n}];
  bool used[${n}] = {};
  perm(0, ${n}, cur, used);
}
`;
  def({
    id: 'permutations', part: 3, lesson: '11', lessonFile: '11-recursion-backtracking.md',
    title: L('Backtracking: choose, explore, un-choose', 'Backtracking: เลือก สำรวจ ยกเลิก'),
    summary: L('Generate every permutation of 1..n. Each frame fills one position; the arrays cur and used live once in main and are shared by every frame through pointers. The un-choose line puts used[] back exactly as it was, so the next branch starts clean.',
      'สร้างทุกการเรียงสับเปลี่ยนของ 1..n แต่ละเฟรมเติมหนึ่งตำแหน่ง อาเรย์ cur และ used อยู่ใน main ที่เดียวและทุกเฟรมใช้ร่วมกันผ่านพอยน์เตอร์ บรรทัดยกเลิกคืน used[] กลับเหมือนเดิมเป๊ะ กิ่งถัดไปจึงเริ่มแบบสะอาด'),
    blurb: L('Shared state, the undo step, the search tree.', 'สถานะที่ใช้ร่วมกัน ขั้นยกเลิก และต้นไม้การค้นหา'),
    params: [{ id: 'n', label: 'n', value: '3', w: 60 }],
    paramHint: L('n from 1 to 4 (n = 4 is long: 64 calls)', 'n ตั้งแต่ 1 ถึง 4 (n = 4 ยาว: 64 การเรียก)'),
    code: pmCode(3),
    codeFn: p => { const n = parseNums(p.n, 1)[0]; return pmCode(n >= 1 && n <= 4 ? n : 3); },
    build(sim, prm) {
      const n = parseNums(prm.n, 1)[0];
      if (!(n >= 1 && n <= 4)) throw userErr(L('n must be 1 to 4.', 'n ต้องอยู่ระหว่าง 1 ถึง 4'));
      const code = pmCode(n), at = LN(code);
      const tree = {}; let cid = 0, cur = null;
      const setCls = () => { for (const id in tree) tree[id].cls = id === cur ? 'hl' : (tree[id].onStack ? 'cmp' : (tree[id].leaf ? 'ok' : (tree[id].done ? 'dim' : ''))); };
      let pos = null, vSel = null;
      sim.viewFn = S => {
        const C = mainVar(S, 'cur'), U = mainVar(S, 'used'); if (!C) return null;
        return { kind: 'multi', title: L('shared arrays and the search tree', 'อาเรย์ที่ใช้ร่วมกันและต้นไม้การค้นหา'), parts: [
          { kind: 'array', rows: [
            { label: 'cur', cells: C.cells.map((c, k) => c === undefined ? '?' : (pos != null && k > pos ? '(' + c + ')' : c)), cls: C.cells.map((c, k) => pos != null && k === pos ? 'hl' : (pos != null && k < pos ? 'hp' : 'dim')), marks: pos != null && pos < n ? { [pos]: ['pos'] } : (pos === n ? { [n]: ['pos'] } : {}) },
            { label: 'used', cells: U.cells.map(b => b ? 'T' : 'F'), cls: U.cells.map((b, k) => k === vSel - 1 ? 'chg' : (b ? 'cmp' : '')), idx0: 1 }] },
          { kind: 'tree', cap: L('Search tree: each box is one call, labelled with the prefix it has built. Teal = running, violet = waiting on the stack, green = a finished permutation. cur values in brackets are leftovers from an earlier branch (not part of the current prefix).', 'ต้นไม้การค้นหา: แต่ละกล่องคือหนึ่งการเรียก ติดป้ายด้วยส่วนหน้าที่สร้างแล้ว ฟ้าอมเขียว = กำลังทำงาน ม่วง = รอบน stack เขียว = การเรียงที่เสร็จแล้ว ค่า cur ในวงเล็บคือเศษจากกิ่งก่อนหน้า (ไม่ใช่ส่วนหน้าปัจจุบัน)'), nodes: tree, root: 'c1', square: true, gy: 50, gx: n === 4 ? 40 : 52, r: 16 }] };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const C = sim.arr('cur', 'int', n, undefined);
      sim.step(at('int cur['), L('<code>cur</code> will hold the permutation being built. It starts as garbage, which is fine: we always write a box before reading it.', '<code>cur</code> จะเก็บการเรียงที่กำลังสร้าง เริ่มเป็นค่าขยะ ซึ่งไม่เป็นไร เพราะเราเขียนก่อนอ่านเสมอ'));
      const U = sim.arr('used', 'bool', n, false);
      sim.step(at('bool used['), L('<code>used[v-1]</code> says whether v is already in cur. <code>= {}</code> sets all to false. Each bool is 1 byte.', '<code>used[v-1]</code> บอกว่า v อยู่ใน cur แล้วหรือยัง <code>= {}</code> ตั้งทุกตัวเป็น false bool แต่ละตัวใช้ 1 ไบต์'));
      let count = 0, calls = 0;
      const rec = (p, parent, prefix, callLine) => {
        const id = 'c' + (++cid); calls++;
        tree[id] = { label: prefix || '·', kids: [], onStack: true, leaf: p === n };
        if (parent) tree[parent].kids.push(id);
        const prevCur = cur, prevPos = pos; cur = id; pos = p; setCls();
        sim.top().line = callLine;
        sim.call('perm(int pos, int n, int cur[], bool used[])');
        sim.param('pos', 'int', p); sim.param('n', 'int', n); sim.param('cur', 'int*', P(C)); sim.param('used', 'bool*', P(U));
        sim.step(at('void perm'), p === 0
          ? L('perm(0): the first frame. cur and used arrive as <b>pointers</b> into main, so every frame will read and write the same two arrays.', 'perm(0): เฟรมแรก cur และ used มาเป็น<b>พอยน์เตอร์</b>ชี้เข้า main ทุกเฟรมจึงอ่านเขียนอาเรย์สองตัวเดียวกัน')
          : L('perm(' + p + '): the prefix so far is ' + prefix + '. This frame decides cur[' + p + '].', 'perm(' + p + '): ส่วนหน้าตอนนี้คือ ' + prefix + ' เฟรมนี้จะตัดสิน cur[' + p + ']'));
        if (p === n) {
          let s = ''; for (let k = 0; k < n; k++) s += sim.r(C + 4 * k);
          sim.print(s + '\n'); count++;
          sim.step(at('for (int k = 0; k < n'), L('pos == n: cur holds a full permutation. Print <b>' + s + '</b> (#' + count + ').', 'pos == n: cur มีการเรียงครบแล้ว พิมพ์ <b>' + s + '</b> (ลำดับที่ ' + count + ')'), { lines: [at('if (pos == n)')] });
          tree[id].onStack = false; tree[id].done = true;
          sim.ret(undefined, { show: false }); cur = prevCur; pos = prevPos; setCls(); return;
        }
        const vA = sim.local('v', 'int', 1);
        for (let v = 1; v <= n; v++) {
          sim.w(vA, v);
          if (sim.r(U + (v - 1))) {
            vSel = v;
            sim.step(at('if (used[v - 1]) continue'), L('v = ' + v + ': used[' + (v - 1) + '] is true (' + v + ' is already in the prefix). Skip.', 'v = ' + v + ': used[' + (v - 1) + '] เป็น true (' + v + ' อยู่ในส่วนหน้าแล้ว) ข้าม'), { lines: [at('for (int v = 1')] });
            vSel = null; continue;
          }
          sim.w(U + (v - 1), true); sim.w(C + 4 * p, v); vSel = v;
          sim.step(at('used[v - 1] = true;'), L('v = ' + v + ' is free. <b>Choose</b> it: used[' + (v - 1) + '] = true, cur[' + p + '] = ' + v + '. These writes go through the pointers into main\'s arrays.', 'v = ' + v + ' ว่างอยู่ <b>เลือก</b>มัน: used[' + (v - 1) + '] = true, cur[' + p + '] = ' + v + ' การเขียนเหล่านี้วิ่งผ่านพอยน์เตอร์ไปที่อาเรย์ของ main'), { lines: [at('for (int v = 1')] });
          vSel = null;
          rec(p + 1, id, (prefix || '') + v, at('perm(pos + 1'));
          sim.step(at('perm(pos + 1'), L('Back in perm(' + p + ') with v = ' + v + ': its own v survived the deeper calls, because it lives in this frame.', 'กลับมาที่ perm(' + p + ') โดย v = ' + v + ': v ของเฟรมนี้รอดจากการเรียกที่ลึกกว่า เพราะมันอยู่ในเฟรมนี้'));
          sim.w(U + (v - 1), false); vSel = v;
          sim.step(at('used[v - 1] = false;'), L('<b>Un-choose</b>: used[' + (v - 1) + '] = false, so ' + v + ' is available again for the next branch. (cur[' + p + '] is not cleared; it will just be overwritten.)', '<b>ยกเลิก</b>: used[' + (v - 1) + '] = false ' + v + ' จึงว่างอีกครั้งสำหรับกิ่งถัดไป (cur[' + p + '] ไม่ได้ถูกล้าง แค่จะถูกเขียนทับ)'));
          vSel = null;
        }
        sim.step(at('for (int v = 1'), L('v = ' + (n + 1) + ' &gt; n: every choice for cur[' + p + '] has been tried. Return.', 'v = ' + (n + 1) + ' &gt; n: ลองทุกทางเลือกของ cur[' + p + '] แล้ว คืนกลับ'));
        tree[id].onStack = false; tree[id].done = true;
        sim.ret(undefined, { show: false }); cur = prevCur; pos = prevPos; setCls();
      };
      rec(0, null, '', at('perm(0,'));
      cur = null; setCls();
      sim.step(at('perm(0,'), L('Done: ' + count + ' permutations (n! = ' + count + ') from ' + calls + ' calls. The stack was never deeper than n + 1 = ' + (n + 1) + ' perm frames.', 'เสร็จ: ' + count + ' การเรียง (n! = ' + count + ') จาก ' + calls + ' การเรียก stack ไม่เคยลึกเกิน n + 1 = ' + (n + 1) + ' เฟรมของ perm'));
      sim.ret(0, { show: false });
    }
  });

  // ---------------------------------------------------------------- memoized fibonacci
  const fbCode = n => `long long memo[${n + 1}];          // -1 = not computed yet
long long fib(int k) {
  if (k <= 1) return k;
  if (memo[k] != -1) return memo[k];   // already known: no recursion
  memo[k] = fib(k - 1) + fib(k - 2);
  return memo[k];
}
int main() {
  fill(memo, memo + ${n + 1}, -1);
  cout << fib(${n}) << "\\n";
}
`;
  def({
    id: 'fib-memo', part: 3, lesson: '14', lessonFile: '14-dp-basics.md',
    title: L('Memoization: remember, don\'t recompute', 'Memoization: จำไว้ ไม่ต้องคำนวณซ้ำ'),
    summary: L('Plain recursive fib(n) calls itself about 1.6ⁿ times. With a memo table each fib(k) is computed once; every later call is a single array read. The call tree shows which calls were cut short.',
      'fib(n) แบบเรียกซ้ำธรรมดาเรียกตัวเองราว 1.6ⁿ ครั้ง เมื่อมีตาราง memo แต่ละ fib(k) ถูกคำนวณครั้งเดียว การเรียกครั้งหลังเป็นแค่การอ่านอาเรย์ครั้งเดียว ต้นไม้การเรียกแสดงว่าการเรียกไหนถูกตัดสั้น'),
    blurb: L('Top-down DP: the memo table fills as the stack unwinds.', 'DP แบบบนลงล่าง: ตาราง memo เติมตอน stack คลายตัว'),
    params: [{ id: 'n', label: 'n', value: '6', w: 60 }],
    paramHint: L('n from 2 to 10', 'n ตั้งแต่ 2 ถึง 10'),
    code: fbCode(6),
    codeFn: p => { const n = parseNums(p.n, 1)[0]; return fbCode(n >= 2 && n <= 10 ? n : 6); },
    build(sim, prm) {
      const n = parseNums(prm.n, 1)[0];
      if (!(n >= 2 && n <= 10)) throw userErr(L('n must be 2 to 10.', 'n ต้องอยู่ระหว่าง 2 ถึง 10'));
      const code = fbCode(n), at = LN(code);
      const tree = {}; let cid = 0, cur = null, hit = null;
      const setCls = () => { for (const id in tree) tree[id].cls = id === cur ? 'hl' : (tree[id].onStack ? 'cmp' : (tree[id].memo ? 'chg' : 'ok')); };
      let M = 0;
      sim.viewFn = S => {
        const mv = S.frames[0] && S.frames[0].vars.find(q => q.name === 'memo'); if (!mv) return null;
        return { kind: 'multi', title: L('memo table and call tree', 'ตาราง memo และต้นไม้การเรียก'), parts: [
          { kind: 'array', rows: [{ label: 'memo', cells: mv.cells.map(c => c === undefined ? '?' : fmtPlain(c)), cls: mv.cells.map((c, k) => k === hit ? 'cmp' : (c === -1 || c === undefined ? 'dim' : 'ok')) }] },
          { kind: 'tree', cap: L('Call tree. Teal = running, violet = waiting, green = computed, yellow = answered from memo (its subtree was skipped).', 'ต้นไม้การเรียก ฟ้าอมเขียว = กำลังทำงาน ม่วง = รออยู่ เขียว = คำนวณแล้ว เหลือง = ตอบจาก memo (ข้ามทั้งกิ่งใต้มัน)'), nodes: tree, root: tree.c1 ? 'c1' : null, square: true, gy: 48, gx: 50, r: 15, empty: L('(no calls yet)', '(ยังไม่มีการเรียก)') }] };
      };
      // memo is a global; we show it in main's frame for simplicity
      sim.call('main()');
      M = sim.arr('memo', 'long long', n + 1, undefined);
      sim.step(at('int main'), L('<code>memo</code> is a global array. Globals live in their own static area, not on the stack; here it is drawn inside main\'s frame only to keep the picture small. Globals start at 0, but we will fill them with −1.', '<code>memo</code> เป็นอาเรย์ global ตัวแปร global อยู่ในพื้นที่ static ของมันเอง ไม่ใช่บน stack ที่นี่วาดไว้ในเฟรมของ main แค่เพื่อให้ภาพเล็กลง global เริ่มต้นเป็น 0 แต่เราจะเติม −1'));
      for (let k = 0; k <= n; k++) sim.w(M + 8 * k, -1);
      sim.step(at('fill(memo'), L('Every entry = −1, meaning "not computed yet". (0 would be a bad marker because fib(0) = 0.)', 'ทุกช่อง = −1 หมายถึง "ยังไม่ได้คำนวณ" (0 เป็นเครื่องหมายที่ไม่ดีเพราะ fib(0) = 0)'));
      let calls = 0;
      const fib = (k, parent, callLine) => {
        const id = 'c' + (++cid); calls++;
        tree[id] = { label: 'f(' + k + ')', kids: [], onStack: true };
        if (parent) tree[parent].kids.push(id);
        const prev = cur; cur = id; setCls();
        sim.top().line = callLine;
        sim.call('fib(int k)'); sim.param('k', 'int', k);
        const done = (val, why, line, memoHit) => {
          tree[id].onStack = false; tree[id].memo = memoHit; tree[id].sub = String(val);
          setCls();
          sim.step(line, why);
          hit = null;
          sim.ret(val, { type: 'long long' }); cur = prev; setCls();
          return val;
        };
        if (k <= 1) return done(k, L('fib(' + k + '): base case, return ' + k + '.', 'fib(' + k + '): กรณีฐาน คืน ' + k), at('if (k <= 1)'), false);
        const mk = sim.r(M + 8 * k);
        if (mk !== -1) { hit = k; return done(mk, L('fib(' + k + '): memo[' + k + '] = ' + mk + ' is already known. Return it immediately; the whole subtree below is <b>skipped</b>.', 'fib(' + k + '): memo[' + k + '] = ' + mk + ' รู้อยู่แล้ว คืนทันที กิ่งทั้งหมดข้างล่าง<b>ถูกข้าม</b>'), at('if (memo[k] != -1)'), true); }
        sim.step(at('if (memo[k] != -1)'), L('fib(' + k + '): memo[' + k + '] = −1, not computed yet. We must recurse.', 'fib(' + k + '): memo[' + k + '] = −1 ยังไม่ได้คำนวณ ต้องเรียกซ้ำ'));
        const a = fib(k - 1, id, at('memo[k] = fib(k - 1)'));
        sim.step(at('memo[k] = fib(k - 1)'), L('fib(' + (k - 1) + ') returned ' + a + '. The return value waits in a temporary while fib(' + (k - 2) + ') runs.', 'fib(' + (k - 1) + ') คืน ' + a + ' ค่าที่คืนรออยู่ในตัวแปรชั่วคราวขณะที่ fib(' + (k - 2) + ') ทำงาน'));
        const b = fib(k - 2, id, at('memo[k] = fib(k - 1)'));
        sim.w(M + 8 * k, a + b);
        cur = id; setCls();
        sim.step(at('memo[k] = fib(k - 1)'), L('fib(' + (k - 2) + ') returned ' + b + '. Store memo[' + k + '] = ' + a + ' + ' + b + ' = <b>' + (a + b) + '</b>.', 'fib(' + (k - 2) + ') คืน ' + b + ' เก็บ memo[' + k + '] = ' + a + ' + ' + b + ' = <b>' + (a + b) + '</b>'));
        return done(sim.r(M + 8 * k), L('Return memo[' + k + '] = ' + (a + b) + '.', 'คืน memo[' + k + '] = ' + (a + b)), at('return memo[k];'), false);
      };
      const ans = fib(n, null, at('cout << fib('));
      sim.print(ans + '\n'); cur = null; setCls();
      const plain = (() => { const c = k => k <= 1 ? 1 : 1 + c(k - 1) + c(k - 2); return c(n); })();
      sim.step(at('cout << fib('), L('fib(' + n + ') = ' + ans + ' using ' + calls + ' calls. Without the memo it would take ' + plain + ' calls. With it, each k is computed once: O(n).', 'fib(' + n + ') = ' + ans + ' ใช้ ' + calls + ' การเรียก ถ้าไม่มี memo จะใช้ ' + plain + ' การเรียก เมื่อมี memo แต่ละ k ถูกคำนวณครั้งเดียว: O(n)'));
      sim.ret(0, { show: false });
    }
  });
})();
