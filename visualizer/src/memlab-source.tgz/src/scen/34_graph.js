/* Part III · graphs: BFS, DFS (lesson 16), Dijkstra (lesson 17), Kruskal + DSU (lesson 18) */
(() => {
  const mainVar = (S, nm) => S.frames[0] && S.frames[0].vars.find(q => q.name === nm);
  const INF = 1000000000;

  // "0-1, 0-2:4" → {n, edges:[{a,b,w}]}
  function parseEdges(str, weighted, maxN = 8) {
    const parts = String(str).split(/[,;\n]+/).map(x => x.trim()).filter(Boolean).slice(0, 14);
    const edges = [];
    for (const p of parts) {
      const m = p.match(/^(\d+)\s*-\s*(\d+)(?:\s*:\s*(\d+))?$/);
      if (!m) throw userErr(L('Cannot read edge "' + p + '". Write u-v' + (weighted ? ':w' : '') + ', for example 0-1' + (weighted ? ':4' : '') + '.', 'อ่านเส้นเชื่อม "' + p + '" ไม่ได้ ให้เขียน u-v' + (weighted ? ':w' : '') + ' เช่น 0-1' + (weighted ? ':4' : '')));
      const a = +m[1], b = +m[2], w = m[3] != null ? +m[3] : 1;
      if (a >= maxN || b >= maxN) throw userErr(L('Vertices must be 0 to ' + (maxN - 1) + '.', 'จุดยอดต้องอยู่ระหว่าง 0 ถึง ' + (maxN - 1)));
      if (a === b) throw userErr(L('No self-loops, please (' + p + ').', 'ไม่รับเส้นวนเข้าตัวเอง (' + p + ')'));
      if (weighted && (w < 1 || w > 99)) throw userErr(L('Weights must be 1 to 99.', 'น้ำหนักต้องอยู่ระหว่าง 1 ถึง 99'));
      edges.push({ a, b, w });
    }
    if (!edges.length) throw userErr(L('Give at least one edge.', 'ใส่เส้นเชื่อมอย่างน้อยหนึ่งเส้น'));
    const n = Math.max(...edges.map(e => Math.max(e.a, e.b))) + 1;
    return { n, edges };
  }
  function adjOf(n, edges) { const adj = Array.from({ length: n }, () => []); edges.forEach((e, k) => { adj[e.a].push({ v: e.b, w: e.w, k }); adj[e.b].push({ v: e.a, w: e.w, k }); }); return adj; }
  // layered layout: x by hop distance from 0, y spread within the layer
  function layout(n, edges) {
    const adj = adjOf(n, edges), d = Array(n).fill(-1), q = [0]; d[0] = 0;
    while (q.length) { const u = q.shift(); for (const { v } of adj[u]) if (d[v] < 0) { d[v] = d[u] + 1; q.push(v); } }
    const maxD = Math.max(0, ...d); for (let i = 0; i < n; i++) if (d[i] < 0) d[i] = maxD + 1;
    const layers = {}; for (let i = 0; i < n; i++) (layers[d[i]] = layers[d[i]] || []).push(i);
    const L0 = Math.max(...Object.keys(layers).map(Number));
    const pos = [];
    for (const k in layers) layers[k].forEach((v, j) => { pos[v] = { x: L0 ? k / L0 : 0.5, y: layers[k].length === 1 ? 0.5 : j / (layers[k].length - 1) }; });
    return pos;
  }
  const adjCode = (n, adj, weighted) => (weighted ? '  vector<pair<int,int>> adj[' + n + '];   // {neighbour, weight}\n' : '  vector<int> adj[' + n + '];\n') +
    adj.map((l, u) => '  adj[' + u + '] = {' + l.map(x => weighted ? '{' + x.v + ',' + x.w + '}' : x.v).join(', ') + '};').join('\n');
  const graphView = (n, edges, pos, nodeCls, nodeSub, edgeCls, weighted, H) => ({
    kind: 'graph', w: 420, h: H || 230,
    nodes: Array.from({ length: n }, (_, i) => ({ id: i, label: String(i), x: pos[i].x, y: pos[i].y, cls: nodeCls(i), sub: nodeSub(i) })),
    edges: edges.map((e, k) => ({ a: e.a, b: e.b, w: weighted ? e.w : null, cls: edgeCls(e, k) }))
  });
  const fmtD = x => x === INF ? '∞' : (x === undefined ? '?' : String(x));

  // ---------------------------------------------------------------- BFS
  const bfsCode = (n, adj) => `int main() {
  int n = ${n};
${adjCode(n, adj, false)}
  int dist[${n}];
  fill(dist, dist + n, -1);             // -1 = not discovered
  int q[${n}], head = 0, tail = 0;          // a queue in a plain array
  dist[0] = 0;  q[tail++] = 0;
  while (head < tail) {
    int u = q[head++];                  // pop the front
    for (int v : adj[u])
      if (dist[v] == -1) {              // first time we see v
        dist[v] = dist[u] + 1;
        q[tail++] = v;                  // push at the back
      }
  }
  for (int i = 0; i < n; i++) cout << dist[i] << " ";
}
`;
  const DEFG = '0-1, 0-2, 1-3, 2-3, 3-4, 2-5, 4-5';
  def({
    id: 'bfs', part: 3, lesson: '16', lessonFile: '16-graphs-bfs-dfs.md',
    title: L('BFS: a queue makes rings of distance', 'BFS: คิวสร้างวงระยะทาง'),
    summary: L('Breadth-first search from vertex 0. The queue is a plain array with head and tail indices: each vertex is pushed exactly once, when it is first discovered, so its dist is final at that moment. Vertices leave the queue in order of distance.',
      'การค้นหาแนวกว้างจากจุดยอด 0 คิวเป็นอาเรย์ธรรมดาที่มีดัชนี head และ tail จุดยอดแต่ละจุดถูก push ครั้งเดียวตอนถูกค้นพบครั้งแรก dist ของมันจึงเป็นค่าสุดท้ายตั้งแต่ตอนนั้น จุดยอดออกจากคิวตามลำดับระยะทาง'),
    blurb: L('dist[], an array queue with head/tail, O(V + E).', 'dist[] คิวในอาเรย์ที่มี head/tail และ O(V + E)'),
    params: [{ id: 'g', label: L('Edges (undirected)', 'เส้นเชื่อม (ไม่มีทิศ)'), value: DEFG }],
    paramHint: L('u-v pairs, vertices 0–7 · BFS starts at 0', 'คู่ u-v จุดยอด 0–7 · BFS เริ่มที่ 0'),
    code: (() => { const { n, edges } = parseEdges(DEFG); return bfsCode(n, adjOf(n, edges)); })(),
    codeFn: p => { try { const { n, edges } = parseEdges(p.g); return bfsCode(n, adjOf(n, edges)); } catch (e) { return bfsCode(2, [[{ v: 1 }], [{ v: 0 }]]); } },
    build(sim, prm) {
      const { n, edges } = parseEdges(prm.g), adj = adjOf(n, edges), code = bfsCode(n, adj), at = LN(code), pos = layout(n, edges);
      let cu = null, cv = null, ce = null, tree = new Set();
      sim.viewFn = S => {
        const D = mainVar(S, 'dist'), Q = mainVar(S, 'q'); if (!D) return null;
        const h = Q ? mainVar(S, 'head').value : 0, t = Q ? mainVar(S, 'tail').value : 0;
        const parts = [graphView(n, edges, pos, i => i === cu ? 'hl' : (i === cv ? 'cmp' : (D.cells[i] === -1 || D.cells[i] === undefined ? '' : (Q && Q.cells.slice(h, t).includes(i) ? 'chg' : 'ok'))), i => D.cells[i] === -1 || D.cells[i] === undefined ? '' : 'd=' + D.cells[i], (e, k) => k === ce ? 'hl' : (tree.has(k) ? 'ok' : null), false)];
        parts[0].cap = L('Teal = u (being expanded), violet = neighbour v being checked, yellow = in the queue, green = done. Green edges form the BFS tree.', 'ฟ้าอมเขียว = u (กำลังขยาย) ม่วง = เพื่อนบ้าน v ที่กำลังตรวจ เหลือง = อยู่ในคิว เขียว = เสร็จ เส้นสีเขียวคือต้นไม้ BFS');
        if (Q) parts.push({ kind: 'array', rows: [{ label: 'q', cells: Q.cells.map((c, k) => c === undefined ? '?' : c), cls: Q.cells.map((c, k) => k < h ? 'dim' : (k < t ? 'chg' : '')), marks: Object.assign({}, { [h]: ['head'] }, t === h ? { [t]: ['head', 'tail'] } : { [t]: ['tail'] }), ranges: t > h ? [{ a: h, b: t - 1, label: L('waiting', 'กำลังรอ') }] : [] }] });
        return { kind: 'multi', title: L('graph and queue', 'กราฟและคิว'), parts };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts. The adjacency lists adj[] are vectors (their data is on the heap, as in Part II); they are left out of the memory picture so the BFS state stands out.', 'main เริ่มทำงาน รายการประชิด adj[] เป็น vector (ข้อมูลอยู่บน heap เหมือนใน Part II) จึงไม่วาดไว้ในภาพหน่วยความจำ เพื่อให้สถานะของ BFS เด่นชัด'), { lines: [at('vector<int> adj')] });
      const D = sim.arr('dist', 'int', n, undefined);
      sim.step(at('int dist['), L('dist[] starts as garbage…', 'dist[] เริ่มเป็นค่าขยะ…'));
      for (let i = 0; i < n; i++) sim.w(D + 4 * i, -1);
      sim.step(at('fill(dist'), L('…and fill sets every entry to −1: "not discovered yet".', '…และ fill ตั้งทุกช่องเป็น −1: "ยังไม่ถูกค้นพบ"'));
      const Q = sim.arr('q', 'int', n, undefined), hA = sim.local('head', 'int', 0), tA = sim.local('tail', 'int', 0);
      sim.step(at('int q['), L('The queue: an array of n boxes. head = index of the front, tail = where the next push goes. [head, tail) is the waiting part. n boxes are enough because every vertex is pushed at most once.', 'คิว: อาเรย์ n ช่อง head = ดัชนีหัวคิว tail = ตำแหน่งที่จะ push ถัดไป [head, tail) คือส่วนที่กำลังรอ n ช่องพอเพราะแต่ละจุดยอดถูก push ไม่เกินครั้งเดียว'));
      sim.w(D, 0); sim.w(Q, 0); sim.w(tA, 1);
      sim.step(at('dist[0] = 0;'), L('Start: dist[0] = 0 and push 0. tail = 1.', 'เริ่ม: dist[0] = 0 แล้ว push 0 tail = 1'));
      let head = 0, tail = 1;
      while (head < tail) {
        sim.r(hA); sim.r(tA);
        const u = sim.r(Q + 4 * head); head++; sim.w(hA, head);
        const uA = sim.local('u', 'int', u); cu = u; cv = null; ce = null;
        sim.step(at('int u = q[head++]'), L('Pop u = q[' + (head - 1) + '] = <b>' + u + '</b> (dist ' + sim.peek(D + 4 * u) + '). Nothing is erased: head just moves past it.', 'ดึง u = q[' + (head - 1) + '] = <b>' + u + '</b> (dist ' + sim.peek(D + 4 * u) + ') ไม่มีอะไรถูกลบ head แค่ขยับผ่านไป'), { lines: [at('while (head < tail)')] });
        const vA = sim.local('v', 'int', undefined);
        for (const { v, k } of adj[u]) {
          sim.w(vA, v); cv = v; ce = k;
          const dv = sim.r(D + 4 * v);
          if (dv === -1) {
            const du = sim.r(D + 4 * u);
            sim.w(D + 4 * v, du + 1); sim.w(Q + 4 * tail, v); tail++; sim.w(tA, tail); tree.add(k);
            sim.step(at('dist[v] = dist[u] + 1'), L('Neighbour v = ' + v + ': dist[' + v + '] = −1, so this is the first path to it, and the shortest. dist[' + v + '] = ' + du + ' + 1 = <b>' + (du + 1) + '</b>; push ' + v + ' at q[' + (tail - 1) + '].', 'เพื่อนบ้าน v = ' + v + ': dist[' + v + '] = −1 นี่คือเส้นทางแรกที่ไปถึงมัน และสั้นที่สุด dist[' + v + '] = ' + du + ' + 1 = <b>' + (du + 1) + '</b> แล้ว push ' + v + ' ที่ q[' + (tail - 1) + ']'), { lines: [at('if (dist[v] == -1)'), at('q[tail++] = v')] });
          } else {
            sim.step(at('if (dist[v] == -1)'), L('Neighbour v = ' + v + ' already has dist ' + dv + '. Skip it: a later path can never be shorter.', 'เพื่อนบ้าน v = ' + v + ' มี dist ' + dv + ' แล้ว ข้าม: เส้นทางที่มาทีหลังไม่มีทางสั้นกว่า'), { lines: [at('for (int v : adj[u])')] });
          }
        }
        cv = null; ce = null; sim.drop('v'); sim.drop('u');
      }
      cu = null;
      sim.r(hA); sim.r(tA);
      let out = ''; for (let i = 0; i < n; i++) out += sim.r(D + 4 * i) + ' ';
      sim.print(out + '\n');
      sim.step(at('for (int i = 0; i < n'), L('head = tail = ' + head + ': the queue is empty. Every reachable vertex was pushed once and popped once, and every edge was looked at twice (once from each end): O(V + E).' + (out.includes('-1') ? ' −1 means unreachable from 0.' : ''), 'head = tail = ' + head + ': คิวว่าง ทุกจุดยอดที่ไปถึงได้ถูก push ครั้งเดียวและ pop ครั้งเดียว ทุกเส้นเชื่อมถูกดูสองครั้ง (จากแต่ละปลาย): O(V + E)' + (out.includes('-1') ? ' −1 หมายถึงไปไม่ถึงจาก 0' : '')));
      sim.ret(0, { show: false });
    }
  });

  // ---------------------------------------------------------------- DFS (recursive)
  const dfsCode = (n, adj) => `${'vector<int> adj[' + n + '];'}          // global
bool vis[${n}];                     // global, starts all false
void dfs(int u) {
  vis[u] = true;
  cout << u << " ";
  for (int v : adj[u])
    if (!vis[v]) dfs(v);            // go deeper right away
}
int main() {
${adj.map((l, u) => '  adj[' + u + '] = {' + l.map(x => x.v).join(', ') + '};').join('\n')}
  dfs(0);
}
`;
  def({
    id: 'dfs', part: 3, lesson: '16', lessonFile: '16-graphs-bfs-dfs.md',
    title: L('DFS: the call stack is the path', 'DFS: call stack คือเส้นทาง'),
    summary: L('Recursive depth-first search. Each dfs(u) frame keeps its own position in its for loop, so when a deeper call returns, the loop resumes exactly where it left off. At any moment the frames on the stack spell out the path from 0 to the current vertex.',
      'การค้นหาแนวลึกแบบเรียกซ้ำ แต่ละเฟรม dfs(u) จำตำแหน่งในลูป for ของตัวเอง เมื่อการเรียกที่ลึกกว่าคืนกลับ ลูปจึงทำต่อจากจุดเดิมพอดี ณ เวลาใดก็ตาม เฟรมบน stack คือเส้นทางจาก 0 ถึงจุดยอดปัจจุบัน'),
    blurb: L('Recursion as an implicit stack; vis[] and the DFS tree.', 'การเรียกซ้ำคือ stack แฝง vis[] และต้นไม้ DFS'),
    params: [{ id: 'g', label: L('Edges (undirected)', 'เส้นเชื่อม (ไม่มีทิศ)'), value: DEFG }],
    paramHint: L('u-v pairs, vertices 0–7 · DFS starts at 0', 'คู่ u-v จุดยอด 0–7 · DFS เริ่มที่ 0'),
    code: (() => { const { n, edges } = parseEdges(DEFG); return dfsCode(n, adjOf(n, edges)); })(),
    codeFn: p => { try { const { n, edges } = parseEdges(p.g); return dfsCode(n, adjOf(n, edges)); } catch (e) { return dfsCode(2, [[{ v: 1 }], [{ v: 0 }]]); } },
    build(sim, prm) {
      const { n, edges } = parseEdges(prm.g), adj = adjOf(n, edges), code = dfsCode(n, adj), at = LN(code), pos = layout(n, edges);
      let cu = null, cv = null, ce = null, tree = new Set(), path = [];
      sim.viewFn = S => {
        const V = mainVar(S, 'vis'); if (!V) return null;
        const g = graphView(n, edges, pos, i => i === cu ? 'hl' : (i === cv ? 'cmp' : (path.includes(i) ? 'chg' : (V.cells[i] ? 'ok' : ''))), i => path.includes(i) ? 'depth ' + path.indexOf(i) : '', (e, k) => k === ce ? 'hl' : (tree.has(k) ? 'ok' : null), false, 240);
        g.cap = L('Teal = current u, yellow = vertices whose dfs frame is still on the stack (the current path), green = finished, violet = neighbour being checked.', 'ฟ้าอมเขียว = u ปัจจุบัน เหลือง = จุดยอดที่เฟรม dfs ยังอยู่บน stack (เส้นทางปัจจุบัน) เขียว = เสร็จแล้ว ม่วง = เพื่อนบ้านที่กำลังตรวจ');
        return { kind: 'multi', title: L('graph and recursion', 'กราฟและการเรียกซ้ำ'), parts: [g, { kind: 'array', rows: [{ label: 'vis', cells: V.cells.map(b => b ? 'T' : 'F'), cls: V.cells.map((b, i) => i === cv ? 'cmp' : (b ? 'ok' : '')) }] }] };
      };
      sim.call('main()');
      const V = sim.arr('vis', 'bool', n, false);
      sim.step(at('int main'), L('<code>vis</code> and <code>adj</code> are globals (static memory, not the stack). vis is drawn inside main\'s frame only to keep the picture compact; adj is left out. Globals start zeroed, so vis is all false.', '<code>vis</code> และ <code>adj</code> เป็น global (หน่วยความจำ static ไม่ใช่ stack) วาด vis ไว้ในเฟรมของ main แค่เพื่อให้ภาพกะทัดรัด และไม่วาด adj global เริ่มเป็นศูนย์ vis จึงเป็น false ทั้งหมด'));
      sim.step(at('adj[' + (n - 1) + '] ='), L('Build the adjacency lists.', 'สร้างรายการประชิด'), { lines: adj.map((_, u) => at('adj[' + u + '] =')) });
      let maxDepth = 0;
      const dfs = (u, callLine, viaEdge) => {
        sim.top().line = callLine;
        sim.call('dfs(int u)'); sim.param('u', 'int', u);
        path.push(u); maxDepth = Math.max(maxDepth, path.length);
        const prevU = cu; cu = u; cv = null; ce = null;
        if (viaEdge != null) tree.add(viaEdge);
        sim.w(V + u, true);
        sim.step(at('vis[u] = true'), L('dfs(' + u + '): a new frame at depth ' + (path.length - 1) + '. Mark vis[' + u + '] = true <b>first</b>, so no other path will enter ' + u + ' again. Stack path: ' + path.join(' → ') + '.', 'dfs(' + u + '): เฟรมใหม่ที่ความลึก ' + (path.length - 1) + ' ตั้ง vis[' + u + '] = true <b>ก่อน</b> เพื่อไม่ให้เส้นทางอื่นเข้ามาที่ ' + u + ' อีก เส้นทางบน stack: ' + path.join(' → ')));
        sim.print(u + ' ');
        sim.step(at('cout << u'), L('Print ' + u + ' (pre-order: when we first arrive).', 'พิมพ์ ' + u + ' (pre-order: ตอนมาถึงครั้งแรก)'));
        const vA = sim.local('v', 'int', undefined);
        for (const { v, k } of adj[u]) {
          sim.w(vA, v); cv = v; ce = k; cu = u;
          if (sim.r(V + v)) {
            sim.step(at('if (!vis[v])'), L('In dfs(' + u + '): neighbour ' + v + ' is already visited. Skip.', 'ใน dfs(' + u + '): เพื่อนบ้าน ' + v + ' ถูกเยี่ยมแล้ว ข้าม'), { lines: [at('for (int v : adj[u])')] });
          } else {
            sim.step(at('if (!vis[v])'), L('In dfs(' + u + '): neighbour ' + v + ' is new. Call dfs(' + v + ') <b>now</b>; this frame pauses in the middle of its loop.', 'ใน dfs(' + u + '): เพื่อนบ้าน ' + v + ' ยังใหม่ เรียก dfs(' + v + ') <b>ทันที</b> เฟรมนี้หยุดรอกลางลูป'), { lines: [at('for (int v : adj[u])')] });
            dfs(v, at('if (!vis[v])'), k);
            cu = u; cv = v; ce = null;
            sim.step(at('if (!vis[v])'), L('dfs(' + v + ') returned. Back in dfs(' + u + '): its v is still ' + v + ' (saved in this frame), so the loop continues with the next neighbour.', 'dfs(' + v + ') คืนกลับ กลับมาที่ dfs(' + u + '): v ของมันยังเป็น ' + v + ' (เก็บไว้ในเฟรมนี้) ลูปจึงไปต่อที่เพื่อนบ้านถัดไป'));
          }
        }
        cv = null; ce = null;
        path.pop();
        sim.step(at('void dfs') + 5, L('dfs(' + u + ') has no more neighbours: it is finished and returns.', 'dfs(' + u + ') ไม่มีเพื่อนบ้านเหลือ: เสร็จแล้วคืนกลับ'));
        sim.ret(undefined, { show: false }); cu = prevU;
      };
      dfs(0, at('dfs(0)'), null);
      cu = null;
      sim.step(at('dfs(0)'), L('All done. The deepest the stack got was ' + maxDepth + ' dfs frames. On a long path graph that depth reaches n, which is why very deep recursive DFS can overflow the stack (around 10⁵–10⁶ frames).', 'เสร็จทั้งหมด stack ลึกสุด ' + maxDepth + ' เฟรมของ dfs บนกราฟที่เป็นเส้นยาว ความลึกจะถึง n นี่คือเหตุผลที่ DFS แบบเรียกซ้ำที่ลึกมากอาจทำให้ stack ล้น (ราว 10⁵–10⁶ เฟรม)'));
      sim.ret(0, { show: false });
    }
  });

  // ---------------------------------------------------------------- Dijkstra
  const djCode = (n, adj) => `int main() {
  const int INF = 1e9;
  int n = ${n};
${adjCode(n, adj, true)}
  int dist[${n}];
  fill(dist, dist + n, INF);
  priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;   // {dist, vertex}, smallest first
  dist[0] = 0;  pq.push({0, 0});
  while (!pq.empty()) {
    auto [d, u] = pq.top();  pq.pop();
    if (d > dist[u]) continue;          // stale entry: u was already settled
    for (auto [v, w] : adj[u])
      if (dist[u] + w < dist[v]) {      // relax
        dist[v] = dist[u] + w;
        pq.push({dist[v], v});
      }
  }
  for (int i = 0; i < n; i++) cout << dist[i] << " ";
}
`;
  const DEFW = '0-1:4, 0-2:1, 2-1:2, 1-3:1, 2-3:5, 3-4:3';
  def({
    id: 'dijkstra', part: 3, lesson: '17', lessonFile: '17-shortest-paths.md',
    title: L('Dijkstra: always settle the closest', 'Dijkstra: ปิดจุดที่ใกล้ที่สุดเสมอ'),
    summary: L('Shortest paths with non-negative weights. The priority queue always hands back the smallest tentative distance; that vertex can no longer improve, so it is settled. Improving dist[v] pushes a new entry instead of updating the old one, which is why stale entries must be skipped.',
      'เส้นทางสั้นที่สุดเมื่อน้ำหนักไม่ติดลบ priority queue คืนระยะชั่วคราวที่น้อยที่สุดเสมอ จุดยอดนั้นไม่มีทางดีขึ้นอีกแล้วจึงถูกปิด การปรับ dist[v] ให้ดีขึ้นจะ push รายการใหม่แทนการแก้รายการเก่า จึงต้องข้ามรายการที่ล้าสมัย'),
    blurb: L('Relaxation, the min-priority-queue, stale entries.', 'การผ่อนคลาย (relax) min-priority-queue และรายการที่ล้าสมัย'),
    params: [{ id: 'g', label: L('Weighted edges (undirected)', 'เส้นเชื่อมมีน้ำหนัก (ไม่มีทิศ)'), value: DEFW }],
    paramHint: L('u-v:w, vertices 0–7, weights 1–99 · source is 0', 'u-v:w จุดยอด 0–7 น้ำหนัก 1–99 · ต้นทางคือ 0'),
    code: (() => { const { n, edges } = parseEdges(DEFW, true); return djCode(n, adjOf(n, edges)); })(),
    codeFn: p => { try { const { n, edges } = parseEdges(p.g, true); return djCode(n, adjOf(n, edges)); } catch (e) { return djCode(2, [[{ v: 1, w: 1 }], [{ v: 0, w: 1 }]]); } },
    build(sim, prm) {
      const { n, edges } = parseEdges(prm.g, true), adj = adjOf(n, edges), code = djCode(n, adj), at = LN(code), pos = layout(n, edges);
      let cu = null, cv = null, ce = null, settled = new Set(), parentE = {}, pq = [], popped = null;
      sim.viewFn = S => {
        const D = mainVar(S, 'dist'); if (!D) return null;
        const g = graphView(n, edges, pos, i => i === cu ? 'hl' : (i === cv ? 'cmp' : (settled.has(i) ? 'ok' : '')), i => fmtD(D.cells[i]), (e, k) => k === ce ? 'hl' : (Object.values(parentE).includes(k) ? 'ok' : null), true, 230);
        g.cap = L('Numbers under vertices are dist[]. Green = settled, teal = u, violet = v being relaxed. Green edges: current shortest-path tree.', 'ตัวเลขใต้จุดยอดคือ dist[] เขียว = ปิดแล้ว ฟ้าอมเขียว = u ม่วง = v ที่กำลัง relax เส้นสีเขียว: ต้นไม้เส้นทางสั้นสุดปัจจุบัน');
        const sorted = pq.slice().sort((x, y) => x[0] - y[0] || x[1] - y[1]);
        const pqRow = { label: 'pq', w: 58, cells: sorted.length ? sorted.map(p => '{' + p[0] + ',' + p[1] + '}') : ['empty'], cls: sorted.length ? sorted.map((p, k) => k === 0 ? 'hl' : (p[0] > D.cells[p[1]] ? 'dim' : 'hp')) : ['dim'], idx: false };
        const parts = [g, { kind: 'array', cap: L('pq contents, smallest first (grey = stale: a better dist was found later). The real pq is a binary heap inside a vector, as in Part II.', 'สิ่งที่อยู่ใน pq เรียงจากน้อยไปมาก (เทา = ล้าสมัย: เจอ dist ที่ดีกว่าภายหลัง) pq จริงคือ binary heap ใน vector เหมือนใน Part II'), rows: [pqRow] }];
        return { kind: 'multi', title: L('graph, dist and the priority queue', 'กราฟ dist และ priority queue'), parts };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts. adj and pq keep their data on the heap (Part II shows how); here they are drawn in the concept view only.', 'main เริ่มทำงาน adj และ pq เก็บข้อมูลบน heap (ดูได้ใน Part II) ที่นี่วาดไว้ในมุมมองแนวคิดเท่านั้น'), { lines: [at('const int INF')] });
      const D = sim.arr('dist', 'int', n, undefined);
      for (let i = 0; i < n; i++) sim.w(D + 4 * i, INF);
      sim.step(at('fill(dist'), L('dist[] = INF (10⁹) everywhere: "no path known yet". INF must be big, but small enough that INF + w does not overflow an int.', 'dist[] = INF (10⁹) ทุกช่อง: "ยังไม่รู้เส้นทาง" INF ต้องใหญ่ แต่เล็กพอที่ INF + w จะไม่ล้น int'), { lines: [at('int dist[')] });
      sim.w(D, 0); pq.push([0, 0]);
      sim.step(at('dist[0] = 0;'), L('dist[0] = 0; push {0, 0}.', 'dist[0] = 0 แล้ว push {0, 0}'), { lines: [at('priority_queue')] });
      let guard = 0;
      while (pq.length && guard++ < 60) {
        pq.sort((x, y) => x[0] - y[0] || x[1] - y[1]);
        const [d, u] = pq.shift();
        const dA = sim.local('d', 'int', d), uA = sim.local('u', 'int', u);
        cu = u; cv = null; ce = null;
        const du = sim.r(D + 4 * u);
        if (d > du) {
          sim.step(at('if (d > dist[u]) continue'), L('Pop {' + d + ', ' + u + '}. But dist[' + u + '] is already ' + du + ' &lt; ' + d + ': this entry is <b>stale</b> (pushed before a better path was found). Skip it.', 'ดึง {' + d + ', ' + u + '} แต่ dist[' + u + '] เป็น ' + du + ' &lt; ' + d + ' แล้ว: รายการนี้<b>ล้าสมัย</b> (ถูก push ก่อนเจอเส้นทางที่ดีกว่า) ข้าม'), { lines: [at('auto [d, u] = pq.top()')], cls: 'warn' });
          sim.drop('u'); sim.drop('d'); continue;
        }
        settled.add(u);
        sim.step(at('auto [d, u] = pq.top()'), L('Pop the smallest entry {' + d + ', ' + u + '}. Every other entry is ≥ ' + d + ' and weights are non-negative, so no other route can reach ' + u + ' more cheaply: dist[' + u + '] = ' + d + ' is <b>final</b>.', 'ดึงรายการที่เล็กที่สุด {' + d + ', ' + u + '} รายการอื่นทุกตัว ≥ ' + d + ' และน้ำหนักไม่ติดลบ จึงไม่มีทางอื่นถึง ' + u + ' ได้ถูกกว่านี้: dist[' + u + '] = ' + d + ' เป็น<b>ค่าสุดท้าย</b>'), { lines: [at('while (!pq.empty())')] });
        const vA = sim.local('v', 'int', undefined), wA = sim.local('w', 'int', undefined);
        for (const { v, w, k } of adj[u]) {
          sim.w(vA, v); sim.w(wA, w); cv = v; ce = k;
          const a = sim.r(D + 4 * u), b = sim.r(D + 4 * v);
          if (a + w < b) {
            sim.w(D + 4 * v, a + w); pq.push([a + w, v]); parentE[v] = k;
            sim.step(at('dist[v] = dist[u] + w'), L('Edge ' + u + '→' + v + ' (w ' + w + '): ' + a + ' + ' + w + ' = ' + (a + w) + ' &lt; dist[' + v + '] = ' + fmtD(b) + '. <b>Relax</b>: dist[' + v + '] = ' + (a + w) + ', push {' + (a + w) + ', ' + v + '}.', 'เส้น ' + u + '→' + v + ' (w ' + w + '): ' + a + ' + ' + w + ' = ' + (a + w) + ' &lt; dist[' + v + '] = ' + fmtD(b) + ' <b>relax</b>: dist[' + v + '] = ' + (a + w) + ' แล้ว push {' + (a + w) + ', ' + v + '}'), { lines: [at('if (dist[u] + w < dist[v])'), at('pq.push({dist[v], v})')] });
          } else {
            sim.step(at('if (dist[u] + w < dist[v])'), L('Edge ' + u + '→' + v + ' (w ' + w + '): ' + a + ' + ' + w + ' = ' + (a + w) + ' is not better than dist[' + v + '] = ' + fmtD(b) + '. Nothing changes.', 'เส้น ' + u + '→' + v + ' (w ' + w + '): ' + a + ' + ' + w + ' = ' + (a + w) + ' ไม่ดีกว่า dist[' + v + '] = ' + fmtD(b) + ' ไม่มีอะไรเปลี่ยน'), { lines: [at('for (auto [v, w] : adj[u])')] });
          }
        }
        cv = null; ce = null;
        sim.drop('w'); sim.drop('v'); sim.drop('u'); sim.drop('d');
      }
      cu = null;
      let out = ''; for (let i = 0; i < n; i++) out += sim.r(D + 4 * i) + ' ';
      sim.print(out + '\n');
      sim.step(at('for (int i = 0; i < n'), L('The queue is empty. Each relaxation pushes one entry, so the pq holds at most E entries: O(E log E) in total.', 'คิวว่าง การ relax แต่ละครั้ง push หนึ่งรายการ pq จึงมีไม่เกิน E รายการ: รวม O(E log E)'));
      sim.ret(0, { show: false });
    }
  });

  // ---------------------------------------------------------------- Kruskal + DSU
  const krCode = (n, E) => `int parent[${n}];
int find(int x) {
  if (parent[x] == x) return x;            // x is a root
  return parent[x] = find(parent[x]);      // path compression
}
int main() {
  int n = ${n};
  int E[${E.length}][3] = {${E.map(e => '{' + e.w + ',' + e.a + ',' + e.b + '}').join(', ')}};   // {w, u, v}, sorted by w
  for (int i = 0; i < n; i++) parent[i] = i;
  int total = 0;
  for (int k = 0; k < ${E.length}; k++) {
    int ru = find(E[k][1]), rv = find(E[k][2]);
    if (ru == rv) continue;                // same component: would make a cycle
    parent[ru] = rv;                       // union
    total += E[k][0];
  }
  cout << total << "\\n";
}
`;
  def({
    id: 'kruskal', part: 3, lesson: '18', lessonFile: '18-mst-dsu.md',
    title: L('Kruskal + DSU: cheapest edges, no cycles', 'Kruskal + DSU: เส้นที่ถูกที่สุด ไม่มีวงจร'),
    summary: L('Take edges from lightest to heaviest and keep one only if its ends are in different components. The disjoint-set union (DSU) answers "same component?" with find(), which walks parent[] up to the root, and squashes the path as it returns (path compression).',
      'หยิบเส้นเชื่อมจากเบาไปหนัก และเก็บไว้ก็ต่อเมื่อปลายทั้งสองอยู่คนละส่วน DSU ตอบคำถาม "อยู่ส่วนเดียวกันไหม" ด้วย find() ที่เดินตาม parent[] ขึ้นไปถึงราก และบีบเส้นทางให้สั้นลงตอนคืนกลับ (path compression)'),
    blurb: L('parent[], recursive find with path compression, union.', 'parent[] find แบบเรียกซ้ำพร้อม path compression และ union'),
    params: [{ id: 'g', label: L('Weighted edges (undirected)', 'เส้นเชื่อมมีน้ำหนัก (ไม่มีทิศ)'), value: '0-1:4, 0-2:3, 1-2:1, 1-3:2, 2-3:4, 3-4:2, 4-5:6, 3-5:5' }],
    paramHint: L('u-v:w, vertices 0–7, weights 1–99 · edges are sorted for you', 'u-v:w จุดยอด 0–7 น้ำหนัก 1–99 · เรียงเส้นเชื่อมให้อัตโนมัติ'),
    code: (() => { const { n, edges } = parseEdges('0-1:4, 0-2:3, 1-2:1, 1-3:2, 2-3:4, 3-4:2, 4-5:6, 3-5:5', true); return krCode(n, edges.slice().sort((x, y) => x.w - y.w)); })(),
    codeFn: p => { try { const { n, edges } = parseEdges(p.g, true); return krCode(n, edges.slice().sort((x, y) => x.w - y.w)); } catch (e) { return krCode(2, [{ a: 0, b: 1, w: 1 }]); } },
    build(sim, prm) {
      const g0 = parseEdges(prm.g, true), n = g0.n, E = g0.edges.slice().sort((x, y) => x.w - y.w), code = krCode(n, E), at = LN(code), pos = layout(n, E);
      let ck = null, mst = new Set(), rej = new Set(), hiV = [];
      sim.viewFn = S => {
        const Pv = mainVar(S, 'parent'); if (!Pv) return null;
        const root = i => { let x = i, g = 0; while (Pv.cells[x] !== undefined && Pv.cells[x] !== x && g++ < 20) x = Pv.cells[x]; return x; };
        const g = graphView(n, E, pos, i => hiV.includes(i) ? 'hl' : '', i => Pv.cells[i] === undefined ? '' : 'root ' + root(i), (e, k) => k === ck ? 'hl' : (mst.has(k) ? 'ok' : (rej.has(k) ? 'bad' : null)), true, 220);
        g.cap = L('Green = in the tree, red = rejected (would close a cycle), teal = edge being considered. Under each vertex: its current root.', 'เขียว = อยู่ในต้นไม้ แดง = ถูกปฏิเสธ (จะปิดวงจร) ฟ้าอมเขียว = เส้นที่กำลังพิจารณา ใต้จุดยอดแต่ละจุด: รากปัจจุบันของมัน');
        // DSU forest as a tree view under a virtual root
        const nodes = { R: { label: '', kids: [], cls: 'dim' } };
        for (let i = 0; i < n; i++) nodes['v' + i] = { label: String(i), kids: [], cls: hiV.includes(i) ? 'hl' : '' };
        let ok = true;
        for (let i = 0; i < n; i++) { const p = Pv.cells[i]; if (p === undefined) { ok = false; break; } if (p === i) nodes.R.kids.push('v' + i); else nodes['v' + p].kids.push('v' + i); }
        const parts = [g, { kind: 'array', rows: [{ label: 'parent', cells: Pv.cells.map(c => c === undefined ? '?' : c), cls: Pv.cells.map((c, i) => hiV.includes(i) ? 'hl' : (c === i ? 'ok' : '')) }] }];
        if (ok) parts.push({ kind: 'tree', cap: L('The DSU forest: each vertex hangs under parent[v]; roots hang under the (invisible) top.', 'ป่า DSU: จุดยอดแต่ละจุดห้อยใต้ parent[v] รากห้อยใต้จุดบนสุด (ที่มองไม่เห็น)'), nodes, root: 'R', square: true, gy: 46, gx: 46, r: 15 });
        return { kind: 'multi', title: L('graph and disjoint sets', 'กราฟและเซตไม่มีส่วนร่วม'), parts };
      };
      sim.call('main()');
      const PA = sim.arr('parent', 'int', n, 0);
      sim.step(at('int main'), L('<code>parent</code> is a global (drawn in main\'s frame for compactness), so it starts all zeros.', '<code>parent</code> เป็น global (วาดไว้ในเฟรมของ main เพื่อความกะทัดรัด) จึงเริ่มเป็นศูนย์ทั้งหมด'));
      sim.local('n', 'int', n);
      const EA = sim.arr('E', 'int', E.length * 3, E.flatMap(e => [e.w, e.a, e.b]));
      const ev = sim.top().vars.find(v => v.name === 'E'); ev.type = 'int[' + E.length + '][3]'; ev.cols = 3;
      sim.step(at('int E['), L('The edges as {w, u, v} rows, already sorted by weight (in a real program: <code>sort(E, E + m)</code>).', 'เส้นเชื่อมเป็นแถว {w, u, v} เรียงตามน้ำหนักแล้ว (ในโปรแกรมจริง: <code>sort(E, E + m)</code>)'));
      for (let i = 0; i < n; i++) sim.w(PA + 4 * i, i);
      sim.step(at('parent[i] = i'), L('parent[i] = i: every vertex starts as its own root, a component of size 1.', 'parent[i] = i: ทุกจุดยอดเริ่มเป็นรากของตัวเอง เป็นส่วนที่มีขนาด 1'));
      const totA = sim.local('total', 'int', 0);
      const kA = sim.local('k', 'int', 0);
      const find = (x, callLine) => {
        sim.top().line = callLine;
        sim.call('find(int x)'); sim.param('x', 'int', x);
        const p = sim.r(PA + 4 * x);
        hiV = [x];
        if (p === x) {
          sim.step(at('if (parent[x] == x)'), L('find(' + x + '): parent[' + x + '] = ' + x + ', so ' + x + ' is a root. Return ' + x + '.', 'find(' + x + '): parent[' + x + '] = ' + x + ' ดังนั้น ' + x + ' เป็นราก คืน ' + x));
          sim.ret(x, { type: 'int' }); return x;
        }
        sim.step(at('if (parent[x] == x)'), L('find(' + x + '): parent[' + x + '] = ' + p + ', not a root. Ask find(' + p + ') and wait.', 'find(' + x + '): parent[' + x + '] = ' + p + ' ไม่ใช่ราก ถาม find(' + p + ') แล้วรอ'));
        const r = find(p, at('return parent[x] = find'));
        hiV = [x];
        sim.w(PA + 4 * x, r);
        sim.step(at('return parent[x] = find'), r !== p ? L('Back in find(' + x + '): the root is ' + r + '. <b>Path compression</b>: parent[' + x + '] = ' + r + ' (was ' + p + '), so next time ' + x + ' reaches the root in one hop.', 'กลับมาที่ find(' + x + '): รากคือ ' + r + ' <b>path compression</b>: parent[' + x + '] = ' + r + ' (เดิม ' + p + ') ครั้งหน้า ' + x + ' จะถึงรากในก้าวเดียว') : L('Back in find(' + x + '): the root is ' + r + ', which is already its parent.', 'กลับมาที่ find(' + x + '): รากคือ ' + r + ' ซึ่งเป็น parent ของมันอยู่แล้ว'));
        sim.ret(r, { type: 'int' }); return r;
      };
      let total = 0;
      E.forEach((e, k) => {
        sim.w(kA, k); ck = E.indexOf(e); hiV = [e.a, e.b];
        sim.step(at('for (int k = 0; k <'), L('Edge ' + k + ': ' + e.a + '–' + e.b + ' with weight ' + e.w + ' (the lightest one not tried yet).', 'เส้นที่ ' + k + ': ' + e.a + '–' + e.b + ' น้ำหนัก ' + e.w + ' (เส้นที่เบาที่สุดที่ยังไม่ได้ลอง)'));
        const ru = find(sim.r(EA + 4 * (3 * k + 1)), at('int ru = find'));
        const ruA = sim.local('ru', 'int', ru);
        const rv = find(sim.r(EA + 4 * (3 * k + 2)), at('int ru = find'));
        const rvA = sim.local('rv', 'int', rv);
        hiV = [e.a, e.b];
        sim.step(at('int ru = find'), L('ru = find(' + e.a + ') = ' + ru + ', rv = find(' + e.b + ') = ' + rv + '.', 'ru = find(' + e.a + ') = ' + ru + ', rv = find(' + e.b + ') = ' + rv));
        if (ru === rv) {
          rej.add(k);
          sim.step(at('if (ru == rv) continue'), L('Same root ' + ru + ': ' + e.a + ' and ' + e.b + ' are already connected. Adding this edge would close a cycle. <b>Reject</b>.', 'รากเดียวกัน ' + ru + ': ' + e.a + ' กับ ' + e.b + ' เชื่อมกันอยู่แล้ว ถ้าเพิ่มเส้นนี้จะปิดวงจร <b>ปฏิเสธ</b>'), { cls: 'warn' });
        } else {
          sim.w(PA + 4 * ru, rv); mst.add(k); hiV = [ru, rv];
          sim.step(at('parent[ru] = rv'), L('Different roots. <b>Union</b>: parent[' + ru + '] = ' + rv + '. The whole component of ' + ru + ' now hangs under ' + rv + ' with one write.', 'รากต่างกัน <b>รวม</b>: parent[' + ru + '] = ' + rv + ' ทั้งส่วนของ ' + ru + ' ไปห้อยใต้ ' + rv + ' ด้วยการเขียนครั้งเดียว'));
          total += e.w; sim.w(totA, total);
          sim.step(at('total += E[k][0]'), L('total = ' + total + '.', 'total = ' + total));
        }
        sim.drop('rv'); sim.drop('ru');
      });
      ck = null; hiV = [];
      sim.drop('k');
      sim.print(sim.r(totA) + '\n');
      sim.step(at('cout << total'), L('The minimum spanning tree weighs <b>' + total + '</b> and uses ' + mst.size + ' edges' + (mst.size === n - 1 ? ' (n − 1, as every spanning tree does).' : ' (fewer than n − 1: the graph is not connected).') + ' Sorting costs O(E log E); with path compression each find is almost O(1).', 'ต้นไม้แผ่กว้างน้อยที่สุดหนัก <b>' + total + '</b> และใช้ ' + mst.size + ' เส้น' + (mst.size === n - 1 ? ' (n − 1 เหมือนต้นไม้แผ่กว้างทุกต้น)' : ' (น้อยกว่า n − 1: กราฟไม่เชื่อมกันทั้งหมด)') + ' การเรียงใช้ O(E log E) ด้วย path compression แต่ละ find เกือบเป็น O(1)'));
      sim.ret(0, { show: false });
    }
  });
})();
