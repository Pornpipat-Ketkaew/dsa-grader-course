/* Part II · CP::priority_queue (real code from priority_queue.h) */
(() => {
  const CLS = `namespace CP {
template <typename T,typename Comp = std::less<T> >
class priority_queue {
  protected:
    T *mData;
    size_t mCap;
    size_t mSize;
    Comp mLess;

    void expand(size_t capacity) {
      T *arr = new T[capacity]();
      for (size_t i = 0;i < mSize;i++) {
        arr[i] = mData[i];
      }
      delete [] mData;
      mData = arr;
      mCap = capacity;
    }
    void fixUp(size_t idx) {
      T tmp = mData[idx];
      while (idx > 0) {
        size_t p = (idx - 1) / 2;
        if ( mLess(tmp,mData[p]) ) break;
        mData[idx] = mData[p];
        idx = p;
      }
      mData[idx] = tmp;
    }
    void fixDown(size_t idx) {
      T tmp = mData[idx];
      size_t c;
      while ((c = 2 * idx + 1) < mSize) {
        if (c + 1 < mSize && mLess(mData[c],mData[c + 1]) ) c++;
        if ( mLess(mData[c],tmp) ) break;
        mData[idx] = mData[c];
        idx = c;
      }
      mData[idx] = tmp;
    }
  public:
    priority_queue(const Comp& c = Comp() ) :
       mData( new T[1]() ), mCap( 1 ), mSize( 0 ), mLess( c ) { }
    const T& top() { return mData[0]; }
    void push(const T& element) {
      if (mSize + 1 > mCap)
        expand(mCap * 2);
      mData[mSize] = element;
      mSize++;
      fixUp(mSize-1);
    }
    void pop() {
      mData[0] = mData[mSize-1];
      mSize--;
      fixDown(0);
    }
};
}
int main() {
`;
  const parse = str => {
    const ops = parseOps(str, 16).map(o => {
      if (o[0] === 'push') { if (typeof o[1] !== 'number') throw userErr(L('push needs a number.', 'push ต้องมีตัวเลข')); return ['push', o[1]]; }
      if (o[0] === 'pop' || o[0] === 'top') return [o[0]];
      throw userErr(L('Unknown operation "' + o[0] + '". Use push x, pop, top.', 'ไม่รู้จักคำสั่ง "' + o[0] + '" ใช้ได้: push x, pop, top'));
    });
    if (!ops.length) throw userErr(L('Type at least one operation.', 'ใส่คำสั่งอย่างน้อยหนึ่งคำสั่ง'));
    return ops;
  };
  const isMin = p => /greater|min/i.test(p.comp || '');
  const codeOf = (ops, min) => CLS + (min ? '  CP::priority_queue<int, std::greater<int> > pq;\n' : '  CP::priority_queue<int> pq;\n') +
    ops.map(o => o[0] === 'push' ? '  pq.push(' + o[1] + ');' : o[0] === 'pop' ? '  pq.pop();' : '  cout << pq.top() << "\\n";').join('\n') + '\n}\n';
  const DEF = 'push 20, push 50, push 30, push 70, push 10, push 60, top, pop, top, pop';
  def({
    id: 'cp-heap', part: 2, lesson: '06', lessonFile: '06-heap-priority-queue.md', dangOK: true,
    title: L('CP::priority_queue: a heap inside an array', 'CP::priority_queue: heap ในอาร์เรย์'),
    summary: L('A binary heap is a complete tree stored in an array with no pointers: the children of i are 2i+1 and 2i+2, and the parent is (i−1)/2. push bubbles the new value up (fixUp), pop moves the last value to the root and sinks it (fixDown). Notice the real code carries the value in tmp and moves the others into the "hole", instead of swapping.',
      'binary heap คือต้นไม้สมบูรณ์ที่เก็บในอาร์เรย์โดยไม่มีพอยน์เตอร์ ลูกของ i คือ 2i+1 และ 2i+2 พ่อคือ (i−1)/2 push ดันค่าใหม่ขึ้น (fixUp) pop ย้ายค่าสุดท้ายไปที่ราก แล้วจมลง (fixDown) สังเกตว่าโค้ดจริงถือค่าไว้ใน tmp แล้วย้ายตัวอื่นเข้า "หลุม" แทนการสลับ'),
    blurb: L('fixUp, fixDown, mLess, and why the array is a tree.', 'fixUp, fixDown, mLess และทำไมอาร์เรย์คือต้นไม้'),
    params: [{ id: 'ops', label: L('Operations', 'คำสั่ง'), value: DEF }, { id: 'comp', label: L('Comparator: less (max on top) or greater (min on top)', 'Comparator: less (ค่ามากอยู่บน) หรือ greater (ค่าน้อยอยู่บน)'), value: 'less' }],
    paramHint: L('push x · pop · top', 'push x · pop · top'),
    code: codeOf(parse(DEF), false),
    codeFn: p => { try { return codeOf(parse(p.ops), isMin(p)); } catch (e) { return CLS + '}\n'; } },
    build(sim, prm) {
      const ops = parse(prm.ops), min = isMin(prm), code = codeOf(ops, min), at = LN(code);
      const mainL = at('int main');
      const less = (a, b) => min ? a > b : a < b;
      const lessTxt = (a, b) => 'mLess(' + a + ', ' + b + ') = ' + (min ? a + ' &gt; ' + b : a + ' &lt; ' + b) + ' = ' + less(a, b);
      let pq;
      const fn = x => 'priority_queue<int>::' + x;
      const F = n => sim.pf(pq, n);
      const buf = () => F('mData').p;
      const sync = () => { const b = sim.block(buf()); if (b) { b.used = F('mSize'); b.label = L('pq.mData · mCap = ' + F('mCap'), 'pq.mData · mCap = ' + F('mCap')); } };
      sim.viewFn = S => {
        if (!pq) return null;
        const mD = S.pf(pq, 'mData'); if (!isP(mD)) return null;
        const b = S.heap.find(x => x.addr === mD.p && !x.freed); if (!b) return null;
        const n = S.pf(pq, 'mSize');
        const top = S.top(); const loc = nm => { const v = top && top.vars.find(x => x.name === nm); return v ? v.value : undefined; };
        const idx = loc('idx'), p = loc('p'), c = loc('c'), tmp = loc('tmp');
        const nodes = {};
        const lim = Math.min(n + (top && /fixUp|fixDown|push|pop/.test(top.sig) && idx != null && idx >= n ? 1 : 0), b.n);
        for (let i = 0; i < lim; i++) {
          const kids = [2 * i + 1 < lim ? 'n' + (2 * i + 1) : null, 2 * i + 2 < lim ? 'n' + (2 * i + 2) : null];
          let cls = '';
          if (i === idx && tmp !== undefined) cls = 'hl'; else if (i === p || i === c) cls = 'cmp';
          nodes['n' + i] = { label: (i === idx && tmp !== undefined) ? '◌' : fmtPlain(b.cells[i]), sub: '[' + i + ']', cls, kids };
        }
        const arrMarks = {}; const mk = (k, l) => { if (typeof k === 'number') (arrMarks[k] = arrMarks[k] || []).push(l); };
        mk(idx, 'idx'); mk(p, 'p'); mk(c, 'c');
        return {
          kind: 'multi', title: L('the same array as a tree', 'อาร์เรย์เดียวกันในรูปต้นไม้'), parts: [
            { kind: 'tree', binary: true, root: lim ? 'n0' : null, nodes, empty: L('(empty heap)', '(heap ว่าง)'), cap: tmp !== undefined && idx != null ? L('tmp = ' + fmtPlain(tmp) + ' is being carried; ◌ marks the hole at index ' + idx + '. Teal = hole, violet = being compared.', 'กำลังถือ tmp = ' + fmtPlain(tmp) + ' ◌ คือหลุมที่ดัชนี ' + idx + ' สีฟ้าอมเขียว = หลุม สีม่วง = กำลังเปรียบเทียบ') : L(min ? 'Min-heap: every parent ≤ its children, so the smallest is at index 0.' : 'Max-heap: every parent ≥ its children, so the largest is at index 0.', min ? 'Min-heap: พ่อทุกตัว ≤ ลูก ค่าน้อยสุดจึงอยู่ที่ดัชนี 0' : 'Max-heap: พ่อทุกตัว ≥ ลูก ค่ามากสุดจึงอยู่ที่ดัชนี 0') },
            { kind: 'array', rows: [{ label: 'mData', cells: b.cells.map((x, i) => i === idx && tmp !== undefined ? '◌' : fmtPlain(x)), cls: b.cells.map((x, i) => i >= lim ? 'dim' : i === idx && tmp !== undefined ? 'hl' : (i === p || i === c) ? 'cmp' : 'hp'), marks: arrMarks }] }
          ]
        };
      };
      sim.call('main()');
      sim.step(mainL, L('main starts.', 'main เริ่มทำงาน'));
      pq = sim.obj('pq', min ? 'CP::priority_queue<int,greater>' : 'CP::priority_queue<int>', [['mData', 'int*', undefined], ['mCap', 'size_t', undefined], ['mSize', 'size_t', undefined], ['mLess', 'char', '{}']]);
      const b0 = sim.newArray('int', 1, 0, { used: 0, expr: 'new int[1]()' });
      sim.wf(pq, 'mData', P(b0)); sim.wf(pq, 'mCap', 1); sim.wf(pq, 'mSize', 0); sync();
      sim.step(mainL + 1, L(
        'The constructor makes a 1-slot buffer, exactly like CP::vector. The 4th field <code>mLess</code> is the comparator object (' + (min ? 'std::greater' : 'std::less') + '): it has no data, so it takes 1 byte (plus padding). <b>mLess(a, b) == true means "a has lower priority than b"</b>.',
        'คอนสตรักเตอร์สร้างบัฟเฟอร์ 1 ช่องเหมือน CP::vector ฟิลด์ที่ 4 <code>mLess</code> คืออ็อบเจกต์ comparator (' + (min ? 'std::greater' : 'std::less') + ') ไม่มีข้อมูลข้างใน จึงใช้แค่ 1 ไบต์ (บวก padding) <b>mLess(a, b) == true แปลว่า "a มีลำดับความสำคัญต่ำกว่า b"</b>'));
      const fixUp = (start) => {
        sim.call(fn('fixUp(size_t idx)')); sim.param('this', 'priority_queue*', P(pq));
        const idxA = sim.param('idx', 'size_t', start);
        const B = buf();
        const tmp = sim.r(B + 4 * start);
        sim.local('tmp', 'int', tmp);
        sim.step(at('T tmp = mData[idx];', 1), L('fixUp(' + start + '): copy the new value ' + tmp + ' into <code>tmp</code>. Slot ' + start + ' is now a "hole" we can move things into.', 'fixUp(' + start + '): คัดลอกค่าใหม่ ' + tmp + ' ไว้ใน <code>tmp</code> ช่อง ' + start + ' กลายเป็น "หลุม" ที่ย้ายของเข้าไปได้'));
        let idx = start;
        const pA = sim.local('p', 'size_t', undefined);
        while (idx > 0) {
          const p = Math.floor((idx - 1) / 2);
          sim.w(pA, p);
          sim.step(at('size_t p = (idx - 1) / 2'), L('idx = ' + idx + ' &gt; 0. Parent p = (' + idx + ' − 1) / 2 = ' + p + '.', 'idx = ' + idx + ' &gt; 0 พ่อคือ p = (' + idx + ' − 1) / 2 = ' + p));
          const pv = sim.r(B + 4 * p);
          if (less(tmp, pv)) {
            sim.step(at('if ( mLess(tmp,mData[p]) ) break;'), L(lessTxt(tmp, pv) + ': the parent already has higher priority, so <b>stop</b>.', lessTxt(tmp, pv) + ': พ่อมีลำดับความสำคัญสูงกว่าแล้ว จึง<b>หยุด</b>'));
            break;
          }
          sim.step(at('if ( mLess(tmp,mData[p]) ) break;'), L(lessTxt(tmp, pv) + ': tmp should be above its parent ' + pv + '.', lessTxt(tmp, pv) + ': tmp ควรอยู่เหนือพ่อ ' + pv));
          sim.w(B + 4 * idx, pv);
          sim.step(at('mData[idx] = mData[p];'), L('Move the parent ' + pv + ' <b>down</b> into the hole at ' + idx + ' (one write, not a swap).', 'ย้ายพ่อ ' + pv + ' <b>ลง</b>มาในหลุมที่ ' + idx + ' (เขียนครั้งเดียว ไม่ใช่การสลับ)'));
          idx = p; sim.w(idxA, idx);
          sim.step(at('idx = p;', 1), L('The hole moves up to ' + idx + '.', 'หลุมเลื่อนขึ้นไปที่ ' + idx));
        }
        if (idx === 0) sim.step(at('while (idx > 0)'), L('idx = 0: we reached the root.', 'idx = 0: ถึงรากแล้ว'));
        sim.w(B + 4 * idx, tmp);
        sim.step(at('mData[idx] = tmp;', 1), L('Drop tmp (' + tmp + ') into the final hole at index ' + idx + '. At most ⌊log₂ n⌋ levels were climbed: O(log n).', 'วาง tmp (' + tmp + ') ลงในหลุมสุดท้ายที่ดัชนี ' + idx + ' ปีนขึ้นไปไม่เกิน ⌊log₂ n⌋ ชั้น: O(log n)'));
        sim.ret(undefined, { show: false });
      };
      const fixDown = (start) => {
        sim.call(fn('fixDown(size_t idx)')); sim.param('this', 'priority_queue*', P(pq));
        const idxA = sim.param('idx', 'size_t', start);
        const B = buf(), n = F('mSize');
        const tmp = sim.r(B + 4 * start);
        sim.local('tmp', 'int', tmp);
        sim.step(at('T tmp = mData[idx];', 2), L('fixDown(0): carry the moved value ' + tmp + ' in tmp; the root is the hole.', 'fixDown(0): ถือค่าที่ถูกย้ายมา ' + tmp + ' ไว้ใน tmp รากกลายเป็นหลุม'));
        const cA = sim.local('c', 'size_t', undefined);
        let idx = start;
        while (true) {
          let c = 2 * idx + 1;
          sim.w(cA, c);
          if (c >= n) { sim.step(at('while ((c = 2 * idx + 1) < mSize)'), L('c = 2×' + idx + '+1 = ' + c + ' ≥ mSize (' + n + '): index ' + idx + ' has no children, stop.', 'c = 2×' + idx + '+1 = ' + c + ' ≥ mSize (' + n + '): ดัชนี ' + idx + ' ไม่มีลูก หยุด')); break; }
          sim.step(at('while ((c = 2 * idx + 1) < mSize)'), L('Left child c = 2×' + idx + '+1 = ' + c + '.', 'ลูกซ้าย c = 2×' + idx + '+1 = ' + c));
          if (c + 1 < n) {
            const a = sim.r(B + 4 * c), bb = sim.r(B + 4 * (c + 1));
            if (less(a, bb)) { c++; sim.w(cA, c); }
            sim.step(at('if (c + 1 < mSize'), L('Both children exist: ' + lessTxt(a, bb) + ', so pick the higher-priority child: index ' + c + ' (' + fmtPlain(sim.peek(B + 4 * c)) + ').', 'มีลูกทั้งสองข้าง: ' + lessTxt(a, bb) + ' จึงเลือกลูกที่สำคัญกว่า: ดัชนี ' + c + ' (' + fmtPlain(sim.peek(B + 4 * c)) + ')'));
          }
          const cv = sim.r(B + 4 * c);
          if (less(cv, tmp)) { sim.step(at('if ( mLess(mData[c],tmp) ) break;'), L(lessTxt(cv, tmp) + ': the best child is lower than tmp, so tmp belongs here. <b>Stop</b>.', lessTxt(cv, tmp) + ': ลูกที่ดีที่สุดยังต่ำกว่า tmp ดังนั้น tmp ควรอยู่ตรงนี้ <b>หยุด</b>')); break; }
          sim.step(at('if ( mLess(mData[c],tmp) ) break;'), L(lessTxt(cv, tmp) + ': the child ' + cv + ' must move up.', lessTxt(cv, tmp) + ': ลูก ' + cv + ' ต้องเลื่อนขึ้น'));
          sim.w(B + 4 * idx, cv);
          sim.step(at('mData[idx] = mData[c];'), L('Move ' + cv + ' <b>up</b> into the hole at ' + idx + '.', 'ย้าย ' + cv + ' <b>ขึ้น</b>ไปในหลุมที่ ' + idx));
          idx = c; sim.w(idxA, idx);
          sim.step(at('idx = c;'), L('The hole sinks to ' + idx + '.', 'หลุมจมลงไปที่ ' + idx));
        }
        sim.w(B + 4 * idx, tmp);
        sim.step(at('mData[idx] = tmp;', 2), L('Put tmp (' + tmp + ') into the hole at ' + idx + '. O(log n).', 'ใส่ tmp (' + tmp + ') ลงในหลุมที่ ' + idx + ' O(log n)'));
        sim.ret(undefined, { show: false });
      };
      ops.forEach((o, k) => {
        const L0 = mainL + 2 + k;
        const n = F('mSize');
        if (o[0] === 'push') {
          const t = sim.local('temp', 'int', o[1]);
          sim.step(L0, L('<code>pq.push(' + o[1] + ')</code>.', '<code>pq.push(' + o[1] + ')</code>'));
          sim.call(fn('push(const T& element)')); sim.param('this', 'priority_queue*', P(pq)); sim.ref('element', 'const int', t, { param: true });
          const cap = sim.rf(pq, 'mCap');
          if (n + 1 > cap) {
            sim.step(at('if (mSize + 1 > mCap)'), L('mSize + 1 = ' + (n + 1) + ' &gt; mCap = ' + cap + ': the buffer is full. Note that this class calls <code>expand(mCap * 2)</code> directly (no ensureCapacity).', 'mSize + 1 = ' + (n + 1) + ' &gt; mCap = ' + cap + ': บัฟเฟอร์เต็ม สังเกตว่าคลาสนี้เรียก <code>expand(mCap * 2)</code> ตรง ๆ (ไม่มี ensureCapacity)'));
            sim.call(fn('expand(size_t capacity)')); sim.param('this', 'priority_queue*', P(pq)); sim.param('capacity', 'size_t', cap * 2);
            const old = buf();
            const nb = sim.newArray('int', cap * 2, 0, { expr: 'new int[' + cap * 2 + ']()', used: n });
            for (let i = 0; i < n; i++) sim.w(nb + 4 * i, sim.r(old + 4 * i));
            sim.local('arr', 'int*', P(nb));
            sim.step(at('T *arr = new T[capacity]()'), L('Allocate ' + (cap * 2) + ' slots and copy the ' + n + ' element(s) over (the copy loop is shown as one step here; see CP::vector for each copy).', 'จอง ' + (cap * 2) + ' ช่องแล้วคัดลอกสมาชิก ' + n + ' ตัว (แสดงลูปคัดลอกเป็นขั้นเดียว ดูทีละตัวได้ในบท CP::vector)'));
            sim.free(old); sim.wf(pq, 'mData', P(nb)); sim.wf(pq, 'mCap', cap * 2); sync();
            sim.step(at('mCap = capacity'), L('Free the old buffer; mData and mCap now describe the new one.', 'คืนบัฟเฟอร์เก่า ตอนนี้ mData และ mCap อธิบายบัฟเฟอร์ใหม่'));
            sim.ret(undefined, { show: false });
          } else sim.step(at('if (mSize + 1 > mCap)'), L('There is room (mSize + 1 = ' + (n + 1) + ' ≤ mCap = ' + cap + ').', 'มีที่ว่าง (mSize + 1 = ' + (n + 1) + ' ≤ mCap = ' + cap + ')'));
          sim.r(t); sim.w(buf() + 4 * n, o[1]); sim.block(buf()).used = n + 1;
          sim.step(at('mData[mSize] = element'), L('Put ' + o[1] + ' in the next free slot, index ' + n + '. This keeps the tree <b>complete</b> (filled left to right), but may break the heap order with its parent.', 'ใส่ ' + o[1] + ' ในช่องว่างถัดไป ดัชนี ' + n + ' ทำให้ต้นไม้ยัง<b>สมบูรณ์</b> (เติมจากซ้ายไปขวา) แต่อาจผิดลำดับ heap กับพ่อของมัน'));
          sim.wf(pq, 'mSize', n + 1); sync();
          sim.step(at('mSize++'), L('mSize = ' + (n + 1) + '.', 'mSize = ' + (n + 1)));
          fixUp(n);
          sim.ret(undefined, { show: false }); sim.drop('temp');
          sim.step(L0, L('Heap array: [' + cellsOf(sim, buf()).slice(0, n + 1).join(', ') + '].', 'อาร์เรย์ heap: [' + cellsOf(sim, buf()).slice(0, n + 1).join(', ') + ']'));
        } else if (o[0] === 'pop') {
          if (n === 0) throw userErr(L('pop on an empty priority_queue throws out_of_range.', 'pop ตอน priority_queue ว่างจะโยน out_of_range'));
          sim.step(L0, L('<code>pq.pop()</code> removes the top (' + fmtPlain(sim.peek(buf())) + ').', '<code>pq.pop()</code> เอา top (' + fmtPlain(sim.peek(buf())) + ') ออก'));
          sim.call(fn('pop()')); sim.param('this', 'priority_queue*', P(pq));
          const last = sim.r(buf() + 4 * (n - 1)); sim.w(buf(), last);
          sim.step(at('mData[0] = mData[mSize-1]'), L('Overwrite the root with the <b>last</b> element (' + last + '). The old top is gone. The tree stays complete, but ' + last + ' is probably too low for the root.', 'เขียนทับรากด้วยสมาชิก<b>ตัวสุดท้าย</b> (' + last + ') top เดิมหายไป ต้นไม้ยังสมบูรณ์ แต่ ' + last + ' น่าจะต่ำเกินไปสำหรับราก'));
          sim.wf(pq, 'mSize', n - 1); sync();
          sim.step(at('mSize--'), L('mSize = ' + (n - 1) + '.', 'mSize = ' + (n - 1)));
          if (n - 1 > 0) fixDown(0);
          else { sim.call(fn('fixDown(size_t idx)')); sim.param('this', 'priority_queue*', P(pq)); sim.param('idx', 'size_t', 0); sim.step(at('while ((c = 2 * idx + 1) < mSize)'), L('The heap is now empty; fixDown does nothing useful.', 'heap ว่างแล้ว fixDown ไม่ต้องทำอะไร')); sim.ret(undefined, { show: false }); }
          sim.ret(undefined, { show: false });
          sim.step(L0, L('Heap array: [' + cellsOf(sim, buf()).slice(0, n - 1).join(', ') + '].', 'อาร์เรย์ heap: [' + cellsOf(sim, buf()).slice(0, n - 1).join(', ') + ']'));
        } else {
          if (n === 0) throw userErr(L('top on an empty priority_queue throws out_of_range.', 'top ตอน priority_queue ว่างจะโยน out_of_range'));
          const val = sim.r(buf()); sim.print(val + '\n');
          sim.step(L0, L('top() is just mData[0] = ' + val + ': O(1).', 'top() ก็คือ mData[0] = ' + val + ': O(1)'));
        }
      });
      sim.step(mainL + 2 + ops.length, L('Done. Remember: a heap is <b>not</b> sorted; only the root is guaranteed to be the ' + (min ? 'minimum' : 'maximum') + '. Children of i: 2i+1, 2i+2. Parent: (i−1)/2.', 'เสร็จ จำไว้ว่า heap <b>ไม่ได้</b>เรียงลำดับ รับประกันแค่รากเป็นค่า' + (min ? 'น้อยสุด' : 'มากสุด') + ' ลูกของ i: 2i+1, 2i+2 พ่อ: (i−1)/2'));
    }
  });
})();
