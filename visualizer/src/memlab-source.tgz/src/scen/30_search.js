/* Part III · binary search and prefix sums (lesson 08) */
(() => {
  // ---------------------------------------------------------------- binary search
  const bsCode = (a, x) => `int lowerBound(int a[], int n, int x) {
  int lo = 0, hi = n;          // the answer is somewhere in [lo, hi]
  while (lo < hi) {
    int mid = (lo + hi) / 2;
    if (a[mid] < x) lo = mid + 1;   // a[mid] is too small: answer is right of mid
    else hi = mid;                  // a[mid] >= x: mid itself could be the answer
  }
  return lo;                   // first index with a[i] >= x (n if none)
}
int main() {
  int a[${a.length}] = {${a.join(', ')}};
  int x = ${x};
  int pos = lowerBound(a, ${a.length}, x);
  cout << pos << "\\n";
}
`;
  const bsParse = p => {
    const a = parseNums(p.arr, 12).sort((u, v) => u - v);
    if (a.length < 1) throw userErr(L('Give at least one number.', 'ใส่ตัวเลขอย่างน้อยหนึ่งตัว'));
    const x = parseNums(p.x, 1)[0];
    if (x === undefined) throw userErr(L('Give a number to search for.', 'ใส่ตัวเลขที่จะค้นหา'));
    return { a, x };
  };
  def({
    id: 'binary-search', part: 3, lesson: '08', lessonFile: '08-binary-search-prefix-sums.md',
    title: L('Binary search: halving the range', 'Binary search: ผ่าครึ่งช่วงค้นหา'),
    summary: L('lower_bound on a sorted array. Every step looks at the middle and throws away half of the candidates, so 1,000,000 elements need only about 20 steps. Also notice that the array is passed as a pointer: lowerBound reads main\'s boxes directly.',
      'lower_bound บนอาเรย์ที่เรียงแล้ว ทุกขั้นดูตรงกลางแล้วทิ้งผู้สมัครไปครึ่งหนึ่ง สมาชิก 1,000,000 ตัวจึงใช้แค่ราว 20 ขั้น และสังเกตว่าอาเรย์ถูกส่งไปเป็นพอยน์เตอร์ lowerBound อ่านกล่องของ main โดยตรง'),
    blurb: L('lo / mid / hi, the invariant, and arrays passed as pointers.', 'lo / mid / hi, invariant และการส่งอาเรย์เป็นพอยน์เตอร์'),
    params: [{ id: 'arr', label: L('Array (sorted for you)', 'อาเรย์ (เรียงให้อัตโนมัติ)'), value: '3 8 15 21 30 42 57 64' }, { id: 'x', label: 'x', value: '30', w: 70 }],
    paramHint: L('up to 12 numbers · try an x that is missing, or bigger than everything', 'ไม่เกิน 12 ตัว · ลอง x ที่ไม่มีในอาเรย์ หรือมากกว่าทุกตัว'),
    code: bsCode([3, 8, 15, 21, 30, 42, 57, 64], 30),
    codeFn: p => { try { const { a, x } = bsParse(p); return bsCode(a, x); } catch (e) { return bsCode([1], 1); } },
    build(sim, prm) {
      const { a, x } = bsParse(prm), n = a.length, code = bsCode(a, x), at = LN(code);
      let lo = null, hi = null, mid = null, base = 0;
      sim.viewFn = S => {
        if (!base) return null;
        const v = S.frames[0] && S.frames[0].vars.find(q => q.name === 'a'); if (!v) return null;
        const marks = {}, cls = [];
        const add = (i, t) => { (marks[i] = marks[i] || []).push(t); };
        if (lo != null) add(lo, 'lo'); if (hi != null) add(hi, 'hi'); if (mid != null) add(mid, 'mid');
        for (let i = 0; i < n; i++) cls.push(lo == null ? '' : (i === mid ? 'hl' : (i >= lo && i < hi ? '' : 'dim')));
        const ranges = lo != null && hi > lo ? [{ a: lo, b: hi - 1, label: L('still possible: [lo, hi)', 'ยังเป็นไปได้: [lo, hi)') }] : [];
        return { kind: 'array', title: L('the search range', 'ช่วงที่ค้นหา'), cap: L('Grey cells are already ruled out. The answer always stays inside [lo, hi]; hi = ' + n + ' means "past the end".', 'ช่องสีเทาถูกตัดทิ้งแล้ว คำตอบอยู่ใน [lo, hi] เสมอ hi = ' + n + ' หมายถึง "เลยท้ายอาเรย์"'),
          rows: [{ label: 'a', cells: v.cells.map(fmtPlain), marks, cls, ranges }] };
      };
      sim.tagFn = S => { const t = []; const f = S.frames[S.frames.length - 1]; if (base && f && f.sig.startsWith('lowerBound')) { if (mid != null) t.push(TAG(base + 4 * mid, 'a[mid]', 't2')); } return t; };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      base = sim.arr('a', 'int', n, a);
      sim.step(at('int a[' + n + ']'), L('The sorted array lives in main\'s frame: ' + n + ' ints, ' + (4 * n) + ' bytes in one piece.', 'อาเรย์ที่เรียงแล้วอยู่ในเฟรมของ main: int ' + n + ' ตัว ' + (4 * n) + ' ไบต์ติดกัน'));
      const xa = sim.local('x', 'int', x);
      sim.step(at('int x ='), L('x = ' + x + ': we want the first index whose value is ≥ ' + x + '.', 'x = ' + x + ': เราต้องการดัชนีแรกที่ค่า ≥ ' + x));
      const posA = sim.local('pos', 'int', undefined);
      sim.r(xa);
      sim.top().line = at('int pos =');
      sim.call('lowerBound(int a[], int n, int x)');
      sim.param('a', 'int*', P(base)); sim.param('n', 'int', n); sim.param('x', 'int', x);
      sim.step(at('int lowerBound'), L('The call copies three things into the new frame. Look at <code>a</code>: it is not an array but an <b>8-byte pointer</b> holding ' + hex(base) + ' (an array argument "decays" to a pointer to its first element). No elements were copied, so the call costs O(1).', 'การเรียกคัดลอกสามอย่างลงเฟรมใหม่ ดูที่ <code>a</code>: มันไม่ใช่อาเรย์ แต่เป็น<b>พอยน์เตอร์ 8 ไบต์</b>ที่เก็บ ' + hex(base) + ' (อาร์กิวเมนต์ที่เป็นอาเรย์จะ "สลาย" เป็นพอยน์เตอร์ไปยังสมาชิกตัวแรก) ไม่มีสมาชิกถูกคัดลอกเลย การเรียกจึงเป็น O(1)'));
      const loA = sim.local('lo', 'int', 0), hiA = sim.local('hi', 'int', n);
      lo = 0; hi = n;
      sim.step(at('int lo = 0'), L('lo = 0, hi = ' + n + '. Every index from 0 to ' + n + ' could be the answer (' + n + ' means "none is big enough").', 'lo = 0, hi = ' + n + ' ทุกดัชนีตั้งแต่ 0 ถึง ' + n + ' อาจเป็นคำตอบ (' + n + ' หมายถึง "ไม่มีตัวไหนใหญ่พอ")'));
      let round = 0;
      while (lo < hi) {
        round++;
        sim.r(loA); sim.r(hiA);
        sim.step(at('while (lo < hi)'), L('Round ' + round + ': lo = ' + lo + ' &lt; hi = ' + hi + ', so ' + (hi - lo) + ' candidate' + (hi - lo > 1 ? 's remain' : ' remains') + '.', 'รอบที่ ' + round + ': lo = ' + lo + ' &lt; hi = ' + hi + ' ยังเหลือผู้สมัคร ' + (hi - lo) + ' ตัว'));
        mid = Math.floor((lo + hi) / 2);
        const midA = sim.local('mid', 'int', mid);
        sim.step(at('int mid ='), L('mid = (' + lo + ' + ' + hi + ') / 2 = <b>' + mid + '</b> (integer division rounds down).', 'mid = (' + lo + ' + ' + hi + ') / 2 = <b>' + mid + '</b> (หารจำนวนเต็มปัดลง)'));
        const v = sim.r(base + 4 * mid);
        if (v < x) {
          lo = mid + 1; sim.w(loA, lo);
          sim.step(at('if (a[mid] < x)'), L('a[' + mid + '] is read through the pointer at address ' + hex(base) + ' + ' + mid + '×4 = ' + hex(base + 4 * mid) + ' (inside main\'s frame): <b>' + v + ' &lt; ' + x + '</b>. So mid and everything left of it are too small: lo = ' + lo + '.', 'อ่าน a[' + mid + '] ผ่านพอยน์เตอร์ที่แอดเดรส ' + hex(base) + ' + ' + mid + '×4 = ' + hex(base + 4 * mid) + ' (ในเฟรมของ main): <b>' + v + ' &lt; ' + x + '</b> ดังนั้น mid และทุกตัวทางซ้ายเล็กเกินไป: lo = ' + lo));
        } else {
          hi = mid; sim.w(hiA, hi);
          sim.step(at('else hi = mid'), L('a[' + mid + '] = ' + v + ' ≥ ' + x + ' (read at ' + hex(base + 4 * mid) + '). mid could be the answer, but maybe something further left is too: hi = ' + hi + '.', 'a[' + mid + '] = ' + v + ' ≥ ' + x + ' (อ่านที่ ' + hex(base + 4 * mid) + ') mid อาจเป็นคำตอบ แต่อาจมีตัวทางซ้ายที่เป็นได้ด้วย: hi = ' + hi), { lines: [at('if (a[mid] < x)')] });
        }
        sim.drop('mid'); mid = null;
      }
      sim.r(loA); sim.r(hiA);
      sim.step(at('while (lo < hi)'), L('lo = hi = ' + lo + ': only one candidate is left, so the loop stops after ' + round + ' round' + (round === 1 ? '' : 's') + ' (log₂ ' + (n + 1) + ' ≈ ' + Math.log2(n + 1).toFixed(1) + ').', 'lo = hi = ' + lo + ': เหลือผู้สมัครตัวเดียว ลูปหยุดหลัง ' + round + ' รอบ (log₂ ' + (n + 1) + ' ≈ ' + Math.log2(n + 1).toFixed(1) + ')'));
      const ans = lo;
      sim.ret(ans, { type: 'int' });
      lo = null; hi = null;
      sim.w(posA, ans);
      sim.step(at('int pos ='), L('lowerBound returns ' + ans + ' and its frame is gone. pos = ' + ans + (ans < n ? ' (a[' + ans + '] = ' + a[ans] + (a[ans] === x ? ', found x' : ', the first value bigger than x') + ').' : ': every value is smaller than x.'), 'lowerBound คืนค่า ' + ans + ' และเฟรมของมันหายไป pos = ' + ans + (ans < n ? ' (a[' + ans + '] = ' + a[ans] + (a[ans] === x ? ' เจอ x' : ' คือค่าแรกที่มากกว่า x') + ')' : ': ทุกค่าน้อยกว่า x')));
      sim.print(sim.r(posA) + '\n');
      sim.step(at('cout << pos'), L('Print ' + ans + '. std::lower_bound(a, a + n, x) does exactly this and returns a pointer instead of an index.', 'พิมพ์ ' + ans + ' std::lower_bound(a, a + n, x) ทำแบบนี้เป๊ะ แต่คืนพอยน์เตอร์แทนดัชนี'));
      sim.ret(0, { show: false });
    }
  });

  // ---------------------------------------------------------------- prefix sums
  const psCode = (a, l, r) => `int main() {
  int a[${a.length}] = {${a.join(', ')}};
  int pre[${a.length + 1}];             // pre[i] = a[0] + ... + a[i-1]
  pre[0] = 0;
  for (int i = 0; i < ${a.length}; i++)
    pre[i + 1] = pre[i] + a[i];
  int l = ${l}, r = ${r};
  cout << pre[r + 1] - pre[l] << "\\n";   // sum of a[l..r]
}
`;
  const psParse = p => {
    const a = parseNums(p.arr, 10);
    if (a.length < 1) throw userErr(L('Give at least one number.', 'ใส่ตัวเลขอย่างน้อยหนึ่งตัว'));
    const q = parseNums(p.q, 2);
    if (q.length < 2 || q[0] < 0 || q[1] >= a.length || q[0] > q[1]) throw userErr(L('The query needs l r with 0 ≤ l ≤ r < ' + a.length + '.', 'คำถามต้องเป็น l r โดย 0 ≤ l ≤ r < ' + a.length));
    return { a, l: q[0], r: q[1] };
  };
  def({
    id: 'prefix-sums', part: 3, lesson: '08', lessonFile: '08-binary-search-prefix-sums.md',
    title: L('Prefix sums: any range sum in O(1)', 'Prefix sum: ผลรวมช่วงใดก็ได้ใน O(1)'),
    summary: L('Build pre[] once in O(n). After that, the sum of a[l..r] is just pre[r+1] − pre[l]: two reads and one subtraction. Notice pre starts full of garbage until each box is written.',
      'สร้าง pre[] ครั้งเดียวใน O(n) หลังจากนั้นผลรวมของ a[l..r] ก็แค่ pre[r+1] − pre[l]: อ่านสองครั้งลบหนึ่งครั้ง สังเกตว่า pre เริ่มต้นเต็มไปด้วยค่าขยะจนกว่าแต่ละช่องจะถูกเขียน'),
    blurb: L('Build pre[] once, then answer range sums with one subtraction.', 'สร้าง pre[] ครั้งเดียว แล้วตอบผลรวมช่วงด้วยการลบครั้งเดียว'),
    params: [{ id: 'arr', label: L('Array', 'อาเรย์'), value: '4 -1 6 2 5 3' }, { id: 'q', label: 'l r', value: '1 4', w: 80 }],
    paramHint: L('up to 10 numbers · query 0 ≤ l ≤ r < n', 'ไม่เกิน 10 ตัว · คำถาม 0 ≤ l ≤ r < n'),
    code: psCode([4, -1, 6, 2, 5, 3], 1, 4),
    codeFn: p => { try { const { a, l, r } = psParse(p); return psCode(a, l, r); } catch (e) { return psCode([1], 0, 0); } },
    build(sim, prm) {
      const { a, l, r } = psParse(prm), n = a.length, code = psCode(a, l, r), at = LN(code);
      let iv = null, q = null;
      sim.viewFn = S => {
        const A = findVar(S, 'a'), PR = findVar(S, 'pre'); if (!A) return null;
        const rows = [{ label: 'a', cells: A.cells.map(fmtPlain), cls: A.cells.map((_, k) => (iv != null && k === iv) || (q && k >= q.l && k <= q.r) ? 'hl' : ''), marks: iv != null ? { [iv]: ['i'] } : {}, ranges: q ? [{ a: q.l, b: q.r, label: 'a[' + q.l + '..' + q.r + ']' }] : [] }];
        if (PR) rows.push({ label: 'pre', cells: PR.cells.map(c => c === undefined ? '?' : fmtPlain(c)), cls: PR.cells.map((c, k) => q ? (k === q.r + 1 ? 'ok' : k === q.l ? 'bad' : '') : (iv != null && k === iv + 1 ? 'chg' : (iv != null && k === iv ? 'cmp' : (c === undefined ? 'dim' : '')))) });
        return { kind: 'array', title: L('a and its prefix sums', 'a และ prefix sum'), cap: L('pre[k] is the sum of the first k elements, so pre has one more box than a.', 'pre[k] คือผลรวมของ k ตัวแรก pre จึงมีมากกว่า a หนึ่งช่อง'), rows };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const A = sim.arr('a', 'int', n, a);
      sim.step(at('int a['), L('The input array.', 'อาเรย์ข้อมูล'));
      const PR = sim.arr('pre', 'int', n + 1, undefined);
      sim.step(at('int pre['), L('<code>int pre[' + (n + 1) + ']</code> without an initializer: ' + (n + 1) + ' boxes of <b>garbage</b> (shown as ?). Reading one before writing it is a bug.', '<code>int pre[' + (n + 1) + ']</code> แบบไม่มีค่าเริ่มต้น: กล่อง ' + (n + 1) + ' กล่องที่เป็น<b>ค่าขยะ</b> (แสดงเป็น ?) การอ่านก่อนเขียนคือบั๊ก'));
      sim.w(PR, 0);
      sim.step(at('pre[0] = 0'), L('pre[0] = 0: the sum of zero elements.', 'pre[0] = 0: ผลรวมของสมาชิกศูนย์ตัว'));
      const ia = sim.local('i', 'int', 0);
      for (let i = 0; i < n; i++) {
        iv = i; sim.w(ia, i);
        const pv = sim.r(PR + 4 * i), av = sim.r(A + 4 * i);
        sim.w(PR + 4 * (i + 1), pv + av);
        sim.step(at('pre[i + 1] = pre[i] + a[i]'), L('i = ' + i + ': pre[' + (i + 1) + '] = pre[' + i + '] + a[' + i + '] = ' + pv + ' + ' + av + ' = <b>' + (pv + av) + '</b>. Each box reuses the one before it, so the whole build is O(n).', 'i = ' + i + ': pre[' + (i + 1) + '] = pre[' + i + '] + a[' + i + '] = ' + pv + ' + ' + av + ' = <b>' + (pv + av) + '</b> แต่ละช่องใช้ช่องก่อนหน้าซ้ำ การสร้างทั้งหมดจึงเป็น O(n)'), { lines: [at('for (int i')] });
      }
      iv = null; sim.drop('i');
      sim.local('l', 'int', l); sim.local('r', 'int', r);
      q = { l, r };
      sim.step(at('int l ='), L('Query: the sum of a[' + l + '..' + r + '].', 'คำถาม: ผลรวมของ a[' + l + '..' + r + ']'));
      const big = sim.r(PR + 4 * (r + 1)), small = sim.r(PR + 4 * l);
      sim.print((big - small) + '\n');
      sim.step(at('cout << pre[r + 1]'), L('pre[' + (r + 1) + '] = ' + big + ' is the sum of a[0..' + r + ']; pre[' + l + '] = ' + small + ' is the sum of a[0..' + (l - 1) + ']. Subtract and the common front part cancels: ' + big + ' − ' + small + ' = <b>' + (big - small) + '</b>. Two reads, whatever the range length.', 'pre[' + (r + 1) + '] = ' + big + ' คือผลรวม a[0..' + r + '] ส่วน pre[' + l + '] = ' + small + ' คือผลรวม a[0..' + (l - 1) + '] ลบกันแล้วส่วนหน้าที่ซ้ำกันหักล้างไป: ' + big + ' − ' + small + ' = <b>' + (big - small) + '</b> อ่านแค่สองครั้งไม่ว่าช่วงจะยาวแค่ไหน'));
      sim.ret(0, { show: false });
    }
  });
})();
