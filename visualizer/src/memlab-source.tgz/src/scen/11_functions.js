/* Part I · functions: parameters, lifetime, recursion */

// ------------------------------------------------------------------ parameters
(() => {
  const code = `void swapVal(int a, int b) {
    int t = a;
    a = b;
    b = t;
}
void swapRef(int& a, int& b) {
    int t = a;
    a = b;
    b = t;
}
void swapPtr(int* a, int* b) {
    int t = *a;
    *a = *b;
    *b = t;
}
int main() {
    int x = 1, y = 2;
    swapVal(x, y);     // gets copies
    swapRef(x, y);     // gets aliases
    swapPtr(&x, &y);   // gets addresses
    cout << x << " " << y << "\\n";
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'parameters', part: 1, lesson: '01', lessonFile: '01-cpp-and-complexity.md',
    title: L('Function calls: by value, by reference, by pointer', 'การเรียกฟังก์ชัน: ส่งค่า ส่ง reference ส่งพอยน์เตอร์'),
    summary: L('Each call pushes a new frame on the stack holding the parameters and locals. The three swaps look almost the same, but only two of them can reach main\'s variables. Watch which boxes the callee can actually touch.',
      'ทุกครั้งที่เรียกฟังก์ชัน จะมีเฟรมใหม่ถูก push บน stack เพื่อเก็บพารามิเตอร์และตัวแปรภายใน swap ทั้งสามแบบหน้าตาเกือบเหมือนกัน แต่มีแค่สองแบบที่เข้าถึงตัวแปรของ main ได้ ดูว่าฟังก์ชันที่ถูกเรียกแตะกล่องไหนได้จริง'),
    blurb: L('Stack frames, copies vs aliases vs addresses.', 'stack frame, สำเนา vs ชื่อแฝง vs แอดเดรส'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const x = sim.local('x', 'int', 1), y = sim.local('y', 'int', 2);
      sim.step(at('int x = 1'), L('x = 1 and y = 2 live in <b class="s">main\'s frame</b>.', 'x = 1 และ y = 2 อยู่ใน<b class="s">เฟรมของ main</b>'));

      // swapVal
      sim.step(at('swapVal(x, y)'), L('Call <code>swapVal(x, y)</code>. The arguments are evaluated first: read x and y.', 'เรียก <code>swapVal(x, y)</code> อาร์กิวเมนต์ถูกประเมินก่อน: อ่าน x และ y'));
      sim.r(x); sim.r(y);
      sim.call('swapVal(int a, int b)');
      let a = sim.param('a', 'int', 1), b = sim.param('b', 'int', 2);
      sim.step(at('void swapVal'), L(
        'A <b class="s">new frame</b> is pushed <i>below</i> main\'s (lower addresses). Parameters <code>a</code> and <code>b</code> are <b>new boxes</b> initialised with <b>copies</b> of 1 and 2. (Small arguments really travel in CPU registers; without optimisation the compiler then stores them in the frame like this.)',
        '<b class="s">เฟรมใหม่</b>ถูก push ไว้<i>ใต้</i>เฟรมของ main (แอดเดรสต่ำกว่า) พารามิเตอร์ <code>a</code> และ <code>b</code> เป็น<b>กล่องใหม่</b> ที่ได้<b>สำเนา</b>ของ 1 และ 2 (อาร์กิวเมนต์เล็ก ๆ จริง ๆ เดินทางผ่าน register ของ CPU ถ้าไม่เปิด optimisation คอมไพเลอร์จะเก็บมันลงเฟรมแบบนี้)'));
      let t = sim.local('t', 'int', sim.r(a));
      sim.step(at('int t = a', 1), L('t = a = 1.', 't = a = 1'));
      sim.w(a, sim.r(b));
      sim.step(at('a = b', 1), L('a = b: the copy <code>a</code> becomes 2.', 'a = b: สำเนา <code>a</code> กลายเป็น 2'));
      sim.w(b, sim.r(t));
      sim.step(at('b = t', 1), L('b = t: the copies are swapped… but look at main\'s x and y: still 1 and 2.', 'b = t: สำเนาถูกสลับแล้ว… แต่ดู x และ y ของ main สิ ยังเป็น 1 และ 2'));
      sim.step(at('}', 1), L('The closing brace: the function is done.', 'ปีกกาปิด: ฟังก์ชันทำงานเสร็จ'));
      sim.ret(undefined, { show: false });
      sim.step(at('swapVal(x, y)'), L(
        'The frame is <b>popped</b> (shown faded). a, b and t are gone, and the swap went with them. <b>Pass by value</b> gives the function its own copies, so it can never change the caller\'s variables.',
        'เฟรมถูก <b>pop</b> (แสดงแบบจาง) a, b และ t หายไป การสลับก็หายไปด้วย <b>การส่งค่า (pass by value)</b> ให้ฟังก์ชันได้สำเนาของตัวเอง จึงเปลี่ยนตัวแปรของผู้เรียกไม่ได้เลย'));

      // swapRef
      sim.step(at('swapRef(x, y)'), L('Call <code>swapRef(x, y)</code>.', 'เรียก <code>swapRef(x, y)</code>'));
      sim.call('swapRef(int& a, int& b)');
      a = sim.ref('a', 'int', x, { param: true }); b = sim.ref('b', 'int', y, { param: true });
      sim.step(at('void swapRef'), L(
        'Now the parameters are <b>references</b>. Notice the frame gets the <i>same addresses</i> the last call used: the stack is reused. <code>a</code> is another name for main\'s x, and <code>b</code> for y. Behind the scenes the compiler passes their addresses (dashed boxes).',
        'ตอนนี้พารามิเตอร์เป็น <b>reference</b> สังเกตว่าเฟรมได้<i>แอดเดรสเดิม</i>กับการเรียกครั้งก่อน เพราะ stack ถูกใช้ซ้ำ <code>a</code> เป็นอีกชื่อของ x ใน main และ <code>b</code> คือ y เบื้องหลังคอมไพเลอร์ส่งแอดเดรสของมันมา (กล่องเส้นประ)'));
      t = sim.local('t', 'int', sim.r(x));
      sim.step(at('int t = a', 2), L('t = a, which reads <b>main\'s x</b> (1).', 't = a ซึ่งอ่าน <b>x ของ main</b> (1)'));
      sim.w(x, sim.r(y));
      sim.step(at('a = b', 2), L('a = b writes <b>main\'s x</b>: x = 2.', 'a = b เขียนลง <b>x ของ main</b>: x = 2'));
      sim.w(y, sim.r(t));
      sim.step(at('b = t', 2), L('b = t writes main\'s y: y = 1. The swap happened in main\'s boxes.', 'b = t เขียนลง y ของ main: y = 1 การสลับเกิดขึ้นในกล่องของ main จริง ๆ'));
      sim.ret(undefined, { show: false });
      sim.step(at('swapRef(x, y)'), L('Frame popped, but this time the change stays: x = 2, y = 1. <b>Pass by reference</b> lets a function modify the caller\'s variables, with no copying.', 'เฟรมถูก pop แต่คราวนี้การเปลี่ยนแปลงยังอยู่: x = 2, y = 1 <b>การส่ง reference</b> ทำให้ฟังก์ชันแก้ตัวแปรของผู้เรียกได้ โดยไม่ต้องคัดลอก'));

      // swapPtr
      sim.step(at('swapPtr(&x, &y)'), L('Call <code>swapPtr(&x, &y)</code>: the arguments are the <b>addresses</b> ' + hex(x) + ' and ' + hex(y) + '.', 'เรียก <code>swapPtr(&x, &y)</code>: อาร์กิวเมนต์คือ<b>แอดเดรส</b> ' + hex(x) + ' และ ' + hex(y)));
      sim.call('swapPtr(int* a, int* b)');
      a = sim.param('a', 'int*', P(x)); b = sim.param('b', 'int*', P(y));
      sim.step(at('void swapPtr'), L(
        'The parameters are ordinary pointer boxes holding <b>copies of the addresses</b>. The pointer itself is passed by value, but a copy of an address still leads to the same house.',
        'พารามิเตอร์เป็นกล่องพอยน์เตอร์ธรรมดาที่เก็บ<b>สำเนาของแอดเดรส</b> ตัวพอยน์เตอร์ถูกส่งแบบค่า แต่สำเนาของแอดเดรสก็ยังพาไปบ้านหลังเดิม'));
      sim.r(a); t = sim.local('t', 'int', sim.r(x));
      sim.step(at('int t = *a'), L('<code>*a</code>: follow the arrow to x and read 2.', '<code>*a</code>: ตามลูกศรไปที่ x แล้วอ่านได้ 2'));
      sim.r(a); sim.r(b); sim.w(x, sim.r(y));
      sim.step(at('*a = *b'), L('<code>*a = *b</code>: x = y = 1.', '<code>*a = *b</code>: x = y = 1'));
      sim.r(b); sim.w(y, sim.r(t));
      sim.step(at('*b = t'), L('<code>*b = t</code>: y = 2.', '<code>*b = t</code>: y = 2'));
      sim.ret(undefined, { show: false });
      sim.step(at('swapPtr(&x, &y)'), L('Popped. x = 1 and y = 2 again: the pointer version also changed main\'s boxes. References are the C++ way; pointers are the C way, and they can also be <code>nullptr</code> or be moved.', 'pop แล้ว x = 1 และ y = 2 อีกครั้ง แบบพอยน์เตอร์ก็แก้กล่องของ main ได้เหมือนกัน reference เป็นวิธีของ C++ ส่วนพอยน์เตอร์เป็นวิธีของ C และพอยน์เตอร์ยังเป็น <code>nullptr</code> หรือย้ายไปชี้ที่อื่นได้'));
      sim.r(x); sim.r(y); sim.print('1 2\n');
      sim.step(at('cout'), L('Output: <code>1 2</code>.', 'ผลลัพธ์: <code>1 2</code>'));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();

// ------------------------------------------------------------------ lifetime
(() => {
  const code = `int square(int n) {
    int r = n * n;
    return r;              // the VALUE is copied out
}
int* bad() {
    int local = 42;
    return &local;         // BUG: local dies on return
}
int* good() {
    int* h = new int(42);  // lives on the heap
    return h;              // the address stays valid
}
int main() {
    int s = square(7);
    int* p = bad();        // p is dangling
    int* q = good();       // q points into the heap
    cout << s << " " << *q << "\\n";
    delete q;              // give the heap memory back
    q = nullptr;
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'lifetime', dangOK: true, part: 1, lesson: '01', lessonFile: '01-cpp-and-complexity.md',
    title: L('Return values and lifetime', 'ค่าที่คืนและอายุของตัวแปร'),
    summary: L('A function\'s locals die when it returns. Returning a value copies it out safely; returning the address of a local leaves a dangling pointer; returning a heap address is fine because heap memory lives until delete.',
      'ตัวแปรภายในของฟังก์ชันตายเมื่อมัน return การคืนค่าจะคัดลอกค่าออกมาอย่างปลอดภัย การคืนแอดเดรสของตัวแปรภายในทำให้เกิดพอยน์เตอร์ห้อย ส่วนการคืนแอดเดรสบน heap ไม่มีปัญหา เพราะ heap อยู่จนกว่าจะ delete'),
    blurb: L('Why returning &local is a bug and new is not.', 'ทำไมการคืน &local เป็นบั๊ก แต่ new ไม่ใช่'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      sim.step(at('int s = square(7)'), L('To initialise s, main must first call <code>square(7)</code>.', 'ก่อนจะกำหนดค่า s ได้ main ต้องเรียก <code>square(7)</code> ก่อน'));
      sim.call('square(int n)');
      const n = sim.param('n', 'int', 7);
      sim.step(at('int square'), L('square\'s frame: <code>n</code> = 7 (a copy).', 'เฟรมของ square: <code>n</code> = 7 (สำเนา)'));
      const nv = sim.r(n); sim.local('r', 'int', nv * nv);
      sim.step(at('int r = n * n'), L('r = 49.', 'r = 49'));
      sim.step(at('return r'), L('<code>return r;</code> copies the <b>value</b> 49 into a CPU register (the return slot). Nothing points back into this frame.', '<code>return r;</code> คัดลอก<b>ค่า</b> 49 ไปไว้ใน register ของ CPU (ช่องคืนค่า) ไม่มีอะไรชี้กลับเข้ามาในเฟรมนี้'));
      sim.ret(49);
      const s = sim.local('s', 'int', 49);
      sim.step(at('int s = square(7)'), L('square\'s frame is popped, and its 49 lands in main\'s new box <code>s</code>. Returning a value is always safe.', 'เฟรมของ square ถูก pop และค่า 49 ไปอยู่ในกล่องใหม่ <code>s</code> ของ main การคืนค่าแบบนี้ปลอดภัยเสมอ'));

      sim.step(at('int* p = bad()'), L('Call <code>bad()</code>.', 'เรียก <code>bad()</code>'));
      sim.call('bad()');
      const loc = sim.local('local', 'int', 42);
      sim.step(at('int local = 42'), L('bad\'s frame reuses the stack space square just gave back. <code>local</code> = 42 at ' + hex(loc) + '.', 'เฟรมของ bad ใช้พื้นที่ stack ที่ square เพิ่งคืน <code>local</code> = 42 อยู่ที่ ' + hex(loc)));
      sim.step(at('return &local'), L('<code>return &local;</code> returns the address ' + hex(loc) + '. The compiler warns: "address of local variable returned".', '<code>return &local;</code> คืนแอดเดรส ' + hex(loc) + ' คอมไพเลอร์เตือนว่า "address of local variable returned"'), { cls: 'warn' });
      sim.ret(P(loc), { type: 'int*' });
      sim.local('p', 'int*', P(loc));
      sim.step(at('int* p = bad()'), L(
        'bad\'s frame is gone, but <code>p</code> still holds ' + hex(loc) + ': a <b>dangling pointer</b> (red). The 42 may still be sitting there for now, but the next call will reuse those bytes. (GCC actually makes such a function return nullptr to make the bug visible.)',
        'เฟรมของ bad หายไปแล้ว แต่ <code>p</code> ยังเก็บ ' + hex(loc) + ' อยู่ นี่คือ<b>พอยน์เตอร์ห้อย</b> (สีแดง) ค่า 42 อาจยังค้างอยู่ตรงนั้นชั่วคราว แต่การเรียกฟังก์ชันครั้งถัดไปจะใช้ไบต์เหล่านั้นซ้ำ (GCC ถึงขั้นทำให้ฟังก์ชันแบบนี้คืน nullptr เพื่อให้เห็นบั๊กชัด ๆ)'), { cls: 'warn' });

      sim.step(at('int* q = good()'), L('Call <code>good()</code>.', 'เรียก <code>good()</code>'));
      sim.call('good()');
      const hb = sim.newObj('int', [['value', 'int', 42]], { label: 'new int(42)', expr: 'new int(42)' });
      const h = sim.local('h', 'int*', P(hb));
      sim.step(at('int* h = new int(42)'), L(
        '<code>new int(42)</code> asks the allocator for 4 bytes on the <b class="h">heap</b>, writes 42 there, and returns the address ' + hex(hb) + '. good\'s frame (it lands exactly where bad\'s was) only stores that address in <code>h</code>.',
        '<code>new int(42)</code> ขอพื้นที่ 4 ไบต์บน <b class="h">heap</b> จากตัวจัดสรร เขียน 42 ลงไป แล้วคืนแอดเดรส ' + hex(hb) + ' เฟรมของ good (ซึ่งอยู่ตรงที่เฟรมของ bad เคยอยู่พอดี) แค่เก็บแอดเดรสนั้นไว้ใน <code>h</code>'));
      sim.r(h);
      sim.step(at('return h'), L('Return the address (a copy of h\'s value).', 'คืนแอดเดรส (สำเนาของค่าใน h)'));
      sim.ret(P(hb), { type: 'int*' });
      const q = sim.local('q', 'int*', P(hb));
      sim.step(at('int* q = good()'), L(
        'good\'s frame is popped, but the heap block is <b>not</b> touched: heap memory lives until someone calls <code>delete</code>. So <code>q</code> is a valid pointer.',
        'เฟรมของ good ถูก pop แต่บล็อกบน heap <b>ไม่</b>ถูกแตะเลย หน่วยความจำ heap อยู่จนกว่าจะมีคน <code>delete</code> ดังนั้น <code>q</code> เป็นพอยน์เตอร์ที่ใช้ได้'));
      sim.r(s); sim.r(q); sim.r(hb); sim.print('49 42\n');
      sim.step(at('cout'), L('Print s and *q.', 'พิมพ์ s และ *q'));
      sim.r(q); sim.free(hb);
      sim.step(at('delete q'), L('<code>delete q;</code> returns the 4 bytes to the allocator. q still holds the old address, so now <i>q</i> is dangling too…', '<code>delete q;</code> คืน 4 ไบต์ให้ตัวจัดสรร q ยังเก็บแอดเดรสเดิม ตอนนี้ <i>q</i> ก็เป็นพอยน์เตอร์ห้อยเหมือนกัน…'));
      sim.w(q, P(0));
      sim.step(at('q = nullptr'), L('…which is why we set it to <code>nullptr</code> right away. p is still dangling: never dereference it.', '…จึงต้องตั้งเป็น <code>nullptr</code> ทันที ส่วน p ยังห้อยอยู่ ห้ามใช้ *p เด็ดขาด'));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();

// ------------------------------------------------------------------ recursion
(() => {
  const code = `long long fact(int n) {
    if (n <= 1) return 1;
    long long sub = fact(n - 1);
    return n * sub;
}
int main() {
    long long f = fact(N);
    cout << f << "\\n";
    return 0;
}`;
  def({
    id: 'recursion', part: 1, lesson: '11', lessonFile: '11-recursion-backtracking.md',
    title: L('Recursion is just a stack of frames', 'การเรียกซ้ำคือ frame ที่ซ้อนกันบน stack'),
    summary: L('Every recursive call gets its own frame with its own n. The calls pile up until the base case, then the answers flow back down the stack one frame at a time.',
      'การเรียกซ้ำแต่ละครั้งได้เฟรมของตัวเองพร้อม n ของตัวเอง การเรียกจะซ้อนขึ้นไปจนถึง base case จากนั้นคำตอบจะไหลกลับลงมาทีละเฟรม'),
    blurb: L('fact(n): frames pile up, then unwind with return values.', 'fact(n): เฟรมซ้อนขึ้น แล้วคลายกลับพร้อมค่าที่คืน'),
    params: [{ id: 'n', label: L('N (1–8)', 'N (1–8)'), value: '4' }],
    code,
    codeFn: p => code.replace('fact(N)', 'fact(' + (parseInt(p.n, 10) || 'N') + ')'),
    build(sim, prm) {
      let N = parseInt(prm.n, 10);
      if (!(N >= 1 && N <= 8)) throw userErr(L('N must be between 1 and 8.', 'N ต้องอยู่ระหว่าง 1 ถึง 8'));
      const at0 = LN(code);
      const at = k => at0(k === 'fact(N)' ? 'long long f = fact' : k);
      const tree = {}; let order = 0;
      sim.viewFn = () => ({ kind: 'tree', title: L('call tree', 'ต้นไม้การเรียก'), cap: L('Each node is one call. Green = returned, teal = running now.', 'แต่ละโหนดคือการเรียกหนึ่งครั้ง เขียว = คืนค่าแล้ว ฟ้าอมเขียว = กำลังทำงาน'), nodes: tree, root: tree.c0 ? 'c0' : null, square: true, gy: 56 });
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      sim.step(at('fact(N)'), L('main calls <code>fact(' + N + ')</code> and waits on this line.', 'main เรียก <code>fact(' + N + ')</code> แล้วรออยู่ที่บรรทัดนี้'));
      const rec = (n, parent) => {
        const id = 'c' + (order++);
        tree[id] = { label: 'fact(' + n + ')', kids: [], cls: 'hl' };
        if (parent) { tree[parent].kids.push(id); tree[parent].cls = 'cmp'; }
        sim.call('fact(int n = ' + n + ')');
        const na = sim.param('n', 'int', n);
        sim.step(at('long long fact'), L(
          'A new frame for <code>fact(' + n + ')</code>. Its <code>n</code> (' + n + ') is a separate box from every other frame\'s n. Depth now: ' + (sim.frames.length - 1) + ' call(s).',
          'เฟรมใหม่ของ <code>fact(' + n + ')</code> ตัว <code>n</code> (' + n + ') เป็นกล่องแยกจาก n ของเฟรมอื่นทั้งหมด ความลึกตอนนี้: ' + (sim.frames.length - 1) + ' ชั้น'));
        sim.r(na);
        if (n <= 1) {
          sim.step(at('if (n <= 1)'), L('<b>Base case</b>: n = ' + n + ' ≤ 1, so return 1 without calling again. This is what stops the recursion.', '<b>Base case</b>: n = ' + n + ' ≤ 1 จึงคืน 1 โดยไม่เรียกต่อ นี่คือสิ่งที่หยุดการเรียกซ้ำ'));
          tree[id].cls = 'ok'; tree[id].label = 'fact(' + n + ')=1';
          if (parent) tree[parent].cls = 'hl';
          sim.ret(1, { type: 'long long' });
          return 1;
        }
        sim.step(at('if (n <= 1)'), L('n = ' + n + ' is not ≤ 1, so keep going.', 'n = ' + n + ' ยังไม่ ≤ 1 จึงทำต่อ'));
        sim.step(at('long long sub = fact'), L('Call <code>fact(' + (n - 1) + ')</code>. This frame <b>pauses</b> here (the line is marked "waiting") until the answer comes back.', 'เรียก <code>fact(' + (n - 1) + ')</code> เฟรมนี้<b>หยุดรอ</b>อยู่ตรงนี้ (บรรทัดถูกทำเครื่องหมายว่ารอ) จนกว่าคำตอบจะกลับมา'));
        const sv = rec(n - 1, id);
        const sub = sim.local('sub', 'long long', sv);
        sim.step(at('long long sub = fact'), L('fact(' + (n - 1) + ') returned ' + sv + '. Its frame is gone; we are back in <code>fact(' + n + ')</code>, whose n is still ' + n + '. Store ' + sv + ' in <code>sub</code>.', 'fact(' + (n - 1) + ') คืนค่า ' + sv + ' เฟรมของมันหายไปแล้ว เรากลับมาที่ <code>fact(' + n + ')</code> ซึ่ง n ยังเป็น ' + n + ' เก็บ ' + sv + ' ไว้ใน <code>sub</code>'));
        sim.r(na); sim.r(sub);
        const res = n * sv;
        sim.step(at('return n * sub'), L('Return ' + n + ' × ' + sv + ' = <b>' + res + '</b>.', 'คืน ' + n + ' × ' + sv + ' = <b>' + res + '</b>'));
        tree[id].cls = 'ok'; tree[id].label = 'fact(' + n + ')=' + res;
        if (parent) tree[parent].cls = 'hl';
        sim.ret(res, { type: 'long long' });
        return res;
      };
      const f = rec(N, null);
      sim.local('f', 'long long', f);
      sim.step(at('fact(N)'), L('Back in main with the final answer ' + f + '. The stack is as small as it was before the first call.', 'กลับมาที่ main พร้อมคำตอบสุดท้าย ' + f + ' stack กลับมาเล็กเท่าก่อนการเรียกครั้งแรก'));
      sim.r(findVar(sim, 'f').addr); sim.print(f + '\n');
      sim.step(at('cout'), L(
        'Printed ' + f + '. The maximum depth was ' + N + ' frames. With n = 10⁶ the stack would overflow (a Runtime Error in the grader): that is why deep recursion sometimes needs a loop instead (course lesson 07 §4.2).',
        'พิมพ์ ' + f + ' ความลึกสูงสุดคือ ' + N + ' เฟรม ถ้า n = 10⁶ stack จะล้น (grader รายงาน Runtime Error) นี่คือเหตุผลที่การเรียกซ้ำลึก ๆ บางครั้งต้องเปลี่ยนเป็นลูป (บทเรียน 07 §4.2)'));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();
