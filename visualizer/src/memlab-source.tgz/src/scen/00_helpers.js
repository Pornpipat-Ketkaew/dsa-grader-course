/* helpers shared by scenarios */

// line finder: LN(code)('int a = 5') → line number of the first line containing that text.
// LN(code)('text', 2) → the 2nd such line.
function LN(code) {
  const lines = code.split('\n');
  return (sub, nth = 1) => {
    let seen = 0;
    for (let i = 0; i < lines.length; i++) if (lines[i].includes(sub) && ++seen === nth) return i + 1;
    throw new Error('LN: line not found: ' + sub);
  };
}

// little-endian bytes of a value, as 2-digit hex strings
function bytesOf(v, type) {
  const n = sizeOf(type);
  if (v === undefined) return Array(n).fill('??');
  const buf = new DataView(new ArrayBuffer(8));
  if (/double/.test(type)) buf.setFloat64(0, v, true);
  else if (type === 'bool') buf.setUint8(0, v ? 1 : 0);
  else if (type === 'char') buf.setUint8(0, isCH(v) ? v.ch.charCodeAt(0) : v);
  else if (isP(v)) buf.setBigUint64(0, BigInt(v.p), true);
  else buf.setBigInt64(0, BigInt(v), true);
  return Array.from({ length: n }, (_, i) => buf.getUint8(i).toString(16).toUpperCase().padStart(2, '0'));
}

// find a scalar variable by name in the top frame (or any frame)
function findVar(sim, name) {
  for (let k = sim.frames.length - 1; k >= 0; k--) { const v = sim.frames[k].vars.find(v => v.name === name); if (v) return v; }
  return null;
}

// tags helper: [{addr,label,cls}]
const TAG = (addr, label, cls) => ({ addr, label, cls });

// a concept view for a CP-style array: cells with used/unused shading and marks
function arrRow(cells, opts = {}) {
  return Object.assign({ cells: cells.map(c => c === undefined ? '?' : fmtPlain(c)) }, opts);
}

// read all cells of a heap array block as plain values (no read marks)
function cellsOf(sim, base) { const b = sim.block(base); return b ? b.cells.slice() : []; }
