/* Part I · basics: variables, arrays, pointers, pointer arithmetic, references */

// ------------------------------------------------------------------ variables
(() => {
  const code = `#include <iostream>
using namespace std;

int main() {
    int a = 5;
    double d = 3.5;
    char c = 'A';
    bool ok;
    int b;
    b = a * 2;
    a = 300;
    ok = (b > a);
    cout << a << " " << b << " " << c << "\\n";
    cout << sizeof(a) << " " << sizeof(d) << "\\n";
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'variables', part: 1, lesson: '01', lessonFile: '01-cpp-and-complexity.md',
    title: L('Variables are boxes with addresses', 'ตัวแปรคือกล่องที่มีแอดเดรส'),
    summary: L('What really happens when you write int a = 5: a few bytes on the stack get a name, a type and a value. Watch the bytes themselves change, including the little-endian order.',
      'เกิดอะไรขึ้นจริง ๆ เมื่อเขียน int a = 5: ไบต์จำนวนหนึ่งบน stack ได้ชื่อ ชนิด และค่า ดูไบต์เปลี่ยนไปทีละตัว รวมถึงการเรียงไบต์แบบ little-endian'),
    blurb: L('Bytes, sizes, garbage values, and how an int sits in memory.', 'ไบต์ ขนาด ค่าขยะ และ int วางอยู่ในหน่วยความจำอย่างไร'),
    code,
    build(sim) {
      const names = [];
      sim.viewFn = s => ({
        kind: 'bytes', title: L('the raw bytes', 'ไบต์ดิบ'),
        cap: L('Each variable is a run of bytes. x86 stores the lowest byte first (little-endian), so 300 = 0x012C is stored as 2C 01 00 00.', 'ตัวแปรแต่ละตัวคือไบต์ที่เรียงติดกัน เครื่อง x86 เก็บไบต์ต่ำสุดไว้ก่อน (little-endian) ดังนั้น 300 = 0x012C จึงถูกเก็บเป็น 2C 01 00 00'),
        vars: names.map(n => { const v = findVar(s, n); return { name: n, type: v.type, addr: v.addr, show: fmtPlain(v.value, v.type), bytes: bytesOf(v.value, v.type) }; })
      });
      sim.call('main()');
      sim.step(at('int main'), L(
        'The program starts. The operating system calls <code>main</code>, and a <b class="s">stack frame</b> for it appears: a slice of the stack reserved for main\'s local variables. (Real compilers reserve the whole frame at once; the lab shows each variable when its line runs.)',
        'โปรแกรมเริ่มทำงาน ระบบปฏิบัติการเรียก <code>main</code> แล้ว <b class="s">stack frame</b> ของมันก็ปรากฏ คือพื้นที่ส่วนหนึ่งของ stack ที่จองไว้ให้ตัวแปรภายในของ main (คอมไพเลอร์จริงจองทั้งเฟรมในครั้งเดียว แต่แล็บจะแสดงตัวแปรเมื่อบรรทัดของมันทำงาน)'));
      const a = sim.local('a', 'int', 5); names.push('a');
      sim.step(at('int a = 5'), L(
        '<code>int a = 5;</code> takes <b>4 bytes</b> of the stack. Their first byte is at address <code>' + hex(a) + '</code>, so <code>a</code> covers ' + hex(a) + '–' + hex(a + 3) + '. The name <code>a</code> exists only for you and the compiler; the machine just sees "the 4 bytes at ' + hex(a) + '".',
        '<code>int a = 5;</code> ใช้พื้นที่ <b>4 ไบต์</b> บน stack ไบต์แรกอยู่ที่แอดเดรส <code>' + hex(a) + '</code> ดังนั้น <code>a</code> ครอบคลุม ' + hex(a) + '–' + hex(a + 3) + ' ชื่อ <code>a</code> มีไว้ให้คุณกับคอมไพเลอร์เท่านั้น เครื่องเห็นแค่ "4 ไบต์ที่ ' + hex(a) + '"'));
      const d = sim.local('d', 'double', 3.5); names.push('d');
      sim.step(at('double d'), L(
        'A <code>double</code> needs <b>8 bytes</b>. The stack grows <b>downward</b>, so <code>d</code> gets a <i>lower</i> address than <code>a</code>: ' + hex(d) + '. Its bytes encode 3.5 in IEEE-754 floating point, which looks nothing like the number 3.',
        '<code>double</code> ใช้ <b>8 ไบต์</b> stack โต<b>ลงล่าง</b> ดังนั้น <code>d</code> ได้แอดเดรสที่<i>ต่ำกว่า</i> <code>a</code> คือ ' + hex(d) + ' ไบต์ของมันเข้ารหัส 3.5 แบบทศนิยม IEEE-754 ซึ่งหน้าตาไม่เหมือนเลข 3 เลย'));
      const c = sim.local('c', 'char', CH('A')); names.push('c');
      sim.step(at("char c"), L(
        'A <code>char</code> is <b>1 byte</b>. The letter A is stored as the number 65 (hex 41). Characters are just small integers.',
        '<code>char</code> ใช้ <b>1 ไบต์</b> ตัวอักษร A ถูกเก็บเป็นเลข 65 (ฐานสิบหก 41) ตัวอักษรก็คือจำนวนเต็มเล็ก ๆ นั่นเอง'));
      sim.local('ok', 'bool', undefined); names.push('ok');
      sim.step(at('bool ok'), L(
        '<code>bool ok;</code> has <b>no initial value</b>. The box shows <b>?</b>: in real C++ it contains whatever bits were left there by earlier code. Reading it before assigning is undefined behaviour.',
        '<code>bool ok;</code> <b>ไม่มีค่าเริ่มต้น</b> กล่องจึงแสดง <b>?</b> ใน C++ จริงมันคือบิตที่โค้ดก่อนหน้าทิ้งไว้ การอ่านค่ามันก่อนกำหนดค่าเป็น undefined behaviour'));
      const b = sim.local('b', 'int', undefined); names.push('b');
      sim.step(at('int b;'), L(
        '<code>int b;</code> is also garbage for now. Note the gap in addresses: the compiler may leave padding so each variable starts at an address divisible by its size (alignment).',
        '<code>int b;</code> ตอนนี้ก็ยังเป็นค่าขยะ สังเกตว่าแอดเดรสอาจเว้นช่องว่าง เพราะคอมไพเลอร์จัดให้ตัวแปรเริ่มที่แอดเดรสที่หารด้วยขนาดของมันลงตัว (alignment)'));
      const av = sim.r(a);
      sim.w(b, av * 2);
      sim.step(at('b = a * 2'), L(
        '<code>b = a * 2;</code> The CPU <b>reads</b> the 4 bytes at ' + hex(a) + ' (violet outline), multiplies by 2 in a register, then <b>writes</b> 10 into the 4 bytes at ' + hex(b) + ' (yellow flash). Every assignment is "read some boxes, compute, write a box".',
        '<code>b = a * 2;</code> CPU <b>อ่าน</b> 4 ไบต์ที่ ' + hex(a) + ' (ขอบม่วง) คูณ 2 ใน register แล้ว<b>เขียน</b> 10 ลง 4 ไบต์ที่ ' + hex(b) + ' (กะพริบเหลือง) การกำหนดค่าทุกครั้งคือ "อ่านกล่อง คำนวณ เขียนกล่อง"'));
      sim.w(a, 300);
      sim.step(at('a = 300'), L(
        '<code>a = 300;</code> overwrites the old 5. 300 = 0x0000012C, and the lowest byte (2C) goes at the lowest address. Look at the bytes view: <code>2C 01 00 00</code>.',
        '<code>a = 300;</code> เขียนทับค่า 5 เดิม 300 = 0x0000012C และไบต์ต่ำสุด (2C) ไปอยู่ที่แอดเดรสต่ำสุด ดูในภาพไบต์: <code>2C 01 00 00</code>'));
      const okv = sim.r(b) > sim.r(a);
      sim.w(findVar(sim, 'ok').addr, okv);
      sim.step(at('ok = (b > a)'), L(
        '<code>ok = (b > a);</code> compares 10 > 300, which is false. A bool is one byte holding 0 (false) or 1 (true).',
        '<code>ok = (b > a);</code> เปรียบเทียบ 10 > 300 ได้ false ค่า bool คือ 1 ไบต์ที่เก็บ 0 (false) หรือ 1 (true)'));
      sim.r(a); sim.r(b); sim.r(c);
      sim.print('300 10 A\n');
      sim.step(at('cout << a'), L(
        '<code>cout</code> reads the three boxes and prints them as text.',
        '<code>cout</code> อ่านสามกล่องนี้แล้วพิมพ์ออกมาเป็นข้อความ'));
      sim.print('4 8\n');
      sim.step(at('sizeof'), L(
        '<code>sizeof</code> is answered by the <b>compiler</b>, not at run time: it is simply the number of bytes the type uses (4 for int, 8 for double). It reads no memory.',
        '<code>sizeof</code> ถูกคำนวณโดย<b>คอมไพเลอร์</b> ไม่ใช่ตอนรันโปรแกรม มันคือจำนวนไบต์ที่ชนิดนั้นใช้ (int = 4, double = 8) จึงไม่ได้อ่านหน่วยความจำเลย'));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L(
        '<code>return 0;</code> main\'s frame is popped. The bytes are still physically there, but they no longer belong to any variable, and the next function call will reuse them.',
        '<code>return 0;</code> เฟรมของ main ถูก pop ไบต์ยังอยู่ในหน่วยความจำจริง แต่ไม่เป็นของตัวแปรใดแล้ว และการเรียกฟังก์ชันครั้งต่อไปจะใช้พื้นที่นี้ซ้ำ'));
    }
  });
})();

// ------------------------------------------------------------------ arrays
(() => {
  const code = `int main() {
    int guard = 7;
    int arr[5] = {10, 20, 30};
    arr[3] = arr[0] + arr[1];
    for (int i = 0; i < 5; i++)
        cout << arr[i] << " ";
    cout << "\\n";
    cout << &arr[0] << " " << &arr[1] << "\\n";
    arr[5] = 99;   // BUG: index 5 does not exist
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'arrays', part: 1, lesson: '01', lessonFile: '01-cpp-and-complexity.md',
    title: L('Arrays are boxes side by side', 'อาร์เรย์คือกล่องที่เรียงติดกัน'),
    summary: L('An array is N boxes in a row with no gaps. That is why arr[i] is instant: its address is just base + i × size. It is also why going past the end silently tramples a neighbour.',
      'อาร์เรย์คือกล่อง N กล่องเรียงต่อกันไม่มีช่องว่าง arr[i] จึงเข้าถึงได้ทันที เพราะแอดเดรสคือ base + i × ขนาด และนี่ก็คือเหตุผลที่การเขียนเกินขอบเขตไปเหยียบเพื่อนบ้านได้แบบเงียบ ๆ'),
    blurb: L('Contiguous memory, index arithmetic, out-of-bounds writes.', 'หน่วยความจำต่อเนื่อง การคำนวณดัชนี การเขียนเกินขอบ'),
    code,
    build(sim) {
      let ival = null, base = 0;
      sim.call('main()');
      sim.step(at('int main'), L('main starts with an empty frame.', 'main เริ่มทำงานด้วยเฟรมว่าง'));
      const guard = sim.local('guard', 'int', 7);
      sim.step(at('int guard'), L('<code>guard</code> is an ordinary int. Remember its address: <code>' + hex(guard) + '</code>. It will matter at the end.', '<code>guard</code> เป็น int ธรรมดา จำแอดเดรสของมันไว้: <code>' + hex(guard) + '</code> มันจะสำคัญตอนท้าย'));
      base = sim.arr('arr', 'int', 5, [10, 20, 30, 0, 0]);
      sim.viewFn = s => {
        const v = findVar(s, 'arr');
        const marks = {}; if (ival != null) marks[Math.min(ival, 5)] = ['i'];
        return { kind: 'array', title: L('address formula', 'สูตรแอดเดรส'), cap: L('address of arr[i] = ' + hex(base) + ' + i × 4', 'แอดเดรสของ arr[i] = ' + hex(base) + ' + i × 4'), rows: [{ label: 'arr', cells: v.cells.map(x => fmtPlain(x)), marks, cls: v.cells.map((x, k) => k === ival ? 'hl' : '') }, { label: L('address', 'แอดเดรส'), w: 46, cells: v.cells.map((x, k) => hex(base + 4 * k).slice(2)), idx: false }] };
      };
      sim.step(at('int arr[5]'), L(
        '<code>int arr[5]</code> reserves <b>5 × 4 = 20 bytes in one piece</b>, from ' + hex(base) + ' to ' + hex(base + 19) + '. Only 3 values were given, so C++ fills the rest with <b>0</b> (with no <code>= {…}</code> at all, all five would be garbage). Notice that <code>arr[4]</code> ends right where <code>guard</code> begins.',
        '<code>int arr[5]</code> จองพื้นที่ <b>5 × 4 = 20 ไบต์ติดกันเป็นก้อนเดียว</b> ตั้งแต่ ' + hex(base) + ' ถึง ' + hex(base + 19) + ' ให้ค่ามาแค่ 3 ตัว C++ จึงเติมที่เหลือเป็น <b>0</b> (ถ้าไม่มี <code>= {…}</code> เลย ทั้งห้าช่องจะเป็นค่าขยะ) สังเกตว่า <code>arr[4]</code> จบตรงที่ <code>guard</code> เริ่มพอดี'));
      const s0 = sim.r(base), s1 = sim.r(base + 4);
      sim.w(base + 12, s0 + s1);
      sim.step(at('arr[3] = arr[0]'), L(
        'To find <code>arr[3]</code> the CPU computes ' + hex(base) + ' + 3×4 = <b>' + hex(base + 12) + '</b>. No searching, just one multiplication and one addition. That is why array access is O(1).',
        'การหา <code>arr[3]</code> CPU คำนวณ ' + hex(base) + ' + 3×4 = <b>' + hex(base + 12) + '</b> ไม่ต้องค้นหาเลย แค่คูณหนึ่งครั้งบวกหนึ่งครั้ง นี่คือเหตุผลที่การเข้าถึงอาร์เรย์เป็น O(1)'));
      const ia = sim.local('i', 'int', 0);
      sim.tagFn = s => { const v = findVar(s, 'i'); return v && v.value < 5 ? [TAG(base + 4 * v.value, 'i', 't2')] : []; };
      ival = 0;
      sim.step(at('for (int i'), L('The loop variable <code>i</code> gets its own box. It starts at 0.', 'ตัวแปรลูป <code>i</code> ได้กล่องของตัวเอง เริ่มที่ 0'));
      for (let k = 0; k < 5; k++) {
        const v = sim.r(base + 4 * k);
        sim.print(v + ' ');
        sim.step(at('cout << arr[i]'), L(
          'i = ' + k + ': read the box at ' + hex(base) + ' + ' + k + '×4 = <code>' + hex(base + 4 * k) + '</code> and print <b>' + v + '</b>.',
          'i = ' + k + ': อ่านกล่องที่ ' + hex(base) + ' + ' + k + '×4 = <code>' + hex(base + 4 * k) + '</code> แล้วพิมพ์ <b>' + v + '</b>'));
        sim.w(ia, k + 1); ival = k + 1;
        if (k < 4) sim.step(at('for (int i'), L('<code>i++</code> → ' + (k + 1) + ', and ' + (k + 1) + ' &lt; 5, so the loop goes on.', '<code>i++</code> → ' + (k + 1) + ' และ ' + (k + 1) + ' &lt; 5 ลูปจึงทำต่อ'));
      }
      sim.step(at('for (int i'), L('i = 5: the test <code>5 &lt; 5</code> fails and the loop ends. i\'s box disappears when the loop\'s scope ends.', 'i = 5: เงื่อนไข <code>5 &lt; 5</code> เป็นเท็จ ลูปจบ กล่องของ i หายไปเมื่อจบขอบเขตของลูป'));
      sim.top().vars = sim.top().vars.filter(v => v.name !== 'i'); ival = null; sim.tagFn = null;
      sim.print('\n');
      sim.step(at('cout << "\\n"'), L('Print a newline.', 'พิมพ์ขึ้นบรรทัดใหม่'));
      sim.print(hex(base) + ' ' + hex(base + 4) + '\n');
      sim.step(at('&arr[0]'), L(
        '<code>&arr[0]</code> and <code>&arr[1]</code> are addresses, and they differ by exactly <b>4</b>: one int. (A real run prints long addresses like 0x7ffd3c0a1b40, but the difference is the same.)',
        '<code>&arr[0]</code> กับ <code>&arr[1]</code> เป็นแอดเดรส และต่างกัน <b>4</b> พอดี คือขนาดของ int หนึ่งตัว (ตอนรันจริงจะพิมพ์แอดเดรสยาว ๆ เช่น 0x7ffd3c0a1b40 แต่ผลต่างเท่าเดิม)'));
      sim.tagFn = () => [TAG(base + 20, 'arr[5]?', 't2')];
      sim.step(at('arr[5] = 99'), L(
        '<code>arr[5]</code> means address ' + hex(base) + ' + 5×4 = <b>' + hex(base + 20) + '</b>. C++ does <b>not</b> check bounds. In this layout that address belongs to <code>guard</code>…',
        '<code>arr[5]</code> หมายถึงแอดเดรส ' + hex(base) + ' + 5×4 = <b>' + hex(base + 20) + '</b> C++ <b>ไม่ตรวจ</b>ขอบเขต และในเลย์เอาต์นี้แอดเดรสนั้นเป็นของ <code>guard</code>…'), { cls: 'warn' });
      sim.w(guard, 99);
      sim.step(at('arr[5] = 99'), L(
        '…so <code>guard</code> silently becomes 99. This is <b>undefined behaviour</b>: depending on the compiler it may overwrite another variable, crash, or appear to work. In the grader it often shows up as a wrong answer or a Runtime Error far from the real bug.',
        '…<code>guard</code> จึงกลายเป็น 99 แบบเงียบ ๆ นี่คือ <b>undefined behaviour</b> ขึ้นกับคอมไพเลอร์ อาจเขียนทับตัวแปรอื่น แครช หรือดูเหมือนทำงานได้ ใน grader มักโผล่มาเป็นคำตอบผิดหรือ Runtime Error ที่อยู่ไกลจากบั๊กจริง'), { cls: 'warn' });
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns and its frame is popped.', 'main คืนค่า เฟรมของมันถูก pop'));
    }
  });
})();

// ------------------------------------------------------------------ pointers
(() => {
  const code = `int main() {
    int x = 10;
    int y = 5;
    int* p = &x;      // p holds the ADDRESS of x
    *p = 20;          // go to that address, write 20
    p = &y;           // now p holds y's address
    *p = *p + 1;      // y becomes 6
    int** pp = &p;    // a pointer to a pointer
    **pp = 100;       // follow two arrows: y = 100
    int* q = nullptr; // points nowhere
    cout << x << " " << y << " " << *p << "\\n";
    // *q = 1;        // would crash: nothing lives at 0
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'pointers', part: 1, lesson: '01', lessonFile: '01-cpp-and-complexity.md',
    title: L('Pointers are addresses you can store', 'พอยน์เตอร์คือแอดเดรสที่เก็บไว้ได้'),
    summary: L('A pointer is a box whose value is an address. & asks "where is this box?", and * says "go to the box at this address". Watch the arrow move.',
      'พอยน์เตอร์คือกล่องที่เก็บแอดเดรส & ถามว่า "กล่องนี้อยู่ที่ไหน" ส่วน * บอกว่า "ไปที่กล่องที่แอดเดรสนี้" ดูลูกศรขยับไปมา'),
    blurb: L('&, *, nullptr, pointer to pointer.', '&, *, nullptr และพอยน์เตอร์ซ้อนพอยน์เตอร์'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const x = sim.local('x', 'int', 10);
      sim.step(at('int x'), L('<code>x</code> lives at <code>' + hex(x) + '</code> and holds 10.', '<code>x</code> อยู่ที่ <code>' + hex(x) + '</code> และเก็บค่า 10'));
      const y = sim.local('y', 'int', 5);
      sim.step(at('int y'), L('<code>y</code> lives at <code>' + hex(y) + '</code> and holds 5.', '<code>y</code> อยู่ที่ <code>' + hex(y) + '</code> และเก็บค่า 5'));
      const p = sim.local('p', 'int*', P(x));
      sim.step(at('int* p = &x'), L(
        '<code>&x</code> means "the address of x", which is <b>' + hex(x) + '</b>. That number is stored in the new box <code>p</code>. A pointer is an ordinary 8-byte box; it is just that its value <i>is</i> an address, so the lab draws an arrow to the box at that address.',
        '<code>&x</code> แปลว่า "แอดเดรสของ x" คือ <b>' + hex(x) + '</b> ตัวเลขนี้ถูกเก็บลงกล่องใหม่ <code>p</code> พอยน์เตอร์ก็คือกล่องธรรมดาขนาด 8 ไบต์ เพียงแต่ค่าของมัน<i>คือ</i>แอดเดรส แล็บจึงวาดลูกศรไปยังกล่องที่แอดเดรสนั้น'));
      sim.r(p); sim.w(x, 20);
      sim.step(at('*p = 20'), L(
        '<code>*p = 20</code> in two moves: (1) read p and get ' + hex(x) + '; (2) go to ' + hex(x) + ' and write 20. We changed <code>x</code> without ever writing the name x.',
        '<code>*p = 20</code> ทำสองจังหวะ: (1) อ่าน p ได้ ' + hex(x) + ' (2) ไปที่ ' + hex(x) + ' แล้วเขียน 20 เราเปลี่ยน <code>x</code> โดยไม่ได้เขียนชื่อ x เลย'));
      sim.w(p, P(y));
      sim.step(at('p = &y'), L(
        '<code>p = &y</code> (no star) changes <b>p itself</b>: it now holds ' + hex(y) + '. x is untouched; only the arrow moved.',
        '<code>p = &y</code> (ไม่มีดาว) เปลี่ยน<b>ตัว p เอง</b> ตอนนี้มันเก็บ ' + hex(y) + ' x ไม่ได้ถูกแตะเลย มีแค่ลูกศรที่ย้าย'));
      sim.r(p); const yv = sim.r(y); sim.w(y, yv + 1);
      sim.step(at('*p = *p + 1'), L(
        'Right side first: <code>*p</code> reads the box p points to (y = 5). Add 1. Left side: <code>*p</code> writes 6 into that same box.',
        'ทำฝั่งขวาก่อน: <code>*p</code> อ่านกล่องที่ p ชี้ (y = 5) บวก 1 ฝั่งซ้าย: <code>*p</code> เขียน 6 กลับลงกล่องเดิม'));
      const pp = sim.local('pp', 'int**', P(p));
      sim.step(at('int** pp'), L(
        '<code>pp</code> is a pointer to a pointer: its value is the address of <code>p</code> (' + hex(p) + '). Pointers are boxes too, so they have addresses too.',
        '<code>pp</code> คือพอยน์เตอร์ที่ชี้ไปยังพอยน์เตอร์ ค่าของมันคือแอดเดรสของ <code>p</code> (' + hex(p) + ') พอยน์เตอร์ก็เป็นกล่อง จึงมีแอดเดรสเหมือนกัน'));
      sim.r(pp); sim.r(p); sim.w(y, 100);
      sim.step(at('**pp = 100'), L(
        '<code>**pp</code>: go to pp\'s target (p), read the address stored there (' + hex(y) + '), go there, and write 100. Two arrows, two hops.',
        '<code>**pp</code>: ไปที่เป้าหมายของ pp (คือ p) อ่านแอดเดรสที่เก็บอยู่ (' + hex(y) + ') ไปที่นั่น แล้วเขียน 100 ลูกศรสองอัน กระโดดสองครั้ง'));
      sim.local('q', 'int*', P(0));
      sim.step(at('int* q'), L(
        '<code>nullptr</code> is address 0. No program data ever lives there, so it is the standard way to say "points to nothing". Always check <code>if (q != nullptr)</code> before <code>*q</code>.',
        '<code>nullptr</code> คือแอดเดรส 0 ไม่มีข้อมูลของโปรแกรมอยู่ที่นั่นเลย จึงใช้เป็นมาตรฐานว่า "ไม่ได้ชี้ไปไหน" ตรวจ <code>if (q != nullptr)</code> ก่อนใช้ <code>*q</code> เสมอ'));
      sim.r(x); sim.r(y); sim.r(p);
      sim.print('20 100 100\n');
      sim.step(at('cout << x'), L('Print x, y and *p. Since p points to y, *p is 100.', 'พิมพ์ x, y และ *p เนื่องจาก p ชี้ไปที่ y ค่า *p จึงเป็น 100'));
      sim.step(at('// *q = 1'), L(
        'If you ran <code>*q = 1</code>, the CPU would try to write to address 0. The OS stops the program: a <b>segmentation fault</b>, which the grader reports as a Runtime Error.',
        'ถ้ารัน <code>*q = 1</code> CPU จะพยายามเขียนที่แอดเดรส 0 ระบบปฏิบัติการจะหยุดโปรแกรม เรียกว่า <b>segmentation fault</b> ซึ่ง grader รายงานเป็น Runtime Error'), { cls: 'warn' });
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();

// ------------------------------------------------------------------ pointer arithmetic
(() => {
  const code = `int main() {
    int a[5] = {3, 1, 4, 1, 5};
    int* p = a;          // same as &a[0]
    int* e = a + 5;      // one past the end, like end()
    p++;                 // moves 4 bytes, not 1
    *(p + 2) = 9;        // a[3] = 9
    p[1] = 7;            // same as *(p + 1): a[2] = 7
    cout << (e - p) << "\\n";
    int sum = 0;
    for (int* it = a; it != e; it++)
        sum += *it;
    cout << sum << "\\n";
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'pointer-arith', part: 1, lesson: '03', lessonFile: '03-cp-vector.md',
    title: L('Pointer arithmetic and iterators', 'การคำนวณพอยน์เตอร์และ iterator'),
    summary: L('p + 1 does not add 1 byte: it moves by one element. This is exactly how CP::vector\'s iterator works, because its iterator IS a T*. begin() is &mData[0] and end() is one past the last element.',
      'p + 1 ไม่ได้บวก 1 ไบต์ แต่เลื่อนไปหนึ่งสมาชิก นี่คือวิธีที่ iterator ของ CP::vector ทำงาน เพราะ iterator ของมัน<b>คือ</b> T* โดยตรง begin() คือ &mData[0] และ end() คือช่องถัดจากตัวสุดท้าย'),
    blurb: L('p++, p[i], end pointers, and why a vector iterator is a pointer.', 'p++, p[i], พอยน์เตอร์ end และทำไม iterator ของ vector คือพอยน์เตอร์'),
    code,
    build(sim) {
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const a = sim.arr('a', 'int', 5, [3, 1, 4, 1, 5]);
      const view = () => {
        sim.viewFn = s => {
          const arr = findVar(s, 'a');
          const marks = {};
          for (const nm of ['p', 'e', 'it']) { const v = findVar(s, nm); if (v && isP(v.value)) { const k = (v.value.p - a) / 4; (marks[k] = marks[k] || []).push(nm); } }
          return { kind: 'array', title: L('element view', 'มุมมองสมาชิก'), cap: L('Pointers move in whole elements: p + k is the address p + k × sizeof(int).', 'พอยน์เตอร์เลื่อนทีละสมาชิก: p + k คือแอดเดรส p + k × sizeof(int)'), rows: [{ label: 'a', cells: arr.cells.map(x => fmtPlain(x)), marks }] };
        };
      };
      view();
      sim.step(at('int a[5]'), L('Five ints in a row, starting at ' + hex(a) + '.', 'int ห้าตัวเรียงกัน เริ่มที่ ' + hex(a)));
      const p = sim.local('p', 'int*', P(a));
      sim.step(at('int* p = a'), L(
        'Writing just <code>a</code> where a pointer is expected gives the address of its first element ("array decay"). So <code>p = ' + hex(a) + '</code>.',
        'การเขียนแค่ <code>a</code> ในที่ที่ต้องการพอยน์เตอร์ จะได้แอดเดรสของสมาชิกตัวแรก (เรียกว่า array decay) ดังนั้น <code>p = ' + hex(a) + '</code>'));
      const e = sim.local('e', 'int*', P(a + 20));
      sim.step(at('int* e = a + 5'), L(
        '<code>a + 5</code> is ' + hex(a) + ' + 5×4 = <b>' + hex(a + 20) + '</b>, the address <i>just after</i> the last element. You may compute and compare it, but never read <code>*e</code>. Containers call this <code>end()</code>.',
        '<code>a + 5</code> คือ ' + hex(a) + ' + 5×4 = <b>' + hex(a + 20) + '</b> เป็นแอดเดรส<i>ถัดจาก</i>ตัวสุดท้าย คำนวณและเปรียบเทียบได้ แต่ห้ามอ่าน <code>*e</code> คอนเทนเนอร์เรียกสิ่งนี้ว่า <code>end()</code>'));
      sim.w(p, P(a + 4));
      sim.step(at('p++'), L(
        '<code>p++</code> adds <b>sizeof(int) = 4</b> to the address: ' + hex(a) + ' → ' + hex(a + 4) + '. The compiler scales pointer arithmetic by the size of the type pointed to.',
        '<code>p++</code> บวก <b>sizeof(int) = 4</b> เข้าไปในแอดเดรส: ' + hex(a) + ' → ' + hex(a + 4) + ' คอมไพเลอร์คูณขนาดของชนิดที่ชี้ให้อัตโนมัติ'));
      sim.r(p); sim.w(a + 12, 9);
      sim.step(at('*(p + 2) = 9'), L(
        '<code>p + 2</code> = ' + hex(a + 4) + ' + 2×4 = ' + hex(a + 12) + ', which is <code>a[3]</code>. Write 9 there.',
        '<code>p + 2</code> = ' + hex(a + 4) + ' + 2×4 = ' + hex(a + 12) + ' คือ <code>a[3]</code> เขียน 9 ลงไป'));
      sim.r(p); sim.w(a + 8, 7);
      sim.step(at('p[1] = 7'), L(
        '<code>p[1]</code> is defined as <code>*(p + 1)</code>. Indexing is pointer arithmetic in disguise, which is why <code>a[i]</code> and <code>p[i]</code> behave the same.',
        '<code>p[1]</code> นิยามว่าเท่ากับ <code>*(p + 1)</code> การใช้ดัชนีก็คือการคำนวณพอยน์เตอร์ในอีกรูปหนึ่ง <code>a[i]</code> กับ <code>p[i]</code> จึงทำงานเหมือนกัน'));
      sim.r(e); sim.r(p);
      sim.print('4\n');
      sim.step(at('(e - p)'), L(
        'Subtracting two pointers gives a count of <b>elements</b>, not bytes: (' + hex(a + 20) + ' − ' + hex(a + 4) + ') / 4 = 4. This is how CP::vector converts an iterator to an index: <code>pos = it - begin()</code>.',
        'ลบพอยน์เตอร์สองตัวได้จำนวน<b>สมาชิก</b> ไม่ใช่ไบต์: (' + hex(a + 20) + ' − ' + hex(a + 4) + ') / 4 = 4 นี่คือวิธีที่ CP::vector แปลง iterator เป็นดัชนี: <code>pos = it - begin()</code>'));
      const sum = sim.local('sum', 'int', 0);
      sim.step(at('int sum'), L('A running total.', 'ตัวแปรเก็บผลรวม'));
      const it = sim.local('it', 'int*', P(a));
      sim.step(at('for (int* it'), L('<code>it</code> starts at <code>a</code> (begin). This loop is exactly what <code>for (int x : v)</code> does behind the scenes.', '<code>it</code> เริ่มที่ <code>a</code> (begin) ลูปนี้คือสิ่งที่ <code>for (int x : v)</code> ทำอยู่เบื้องหลังพอดี'));
      let s = 0;
      for (let k = 0; k < 5; k++) {
        sim.r(it); const v = sim.r(a + 4 * k); s += v; sim.w(sum, s);
        sim.step(at('sum += *it'), L('<code>*it</code> reads ' + hex(a + 4 * k) + ' = ' + v + '. sum = ' + s + '.', '<code>*it</code> อ่าน ' + hex(a + 4 * k) + ' = ' + v + ' ได้ sum = ' + s));
        sim.w(it, P(a + 4 * (k + 1)));
        sim.step(at('for (int* it'), k < 4
          ? L('<code>it++</code> → ' + hex(a + 4 * (k + 1)) + '. It is not equal to e yet, so continue.', '<code>it++</code> → ' + hex(a + 4 * (k + 1)) + ' ยังไม่เท่ากับ e จึงทำต่อ')
          : L('<code>it++</code> → ' + hex(a + 20) + ', which equals <code>e</code>. The loop stops before ever reading the end address.', '<code>it++</code> → ' + hex(a + 20) + ' ซึ่งเท่ากับ <code>e</code> ลูปหยุดก่อนจะอ่านแอดเดรส end'));
      }
      sim.top().vars = sim.top().vars.filter(v => v.name !== 'it');
      sim.r(sum); sim.print(s + '\n');
      sim.step(at('cout << sum'), L('3 + 1 + 7 + 9 + 5 = ' + s + '.', '3 + 1 + 7 + 9 + 5 = ' + s));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();

// ------------------------------------------------------------------ references
(() => {
  const code = `int main() {
    int x = 1;
    int& r = x;     // r is another name for x
    r = 5;          // writes x
    int y = r;      // copies x's value into y
    y = 9;          // y is its own box: x unchanged
    int* p = &r;    // &r is the address of x
    *p = 7;
    cout << x << " " << r << " " << y << "\\n";
    return 0;
}`;
  const at = LN(code);
  def({
    id: 'references', part: 1, lesson: '01', lessonFile: '01-cpp-and-complexity.md',
    title: L('References are second names', 'reference คือชื่อที่สอง'),
    summary: L('int& r = x does not create a new int. r is another name for the same box. Under the hood the compiler usually implements a reference with the address (dashed box), but you can never move it to another box.',
      'int& r = x ไม่ได้สร้าง int ตัวใหม่ r คืออีกชื่อหนึ่งของกล่องเดิม เบื้องหลังคอมไพเลอร์มักเก็บเป็นแอดเดรส (กล่องเส้นประ) แต่คุณย้ายมันไปชี้กล่องอื่นไม่ได้เลย'),
    blurb: L('Aliases, and how they differ from copies and pointers.', 'ชื่อแฝง และต่างจากการคัดลอกและพอยน์เตอร์อย่างไร'),
    code,
    build(sim) {
      sim.call('main()');
      sim.viewFn = s => {
        const names = []; const xv = findVar(s, 'x');
        if (!xv) return null;
        const owners = ['x']; if (findVar(s, 'r')) owners.push('r');
        const yv = findVar(s, 'y'); const pv = findVar(s, 'p');
        let h = '<div style="display:flex;gap:28px;flex-wrap:wrap;align-items:flex-end;font-family:var(--font-mono)">';
        const box = (labels, val, addr, col) => '<div style="display:grid;justify-items:center;gap:4px"><div style="display:flex;gap:4px">' + labels.map(l => '<span class="tag ' + (l === 'r' ? 't2' : '') + '">' + l + '</span>').join('') + '</div><div style="min-width:70px;height:44px;display:grid;place-items:center;border:2px solid ' + col + ';border-radius:8px;background:var(--panel);font-size:18px">' + val + '</div><div style="font-size:11px;color:var(--muted)">' + addr + '</div></div>';
        h += box(owners, fmtPlain(xv.value), hex(xv.addr), 'var(--stack)');
        if (yv) h += box(['y'], fmtPlain(yv.value), hex(yv.addr), 'var(--stack)');
        if (pv) h += box(['p'], hex(pv.value.p), hex(pv.addr), 'var(--ptr)');
        h += '</div>';
        return { kind: 'html', title: L('names on boxes', 'ชื่อบนกล่อง'), cap: L('Name tags on boxes. A reference is a second tag on an existing box.', 'ป้ายชื่อบนกล่อง reference คือป้ายชื่ออันที่สองที่แปะบนกล่องเดิม'), html: h };
      };
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const x = sim.local('x', 'int', 1);
      sim.step(at('int x'), L('One box, one name: <code>x</code> = 1.', 'กล่องเดียว ชื่อเดียว: <code>x</code> = 1'));
      sim.ref('r', 'int', x);
      sim.step(at('int& r = x'), L(
        '<code>int& r = x;</code> makes <b>no new int</b>. In the concept view, the tag <code>r</code> is stuck on x\'s box. In raw memory, the compiler may keep x\'s address in a hidden slot (dashed), or optimise it away completely. Either way, r can never be re-pointed.',
        '<code>int& r = x;</code> <b>ไม่ได้สร้าง int ใหม่</b> ในภาพแนวคิด ป้าย <code>r</code> ถูกแปะบนกล่องของ x ในหน่วยความจำจริง คอมไพเลอร์อาจเก็บแอดเดรสของ x ไว้ในช่องลับ (เส้นประ) หรือตัดทิ้งไปเลยก็ได้ ไม่ว่าแบบไหน r ก็ย้ายไปชี้ที่อื่นไม่ได้'));
      sim.w(x, 5);
      sim.step(at('r = 5'), L('Writing to <code>r</code> writes to x\'s box. No star needed: the compiler adds the "go to the address" step for you.', 'การเขียนลง <code>r</code> คือการเขียนลงกล่องของ x ไม่ต้องใช้ดาว คอมไพเลอร์ใส่ขั้น "ไปที่แอดเดรส" ให้เอง'));
      const xv = sim.r(x);
      const y = sim.local('y', 'int', xv);
      sim.step(at('int y = r'), L('<code>int y = r;</code> declares a plain int, so it gets a <b>new box</b> holding a <b>copy</b> of the value 5.', '<code>int y = r;</code> ประกาศ int ธรรมดา จึงได้<b>กล่องใหม่</b>ที่เก็บ<b>สำเนา</b>ของค่า 5'));
      sim.w(y, 9);
      sim.step(at('y = 9'), L('Changing the copy does not touch the original. x stays 5.', 'เปลี่ยนสำเนาไม่กระทบตัวจริง x ยังเป็น 5'));
      sim.local('p', 'int*', P(x));
      sim.step(at('int* p = &r'), L('The address of a reference is the address of the thing it refers to: <code>&r == &x == ' + hex(x) + '</code>.', 'แอดเดรสของ reference คือแอดเดรสของสิ่งที่มันอ้างถึง: <code>&r == &x == ' + hex(x) + '</code>'));
      sim.w(x, 7);
      sim.step(at('*p = 7'), L('Through the pointer, write 7. x and r both "see" 7 because they are the same box.', 'เขียน 7 ผ่านพอยน์เตอร์ x และ r เห็นค่า 7 ทั้งคู่ เพราะเป็นกล่องเดียวกัน'));
      sim.r(x); sim.r(y);
      sim.print('7 7 9\n');
      sim.step(at('cout'), L(
        'Output <code>7 7 9</code>. Summary: a <b>copy</b> is a new box; a <b>reference</b> is a new name for an old box; a <b>pointer</b> is a new box that holds an old box\'s address.',
        'ผลลัพธ์ <code>7 7 9</code> สรุป: <b>สำเนา</b> = กล่องใหม่ / <b>reference</b> = ชื่อใหม่ของกล่องเดิม / <b>พอยน์เตอร์</b> = กล่องใหม่ที่เก็บแอดเดรสของกล่องเดิม'));
      sim.ret(0, { show: false });
      sim.step(at('return 0'), L('main returns.', 'main คืนค่า'));
    }
  });
})();
