/* Part II · CP::list (real code from list.h) */
(() => {
  const CLS = `namespace CP {
template <typename T>
class list {
  protected:
    class node {
      public:
        T data;
        node *prev;
        node *next;
        node() :
          data( T() ), prev( this ), next( this ) { }
        node(const T& data,node* prev, node* next) :
          data ( T(data) ), prev( prev ), next( next ) { }
    };
    class list_iterator {
      public:
        node* ptr;
        list_iterator& operator++() { ptr = ptr->next; return (*this); }
    };
    node *mHeader;   // the sentinel
    size_t mSize;
  public:
    typedef list_iterator iterator;
    list() :
      mHeader( new node() ), mSize( 0 ) { }
    iterator begin() { return iterator(mHeader->next); }
    iterator end()   { return iterator(mHeader); }
    void push_back(const T& element)  { insert(end(),element); }
    void push_front(const T& element) { insert(begin(),element); }
    void pop_front() { erase(begin()); }
    void pop_back()  { erase(iterator(mHeader->prev)); }

    iterator insert(iterator it,const T& element) {
      node *n = new node(element,it.ptr->prev, it.ptr);
      it.ptr->prev->next = n;
      it.ptr->prev = n;
      mSize++;
      return iterator(n);
    }
    iterator erase(iterator it) {
      iterator tmp(it.ptr->next);
      it.ptr->prev->next = it.ptr->next;
      it.ptr->next->prev = it.ptr->prev;
      delete it.ptr;
      mSize--;
      return tmp;
    }
    ~list() { clear(); delete mHeader; }
};
}
int main() {
  CP::list<int> l;
`;
  const parse = str => {
    const ops = parseOps(str, 12).map(o => {
      const n = o[0];
      if (n === 'push_back' || n === 'push_front') { if (typeof o[1] !== 'number') throw userErr(L(n + ' needs a number.', n + ' ต้องมีตัวเลข')); return [n, o[1]]; }
      if (n === 'insert') { if (typeof o[1] !== 'number' || typeof o[2] !== 'number') throw userErr(L('insert needs a position and a value.', 'insert ต้องมีตำแหน่งและค่า')); return ['insert', o[1], o[2]]; }
      if (n === 'erase') { if (typeof o[1] !== 'number') throw userErr(L('erase needs a position.', 'erase ต้องมีตำแหน่ง')); return ['erase', o[1]]; }
      if (n === 'pop_front' || n === 'pop_back') return [n];
      throw userErr(L('Unknown operation "' + n + '". Use push_back, push_front, insert, erase, pop_front, pop_back.', 'ไม่รู้จักคำสั่ง "' + n + '" ใช้ได้: push_back, push_front, insert, erase, pop_front, pop_back'));
    });
    if (!ops.length) throw userErr(L('Type at least one operation.', 'ใส่คำสั่งอย่างน้อยหนึ่งคำสั่ง'));
    return ops;
  };
  const line = o => {
    if (o[0] === 'push_back' || o[0] === 'push_front') return '  l.' + o[0] + '(' + o[1] + ');';
    if (o[0] === 'insert') return '  { auto it = l.begin(); for (int k = 0; k < ' + o[1] + '; k++) ++it; l.insert(it, ' + o[2] + '); }';
    if (o[0] === 'erase') return '  { auto it = l.begin(); for (int k = 0; k < ' + o[1] + '; k++) ++it; l.erase(it); }';
    return '  l.' + o[0] + '();';
  };
  const codeOf = ops => CLS + ops.map(line).join('\n') + '\n}\n';
  const DEF = 'push_back 10, push_back 20, push_front 5, insert 2 15, erase 1, pop_back';
  def({
    id: 'cp-list', part: 2, lesson: '05', lessonFile: '05-cp-list.md', dangOK: true,
    title: L('CP::list: nodes, a sentinel, and pointer surgery', 'CP::list: โหนด sentinel และการผ่าตัดพอยน์เตอร์'),
    summary: L('Every element is its own heap node holding data, prev and next. The header (sentinel) node holds no data and closes the circle, so insert and erase never need a special case. Watch each pointer assignment of insert and erase, one arrow at a time.',
      'สมาชิกแต่ละตัวเป็นโหนดของตัวเองบน heap ที่เก็บ data, prev และ next โหนด header (sentinel) ไม่เก็บข้อมูลและปิดวงให้ครบ insert และ erase จึงไม่ต้องมีกรณีพิเศษ ดูการกำหนดพอยน์เตอร์ทีละลูกศรใน insert และ erase'),
    blurb: L('Header node, the 4 link updates of insert, unlinking in erase.', 'โหนด header การแก้ลิงก์ 4 จุดของ insert และการปลดโหนดใน erase'),
    params: [{ id: 'ops', label: L('Operations', 'คำสั่ง'), value: DEF }],
    paramHint: L('push_back x · push_front x · insert pos x · erase pos · pop_front · pop_back', 'push_back x · push_front x · insert pos x · erase pos · pop_front · pop_back'),
    code: codeOf(parse(DEF)),
    codeFn: p => { try { return codeOf(parse(p.ops)); } catch (e) { return CLS + '}\n'; } },
    build(sim, prm) {
      const ops = parse(prm.ops), code = codeOf(ops), at = LN(code);
      const mainL = at('int main');
      let l, H;
      const fn = x => 'list<int>::' + x;
      const nodeF = (addr, f) => sim.pf(addr, f);
      const order = () => { const out = []; let p = nodeF(H, 'next').p, guard = 0; while (p !== H && guard++ < 50) { out.push(p); p = nodeF(p, 'next').p; } return out; };
      const vals = () => order().map(a => nodeF(a, 'data'));
      const labelNodes = () => { for (const b of sim.heap) if (b.kind === 'obj' && b.addr !== H) b.label = L('node ' + fmtPlain(b.fields[0].value), 'โหนด ' + fmtPlain(b.fields[0].value)); };

      sim.viewFn = S => {
        if (!H) return null;
        const get = (a, f) => { const b = S.heap.find(x => x.addr === a && !x.freed); return b ? b.fields.find(x => x.name === f).value : null; };
        const nodes = [], seen = new Set(), slot = new Map();
        nodes.push({ addr: H, label: 'header', sub: hex(H), slot: 0, header: true }); seen.add(H); slot.set(H, 0);
        let p = get(H, 'next'), k = 1, guard = 0;
        while (p && p.p !== H && seen.size < 40 && guard++ < 40) {
          const a = p.p; if (seen.has(a) || !S.heap.find(x => x.addr === a && !x.freed)) break;
          seen.add(a); slot.set(a, k); nodes.push({ addr: a, label: fmtPlain(get(a, 'data')), sub: hex(a), slot: k++ });
          p = get(a, 'next');
        }
        // nodes not reachable via next (being inserted or being removed)
        for (const b of S.heap) if (b.kind === 'obj' && !seen.has(b.addr)) {
          const pv = b.fields.find(x => x.name === 'prev').value;
          const base = pv && slot.has(pv.p) ? slot.get(pv.p) + 0.5 : k;
          nodes.push({ addr: b.addr, label: fmtPlain(b.fields[0].value), sub: hex(b.addr), slot: base, row: 1, cls: b.freed ? 'bad' : 'chg' });
          seen.add(b.addr);
        }
        const links = [];
        for (const n of nodes) {
          const b = S.heap.find(x => x.addr === n.addr); if (!b) continue;
          const nx = b.fields.find(x => x.name === 'next').value, pv = b.fields.find(x => x.name === 'prev').value;
          if (nx && seen.has(nx.p)) links.push({ from: n.addr, to: nx.p, kind: 'next' });
          if (pv && seen.has(pv.p)) links.push({ from: n.addr, to: pv.p, kind: 'prev' });
        }
        // highlight the iterator target
        const top = S.top();
        const itv = top && top.vars.find(x => x.name === 'it' && x.kind === 'obj');
        if (itv) { const t = itv.fields[0].value; const nd = nodes.find(x => isP(t) && x.addr === t.p); if (nd) nd.tag = 'it'; }
        const nv = top && top.vars.find(x => x.name === 'n');
        if (nv && isP(nv.value)) { const nd = nodes.find(x => x.addr === nv.value.p); if (nd) nd.tag = (nd.tag ? nd.tag + ',' : '') + 'n'; }
        return { kind: 'chain', title: L('the chain of nodes', 'สายโซ่ของโหนด'), cap: L('Red arcs on top are next pointers; blue arcs below are prev pointers. The last node\'s next and the header\'s prev close the circle. A node being inserted or removed is drawn on the lower row.', 'เส้นโค้งสีแดงด้านบนคือพอยน์เตอร์ next เส้นสีน้ำเงินด้านล่างคือ prev next ของโหนดสุดท้ายและ prev ของ header ปิดวงให้ครบ โหนดที่กำลังถูกแทรกหรือถูกลบจะอยู่แถวล่าง'), nodes, links };
      };

      sim.call('main()');
      sim.step(mainL, L('main starts.', 'main เริ่มทำงาน'));
      l = sim.obj('l', 'CP::list<int>', [['mHeader', 'node*', undefined], ['mSize', 'size_t', undefined]]);
      sim.call(fn('list()')); sim.param('this', 'list*', P(l));
      H = sim.newObj('node', [['data', 'int', 0], ['prev', 'node*', P(0)], ['next', 'node*', P(0)]], { label: L('header (sentinel)', 'header (sentinel)'), expr: 'new node()' });
      sim.wf(H, 'prev', P(H)); sim.wf(H, 'next', P(H));
      sim.wf(l, 'mHeader', P(H)); sim.wf(l, 'mSize', 0);
      sim.step(at('mHeader( new node() )'), L(
        'The constructor allocates the <b>header node</b>. Its <code>node()</code> constructor sets <code>prev = next = this</code>: an empty list is a header that points to itself in both directions. Its data (0) is never used.',
        'คอนสตรักเตอร์จอง<b>โหนด header</b> คอนสตรักเตอร์ <code>node()</code> ของมันตั้งค่า <code>prev = next = this</code> list ว่างคือ header ที่ชี้กลับมาที่ตัวเองทั้งสองทาง data ของมัน (0) ไม่เคยถูกใช้'));
      sim.ret(undefined, { show: false });
      sim.step(mainL + 1, L('l is ready. On the stack it is only 16 bytes: the header\'s address and the size.', 'l พร้อมใช้ บน stack มันมีแค่ 16 ไบต์: แอดเดรสของ header กับขนาด'));

      const insertAt = (target, val, tempA) => {
        sim.call(fn('insert(iterator it, const T& element)'));
        sim.param('this', 'list*', P(l));
        sim.obj('it', 'iterator', [['ptr', 'node*', P(target)]], { param: true });
        sim.ref('element', 'const int', tempA, { param: true });
        sim.step(at('iterator insert'), L('insert(it, ' + val + '): the new node must go <b>before</b> ' + (target === H ? 'the header, i.e. at the very end' : 'the node ' + fmtPlain(nodeF(target, 'data'))) + '. it.ptr = ' + hex(target) + '.', 'insert(it, ' + val + '): โหนดใหม่ต้องอยู่<b>ก่อน</b> ' + (target === H ? 'header ซึ่งก็คือท้ายสุด' : 'โหนด ' + fmtPlain(nodeF(target, 'data'))) + ' it.ptr = ' + hex(target)));
        const before = sim.rf(target, 'prev').p;
        const n = sim.newObj('node', [['data', 'int', val], ['prev', 'node*', P(before)], ['next', 'node*', P(target)]], { expr: 'new node(' + val + ', …)' });
        sim.local('n', 'node*', P(n));
        labelNodes();
        sim.step(at('node *n = new node(element'), L(
          'Allocate a node anywhere on the heap (nodes are <b>not</b> contiguous). Its constructor already sets n->prev = ' + hex(before) + ' (the node before) and n->next = ' + hex(target) + '. Nobody points to n yet, so the list itself is unchanged. (2 of 4 links done.)',
          'จองโหนดที่ไหนก็ได้บน heap (โหนด<b>ไม่ได้</b>อยู่ติดกัน) คอนสตรักเตอร์ตั้ง n->prev = ' + hex(before) + ' (โหนดก่อนหน้า) และ n->next = ' + hex(target) + ' ไว้แล้ว ยังไม่มีใครชี้มาที่ n ดังนั้นตัว list ยังไม่เปลี่ยน (ทำไปแล้ว 2 จาก 4 ลิงก์)'));
        sim.rf(target, 'prev'); sim.wf(before, 'next', P(n));
        sim.step(at('it.ptr->prev->next = n'), L('<code>it.ptr->prev->next = n</code>: the node before (' + hex(before) + ') now points <b>forward</b> to n. (3 of 4.)', '<code>it.ptr->prev->next = n</code>: โหนดก่อนหน้า (' + hex(before) + ') ชี้<b>ไปข้างหน้า</b>ที่ n (3 จาก 4)'));
        sim.wf(target, 'prev', P(n));
        sim.step(at('it.ptr->prev = n;'), L('<code>it.ptr->prev = n</code>: the node after now points <b>back</b> to n. (4 of 4.) The order of these two lines matters: the first one still needed the old it.ptr->prev.', '<code>it.ptr->prev = n</code>: โหนดถัดไปชี้<b>ย้อนกลับ</b>มาที่ n (4 จาก 4) ลำดับของสองบรรทัดนี้สำคัญ บรรทัดแรกยังต้องใช้ค่า it.ptr->prev เดิม'));
        sim.wf(l, 'mSize', sim.rf(l, 'mSize') + 1);
        sim.step(at('mSize++'), L('mSize = ' + sim.pf(l, 'mSize') + '. Total work: O(1), however long the list is. No element moved in memory.', 'mSize = ' + sim.pf(l, 'mSize') + ' งานทั้งหมด O(1) ไม่ว่า list จะยาวแค่ไหน ไม่มีสมาชิกตัวไหนถูกย้ายในหน่วยความจำ'));
        sim.ret(P(n), { type: 'node*', show: false });
      };
      const eraseAt = (target) => {
        sim.call(fn('erase(iterator it)'));
        sim.param('this', 'list*', P(l));
        sim.obj('it', 'iterator', [['ptr', 'node*', P(target)]], { param: true });
        const v0 = fmtPlain(nodeF(target, 'data'));
        sim.step(at('iterator erase'), L('erase the node holding ' + v0 + ' at ' + hex(target) + '.', 'ลบโหนดที่เก็บ ' + v0 + ' ที่ ' + hex(target)));
        const nx = sim.rf(target, 'next').p, pv = sim.rf(target, 'prev').p;
        sim.obj('tmp', 'iterator', [['ptr', 'node*', P(nx)]]);
        sim.step(at('iterator tmp(it.ptr->next)'), L('Remember the next node (' + hex(nx) + ') <b>before</b> anything is destroyed; this is what erase returns.', 'จำโหนดถัดไป (' + hex(nx) + ') ไว้<b>ก่อน</b>ที่อะไรจะถูกทำลาย นี่คือค่าที่ erase จะคืน'));
        sim.wf(pv, 'next', P(nx));
        sim.step(at('it.ptr->prev->next = it.ptr->next'), L('The previous node skips over it: prev->next = ' + hex(nx) + '.', 'โหนดก่อนหน้าข้ามโหนดนี้ไป: prev->next = ' + hex(nx)));
        sim.wf(nx, 'prev', P(pv));
        sim.step(at('it.ptr->next->prev = it.ptr->prev'), L('The next node points back past it: next->prev = ' + hex(pv) + '. Now nobody points to ' + hex(target) + ' (it drops to the lower row), though its own prev/next still hold old addresses.', 'โหนดถัดไปชี้ย้อนข้ามมันไป: next->prev = ' + hex(pv) + ' ตอนนี้ไม่มีใครชี้มาที่ ' + hex(target) + ' แล้ว (มันตกลงไปแถวล่าง) แม้ prev/next ของมันเองยังเก็บแอดเดรสเดิมอยู่'));
        sim.free(target);
        sim.step(at('delete it.ptr'), L('<code>delete it.ptr</code> returns the node\'s 24 bytes. The iterator <code>it</code> is now dangling; that is why erase returns <code>tmp</code>.', '<code>delete it.ptr</code> คืน 24 ไบต์ของโหนด iterator <code>it</code> ตอนนี้ห้อยแล้ว นี่คือเหตุผลที่ erase คืน <code>tmp</code>'));
        sim.wf(l, 'mSize', sim.rf(l, 'mSize') - 1);
        sim.step(at('mSize--'), L('mSize = ' + sim.pf(l, 'mSize') + '. O(1).', 'mSize = ' + sim.pf(l, 'mSize') + ' O(1)'));
        sim.ret(P(nx), { type: 'node*', show: false });
      };

      ops.forEach((o, k) => {
        const L0 = mainL + 2 + k;
        const size = sim.pf(l, 'mSize');
        const nth = i => order()[i];
        if (o[0] === 'push_back' || o[0] === 'push_front') {
          const t = sim.local('temp', 'int', o[1]);
          sim.step(L0, L('<code>l.' + o[0] + '(' + o[1] + ')</code>.', '<code>l.' + o[0] + '(' + o[1] + ')</code>'));
          sim.call(fn(o[0] + '(const T& element)')); sim.param('this', 'list*', P(l)); sim.ref('element', 'const int', t, { param: true });
          const target = o[0] === 'push_back' ? H : sim.rf(H, 'next').p;
          sim.step(at('void ' + o[0]), o[0] === 'push_back'
            ? L('push_back = insert before <b>end()</b>, and end() is the header itself. Inserting before the header means "at the back", because the circle wraps.', 'push_back = insert ก่อน <b>end()</b> และ end() ก็คือ header เอง การแทรกก่อน header คือ "ท้ายสุด" เพราะเป็นวงกลม')
            : L('push_front = insert before <b>begin()</b> = mHeader->next' + (size === 0 ? ', which is the header itself when the list is empty. Same code, no special case.' : '.'), 'push_front = insert ก่อน <b>begin()</b> = mHeader->next' + (size === 0 ? ' ซึ่งตอน list ว่างก็คือ header เอง โค้ดเดียวกัน ไม่มีกรณีพิเศษ' : '')));
          insertAt(target, o[1], t);
          sim.ret(undefined, { show: false }); sim.drop('temp');
        } else if (o[0] === 'insert') {
          if (o[1] < 0 || o[1] > size) throw userErr(L('insert position must be 0…' + size + '.', 'ตำแหน่ง insert ต้องอยู่ในช่วง 0…' + size));
          const t = sim.local('temp', 'int', o[2]);
          const target = o[1] === size ? H : nth(o[1]);
          sim.step(L0, L('Lists have no <code>[ ]</code>: to reach position ' + o[1] + ' we start at begin() and follow next ' + o[1] + ' time(s). That walk is O(k); the insert itself is O(1).', 'list ไม่มี <code>[ ]</code>: จะไปถึงตำแหน่ง ' + o[1] + ' ต้องเริ่มที่ begin() แล้วตาม next ไป ' + o[1] + ' ครั้ง การเดินนี้ใช้ O(k) ส่วน insert เองใช้ O(1)'));
          insertAt(target, o[2], t);
          sim.drop('temp');
        } else if (o[0] === 'erase' || o[0] === 'pop_front' || o[0] === 'pop_back') {
          if (size === 0) throw userErr(L('Cannot erase from an empty list: erase(end()) would delete the header!', 'ลบจาก list ว่างไม่ได้: erase(end()) จะลบ header ทิ้ง!'));
          let idx = o[0] === 'pop_front' ? 0 : o[0] === 'pop_back' ? size - 1 : o[1];
          if (idx < 0 || idx >= size) throw userErr(L('erase position must be 0…' + (size - 1) + '.', 'ตำแหน่ง erase ต้องอยู่ในช่วง 0…' + (size - 1)));
          const target = nth(idx);
          if (o[0] === 'erase') sim.step(L0, L('Walk ' + idx + ' step(s) from begin() to reach the node, then erase it.', 'เดิน ' + idx + ' ก้าวจาก begin() เพื่อไปถึงโหนด แล้วลบมัน'));
          else {
            sim.step(L0, L('<code>l.' + o[0] + '()</code>.', '<code>l.' + o[0] + '()</code>'));
            sim.call(fn(o[0] + '()')); sim.param('this', 'list*', P(l));
            sim.step(at('void ' + o[0]), o[0] === 'pop_back' ? L('The last node is mHeader->prev: O(1), thanks to the circle.', 'โหนดสุดท้ายคือ mHeader->prev: O(1) เพราะเป็นวงกลม') : L('The first node is begin() = mHeader->next.', 'โหนดแรกคือ begin() = mHeader->next'));
          }
          eraseAt(target);
          if (o[0] !== 'erase') sim.ret(undefined, { show: false });
        }
        labelNodes();
        sim.step(L0, L('List now: [' + vals().map(x => fmtPlain(x)).join(', ') + '], mSize = ' + sim.pf(l, 'mSize') + '. In memory the nodes sit wherever the allocator put them; only the pointers define the order.', 'list ตอนนี้: [' + vals().map(x => fmtPlain(x)).join(', ') + '] mSize = ' + sim.pf(l, 'mSize') + ' ในหน่วยความจำ โหนดอยู่ที่ไหนก็ได้ที่ตัวจัดสรรวางไว้ มีแค่พอยน์เตอร์ที่กำหนดลำดับ'));
      });
      const endL = mainL + 2 + ops.length;
      sim.call(fn('~list()')); sim.param('this', 'list*', P(l));
      for (const a of order()) sim.free(a);
      sim.free(H);
      sim.step(at('~list()'), L('At the end of main the destructor runs: <code>clear()</code> erases every node one by one, then the header is deleted. Every <code>new node</code> got its <code>delete</code>.', 'ตอนจบ main destructor ทำงาน: <code>clear()</code> ลบโหนดทีละตัว แล้ว delete header ทุก <code>new node</code> ได้ <code>delete</code> ของมันครบ'));
      sim.ret(undefined, { show: false });
      sim.ret(0, { show: false });
      sim.step(endL, L('Done.', 'เสร็จ'));
    }
  });
})();
