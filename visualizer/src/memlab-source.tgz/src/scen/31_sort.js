/* Part III · insertion sort and merge sort (lessons 09, 12) */
(() => {
  const mainArr = S => S.frames[0] && S.frames[0].vars.find(q => q.name === 'a');
  const parseArr = (p, max) => {
    const a = parseNums(p.arr, max);
    if (a.length < 2) throw userErr(L('Give at least two numbers (up to ' + max + ').', 'ใส่ตัวเลขอย่างน้อยสองตัว (ไม่เกิน ' + max + ')'));
    return a;
  };

  // ---------------------------------------------------------------- insertion sort
  const isCode = a => `void insertionSort(int a[], int n) {
  for (int i = 1; i < n; i++) {
    int key = a[i];            // take a[i] out: its box becomes a "hole"
    int j = i - 1;
    while (j >= 0 && a[j] > key) {
      a[j + 1] = a[j];         // shift the bigger value one box right
      j--;
    }
    a[j + 1] = key;            // drop key into the hole
  }
}
int main() {
  int a[${a.length}] = {${a.join(', ')}};
  insertionSort(a, ${a.length});
  for (int i = 0; i < ${a.length}; i++) cout << a[i] << " ";
}
`;
  def({
    id: 'insertion-sort', part: 3, lesson: '09', lessonFile: '09-sorting-hashing-counting.md',
    title: L('Insertion sort: shifting through a hole', 'Insertion sort: เลื่อนค่าผ่าน "รู"'),
    summary: L('The left part is always sorted. Take the next value out (key), shift every bigger value one box to the right, and drop key into the gap. The function writes straight into main\'s array through the pointer a.',
      'ส่วนซ้ายเรียงแล้วเสมอ หยิบค่าถัดไปออกมา (key) เลื่อนทุกค่าที่ใหญ่กว่าไปทางขวาหนึ่งช่อง แล้ววาง key ลงในช่องว่าง ฟังก์ชันเขียนลงอาเรย์ของ main โดยตรงผ่านพอยน์เตอร์ a'),
    blurb: L('Sorted prefix, key, shifting, O(n²) worst case.', 'ส่วนหน้าที่เรียงแล้ว key การเลื่อน กรณีแย่สุด O(n²)'),
    params: [{ id: 'arr', label: L('Array', 'อาเรย์'), value: '5 2 9 1 6 3' }],
    paramHint: L('2 to 9 numbers · try one that is already sorted, or reversed', '2 ถึง 9 ตัว · ลองอาเรย์ที่เรียงแล้ว หรือเรียงกลับด้าน'),
    code: isCode([5, 2, 9, 1, 6, 3]),
    codeFn: p => { try { return isCode(parseArr(p, 9)); } catch (e) { return isCode([2, 1]); } },
    build(sim, prm) {
      const a = parseArr(prm, 9), n = a.length, code = isCode(a), at = LN(code);
      let st = null;   // {i, j, key, hole, sorted}
      sim.viewFn = S => {
        const v = mainArr(S); if (!v) return null;
        const marks = {}, add = (k, t) => { if (k >= 0) (marks[k] = marks[k] || []).push(t); };
        const cls = v.cells.map(() => '');
        if (st) {
          for (let k = 0; k < n; k++) cls[k] = k < st.sorted ? 'ok' : '';
          if (st.hole != null) { cls[st.hole] = 'dim'; }
          if (st.j != null && st.j >= 0) { add(st.j, 'j'); if (st.cmp) cls[st.j] = 'cmp'; }
          if (st.i != null) add(st.i, 'i');
          if (st.moved != null) cls[st.moved] = 'chg';
        }
        const rows = [{ label: 'a', cells: v.cells.map((c, k) => st && st.hole === k ? '·' : fmtPlain(c)), cls, marks, ranges: st && st.sorted > 0 ? [{ a: 0, b: st.sorted - 1, label: L('sorted', 'เรียงแล้ว'), cls: 'ok' }] : [] }];
        if (st && st.key != null) rows.push({ label: 'key', cells: [st.key], cls: ['hl'], idx: false });
        return { kind: 'array', title: L('the array in main', 'อาเรย์ใน main'), cap: L('Green = sorted part. A "·" is the hole (its old value is still in memory but logically empty). key is a separate box in insertionSort\'s frame.', 'เขียว = ส่วนที่เรียงแล้ว "·" คือรู (ค่าเดิมยังอยู่ในหน่วยความจำ แต่ถือว่าว่าง) key เป็นกล่องแยกในเฟรมของ insertionSort'), rows };
      };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const A = sim.arr('a', 'int', n, a);
      sim.step(at('int a['), L('The unsorted array, in main\'s frame.', 'อาเรย์ที่ยังไม่เรียง อยู่ในเฟรมของ main'));
      sim.top().line = at('insertionSort(a,');
      sim.call('insertionSort(int a[], int n)');
      sim.param('a', 'int*', P(A)); sim.param('n', 'int', n);
      st = { sorted: 1 };
      sim.step(at('void insertionSort'), L('insertionSort gets a <b>pointer</b> to main\'s array, so every <code>a[k] = …</code> below changes main\'s boxes, not a copy. A one-element prefix (a[0]) is already sorted.', 'insertionSort ได้<b>พอยน์เตอร์</b>ไปยังอาเรย์ของ main ทุก <code>a[k] = …</code> ข้างล่างจึงเปลี่ยนกล่องของ main ไม่ใช่สำเนา ส่วนหน้าที่มีตัวเดียว (a[0]) ถือว่าเรียงแล้ว'));
      const iA = sim.local('i', 'int', 1);
      let shifts = 0;
      for (let i = 1; i < n; i++) {
        sim.w(iA, i);
        const key = sim.r(A + 4 * i);
        const kA = sim.local('key', 'int', key);
        st = { sorted: i, i, key, hole: i };
        sim.step(at('int key = a[i]'), L('i = ' + i + ': copy a[' + i + '] = <b>' + key + '</b> into key. Box ' + i + ' is now a hole we may fill.', 'i = ' + i + ': คัดลอก a[' + i + '] = <b>' + key + '</b> ไปไว้ใน key ช่อง ' + i + ' ตอนนี้เป็นรูที่เติมได้'), { lines: [at('for (int i = 1')] });
        let j = i - 1;
        const jA = sim.local('j', 'int', j);
        st.j = j;
        sim.step(at('int j = i - 1'), L('j = ' + j + ': start comparing with the last value of the sorted part.', 'j = ' + j + ': เริ่มเทียบกับค่าสุดท้ายของส่วนที่เรียงแล้ว'));
        let hole = i;
        while (true) {
          if (j < 0) { st = { sorted: i, i, key, hole, j }; sim.r(jA); sim.step(at('while (j >= 0'), L('j = −1: we passed the front of the array. key is the smallest so far.', 'j = −1: เลยหน้าสุดของอาเรย์แล้ว key เล็กที่สุดเท่าที่เจอ')); break; }
          const v = sim.r(A + 4 * j); sim.r(kA);
          st = { sorted: i, i, key, hole, j, cmp: true };
          if (v > key) {
            sim.step(at('while (j >= 0'), L('a[' + j + '] = ' + v + ' &gt; key = ' + key + ': it must move right.', 'a[' + j + '] = ' + v + ' &gt; key = ' + key + ': มันต้องเลื่อนไปทางขวา'));
            sim.w(A + 4 * (j + 1), v); shifts++;
            hole = j;
            st = { sorted: i, i, key, hole, j, moved: j + 1 };
            sim.step(at('a[j + 1] = a[j]'), L('Shift: a[' + (j + 1) + '] = ' + v + '. The hole moves to box ' + j + '. (Its old ' + v + ' is still there, but it will be overwritten.)', 'เลื่อน: a[' + (j + 1) + '] = ' + v + ' รูย้ายไปช่อง ' + j + ' (ค่า ' + v + ' เดิมยังอยู่ แต่จะถูกเขียนทับ)'));
            j--; sim.w(jA, j); st.j = j;
            sim.step(at('j--;'), L('j = ' + j + '.', 'j = ' + j));
          } else {
            sim.step(at('while (j >= 0'), L('a[' + j + '] = ' + v + ' ≤ key = ' + key + ': stop. Everything left of here is already ≤ key.', 'a[' + j + '] = ' + v + ' ≤ key = ' + key + ': หยุด ทุกตัวทางซ้ายจากตรงนี้ ≤ key อยู่แล้ว'));
            break;
          }
        }
        sim.w(A + 4 * (j + 1), sim.r(kA));
        st = { sorted: i + 1, moved: j + 1 };
        sim.step(at('a[j + 1] = key'), L('Drop key into the hole: a[' + (j + 1) + '] = ' + key + '. Now a[0..' + i + '] is sorted.', 'วาง key ลงในรู: a[' + (j + 1) + '] = ' + key + ' ตอนนี้ a[0..' + i + '] เรียงแล้ว'));
        sim.drop('j'); sim.drop('key');
      }
      st = { sorted: n };
      sim.step(at('for (int i = 1'), L('i = ' + n + ' = n: done. Total shifts: ' + shifts + ' (the number of out-of-order pairs). Already sorted input needs 0 shifts, O(n); reversed input needs n(n−1)/2, O(n²).', 'i = ' + n + ' = n: เสร็จ เลื่อนทั้งหมด ' + shifts + ' ครั้ง (เท่ากับจำนวนคู่ที่ผิดลำดับ) อินพุตที่เรียงแล้วไม่ต้องเลื่อนเลย O(n) ส่วนที่เรียงกลับต้อง n(n−1)/2 ครั้ง O(n²)'));
      sim.ret(undefined, { show: false });
      st = null;
      for (let k = 0; k < n; k++) sim.print(sim.r(A + 4 * k) + ' ');
      sim.step(at('for (int i = 0; i < ' + n), L('Back in main, the array itself is sorted: the function changed it through the pointer.', 'กลับมาที่ main อาเรย์ถูกเรียงแล้วจริง ๆ ฟังก์ชันเปลี่ยนมันผ่านพอยน์เตอร์'));
      sim.ret(0, { show: false });
    }
  });

  // ---------------------------------------------------------------- merge sort
  const msCode = a => `void mergeSort(int a[], int lo, int hi) {   // sorts a[lo..hi)
  if (hi - lo <= 1) return;
  int mid = (lo + hi) / 2;
  mergeSort(a, lo, mid);
  mergeSort(a, mid, hi);
  int* tmp = new int[hi - lo];
  int i = lo, j = mid, k = 0;
  while (i < mid && j < hi)
    tmp[k++] = (a[i] <= a[j]) ? a[i++] : a[j++];
  while (i < mid) tmp[k++] = a[i++];
  while (j < hi)  tmp[k++] = a[j++];
  for (k = 0; k < hi - lo; k++) a[lo + k] = tmp[k];
  delete[] tmp;
}
int main() {
  int a[${a.length}] = {${a.join(', ')}};
  mergeSort(a, 0, ${a.length});
  for (int i = 0; i < ${a.length}; i++) cout << a[i] << " ";
}
`;
  def({
    id: 'merge-sort', part: 3, lesson: '12', lessonFile: '12-divide-and-conquer.md', dangOK: true,
    title: L('Merge sort: recursion + a temporary array', 'Merge sort: การเรียกซ้ำ + อาเรย์ชั่วคราว'),
    summary: L('Split the range in half, sort each half recursively, then merge the two sorted halves through a temporary heap array. Watch the call stack grow to depth log n, and each merge allocate and free its own tmp.',
      'แบ่งช่วงเป็นสองครึ่ง เรียงแต่ละครึ่งแบบเรียกซ้ำ แล้วรวมสองครึ่งที่เรียงแล้วผ่านอาเรย์ชั่วคราวบน heap ดู call stack ลึกขึ้นเป็น log n และแต่ละการรวมจองแล้วคืน tmp ของตัวเอง'),
    blurb: L('Divide and conquer, call stack depth, merging with two pointers.', 'แบ่งแยกและเอาชนะ ความลึกของ call stack การรวมด้วยสองพอยน์เตอร์'),
    params: [{ id: 'arr', label: L('Array', 'อาเรย์'), value: '38 27 43 3 9 82' }],
    paramHint: L('2 to 8 numbers', '2 ถึง 8 ตัว'),
    code: msCode([38, 27, 43, 3, 9, 82]),
    codeFn: p => { try { return msCode(parseArr(p, 8)); } catch (e) { return msCode([2, 1]); } },
    build(sim, prm) {
      const a = parseArr(prm, 8), n = a.length, code = msCode(a), at = LN(code);
      const tree = {}; let cid = 0, cur = null, mg = null;   // mg = {lo, mid, hi, i, j, k, tmp}
      sim.viewFn = S => {
        const v = mainArr(S); if (!v) return null;
        const marks = {}, add = (k, t) => { (marks[k] = marks[k] || []).push(t); };
        const cls = v.cells.map(() => 'dim');
        const node = cur && tree[cur];
        if (node) for (let k = node.lo; k < node.hi; k++) cls[k] = '';
        if (mg) { if (mg.i != null && mg.i < mg.mid) { add(mg.i, 'i'); cls[mg.i] = 'cmp'; } if (mg.j != null && mg.j < mg.hi) { add(mg.j, 'j'); cls[mg.j] = 'cmp'; } if (mg.w != null) { cls[mg.w] = 'chg'; } }
        const ranges = node ? (mg ? [{ a: mg.lo, b: mg.mid - 1, label: L('left half', 'ครึ่งซ้าย') }, { a: mg.mid, b: mg.hi - 1, label: L('right half', 'ครึ่งขวา'), cls: 'cmp' }] : [{ a: node.lo, b: node.hi - 1, label: '[' + node.lo + ', ' + node.hi + ')' }]) : [];
        const rows = [{ label: 'a', cells: v.cells.map(fmtPlain), cls, marks, ranges }];
        if (mg && mg.tmp) { const b = S.heap.find(x => x.addr === mg.tmp && !x.freed); if (b) rows.push({ label: 'tmp', cells: b.cells.map(c => c === undefined ? '?' : fmtPlain(c)), cls: b.cells.map((c, k) => k === mg.kw ? 'chg' : (c === undefined ? 'dim' : 'hp')), marks: mg.k != null && mg.k < b.cells.length ? { [mg.k]: ['k'] } : {}, idx0: 0 }); }
        return { kind: 'multi', title: L('array and call tree', 'อาเรย์และต้นไม้การเรียก'), parts: [
          { kind: 'array', rows },
          { kind: 'tree', cap: L('Call tree: each box is one call mergeSort(lo, hi). Teal = running now, violet = waiting on the stack, green = finished.', 'ต้นไม้การเรียก: แต่ละกล่องคือการเรียก mergeSort(lo, hi) หนึ่งครั้ง ฟ้าอมเขียว = กำลังทำงาน ม่วง = รออยู่บน stack เขียว = เสร็จแล้ว'), nodes: tree, root: 'c1', square: true, gy: 52, gx: 64 }] };
      };
      const setCls = () => { for (const id in tree) tree[id].cls = tree[id].done ? 'ok' : (id === cur ? 'hl' : (tree[id].onStack ? 'cmp' : '')); };
      sim.call('main()');
      sim.step(at('int main'), L('main starts.', 'main เริ่มทำงาน'));
      const A = sim.arr('a', 'int', n, a);
      sim.step(at('int a['), L('The unsorted array.', 'อาเรย์ที่ยังไม่เรียง'));
      let depth = 0, maxDepth = 0;
      const ms = (lo, hi, parent, callLine) => {
        const id = 'c' + (++cid);
        tree[id] = { label: '[' + lo + ',' + hi + ')', sub: hi - lo > 1 ? '' : fmtPlain(sim.peek(A + 4 * lo)), kids: [], lo, hi, onStack: true };
        if (parent) tree[parent].kids.push(id);
        const prevCur = cur; cur = id; setCls();
        sim.top().line = callLine;
        sim.call('mergeSort(int a[], int lo, int hi)');
        sim.param('a', 'int*', P(A)); sim.param('lo', 'int', lo); sim.param('hi', 'int', hi);
        depth++; maxDepth = Math.max(maxDepth, depth);
        sim.step(at('void mergeSort'), L('mergeSort(' + lo + ', ' + hi + '): a new frame (depth ' + depth + '). Every frame gets its own lo, hi, and pointer a, but they all point at the <b>same</b> array in main.', 'mergeSort(' + lo + ', ' + hi + '): เฟรมใหม่ (ความลึก ' + depth + ') ทุกเฟรมมี lo, hi และพอยน์เตอร์ a ของตัวเอง แต่ทั้งหมดชี้ไปที่อาเรย์<b>เดียวกัน</b>ใน main'));
        if (hi - lo <= 1) {
          tree[id].done = true; tree[id].onStack = false; setCls();
          sim.step(at('if (hi - lo <= 1)'), L('Only ' + (hi - lo) + ' element: already sorted. Return right away (the base case).', 'มีแค่ ' + (hi - lo) + ' ตัว: เรียงอยู่แล้ว คืนกลับทันที (กรณีฐาน)'));
          sim.ret(undefined, { show: false }); depth--; cur = prevCur; setCls(); return;
        }
        const mid = Math.floor((lo + hi) / 2);
        sim.local('mid', 'int', mid);
        sim.step(at('int mid ='), L('mid = ' + mid + ': left half [' + lo + ', ' + mid + '), right half [' + mid + ', ' + hi + ').', 'mid = ' + mid + ': ครึ่งซ้าย [' + lo + ', ' + mid + ') ครึ่งขวา [' + mid + ', ' + hi + ')'));
        ms(lo, mid, id, at('mergeSort(a, lo, mid)'));
        sim.step(at('mergeSort(a, lo, mid)'), L('Back in mergeSort(' + lo + ', ' + hi + '): the left half a[' + lo + '..' + (mid - 1) + '] is sorted. The child frame is gone; this frame was waiting the whole time.', 'กลับมาที่ mergeSort(' + lo + ', ' + hi + '): ครึ่งซ้าย a[' + lo + '..' + (mid - 1) + '] เรียงแล้ว เฟรมลูกหายไป เฟรมนี้รออยู่ตลอด'));
        ms(mid, hi, id, at('mergeSort(a, mid, hi)'));
        sim.step(at('mergeSort(a, mid, hi)'), L('Both halves are sorted. Now merge them.', 'ทั้งสองครึ่งเรียงแล้ว ต่อไปรวมกัน'));
        const T = sim.newArray('int', hi - lo, undefined, { label: 'tmp [' + lo + ',' + hi + ')', expr: 'new int[' + (hi - lo) + ']' });
        sim.local('tmp', 'int*', P(T));
        mg = { lo, mid, hi, tmp: T };
        sim.step(at('int* tmp = new int'), L('<code>new int[' + (hi - lo) + ']</code>: a temporary block on the <b>heap</b> for the merged result. Merging cannot be done safely in place, so merge sort needs O(n) extra memory.', '<code>new int[' + (hi - lo) + ']</code>: บล็อกชั่วคราวบน <b>heap</b> สำหรับผลที่รวมแล้ว การรวมทำในที่เดิมอย่างปลอดภัยไม่ได้ merge sort จึงใช้หน่วยความจำเพิ่ม O(n)'));
        let i = lo, j = mid, k = 0;
        const iA = sim.local('i', 'int', i), jA = sim.local('j', 'int', j), kA = sim.local('k', 'int', 0);
        Object.assign(mg, { i, j, k });
        sim.step(at('int i = lo, j = mid'), L('Two read pointers: i at the start of the left half (' + lo + '), j at the start of the right half (' + mid + '). k is where tmp is written.', 'ตัวชี้อ่านสองตัว: i ที่ต้นครึ่งซ้าย (' + lo + ') j ที่ต้นครึ่งขวา (' + mid + ') k คือตำแหน่งที่จะเขียนใน tmp'));
        const put = (from, which, lineSub, why) => {
          const v = sim.r(A + 4 * from); sim.w(T + 4 * k, v);
          mg.kw = k; mg.w = null;
          if (which === 'i') { i++; sim.w(iA, i); } else { j++; sim.w(jA, j); }
          k++; sim.w(kA, k); Object.assign(mg, { i, j, k });
          sim.step(at(lineSub), why(v));
          mg.kw = null;
        };
        while (i < mid && j < hi) {
          const ai = sim.peek(A + 4 * i), aj = sim.peek(A + 4 * j);
          sim.r(A + 4 * i); sim.r(A + 4 * j);
          if (ai <= aj) put(i, 'i', 'tmp[k++] = (a[i] <= a[j])', v => L('a[i] = ' + ai + ' ≤ a[j] = ' + aj + ': take ' + v + ' from the left. tmp[' + k + '] = ' + v + ', i++ and k++.', 'a[i] = ' + ai + ' ≤ a[j] = ' + aj + ': หยิบ ' + v + ' จากฝั่งซ้าย tmp[' + k + '] = ' + v + ' แล้ว i++ k++'));
          else put(j, 'j', 'tmp[k++] = (a[i] <= a[j])', v => L('a[i] = ' + ai + ' &gt; a[j] = ' + aj + ': take ' + v + ' from the right. tmp[' + k + '] = ' + v + ', j++ and k++.', 'a[i] = ' + ai + ' &gt; a[j] = ' + aj + ': หยิบ ' + v + ' จากฝั่งขวา tmp[' + k + '] = ' + v + ' แล้ว j++ k++'));
        }
        while (i < mid) put(i, 'i', 'while (i < mid) tmp', v => L('The right half is used up. Copy the rest of the left: ' + v + '.', 'ฝั่งขวาหมดแล้ว คัดลอกที่เหลือของฝั่งซ้าย: ' + v));
        while (j < hi) put(j, 'j', 'while (j < hi)  tmp', v => L('The left half is used up. Copy the rest of the right: ' + v + '.', 'ฝั่งซ้ายหมดแล้ว คัดลอกที่เหลือของฝั่งขวา: ' + v));
        mg.i = null; mg.j = null; mg.k = null;
        for (let t = 0; t < hi - lo; t++) sim.w(A + 4 * (lo + t), sim.r(T + 4 * t));
        sim.w(kA, hi - lo);
        mg.w = null;
        sim.step(at('for (k = 0; k < hi - lo'), L('Copy tmp back into a[' + lo + '..' + (hi - 1) + '] (all ' + (hi - lo) + ' writes shown at once). This range of main\'s array is now sorted.', 'คัดลอก tmp กลับลง a[' + lo + '..' + (hi - 1) + '] (แสดงการเขียนทั้ง ' + (hi - lo) + ' ครั้งรวมกัน) ช่วงนี้ของอาเรย์ใน main เรียงแล้ว'));
        sim.free(T);
        mg = null;
        sim.step(at('delete[] tmp'), L('<code>delete[] tmp</code> gives the block back. Without it every merge would leak; with it, at most one tmp per stack level is alive at once.', '<code>delete[] tmp</code> คืนบล็อก ถ้าไม่มีบรรทัดนี้ ทุกการรวมจะรั่ว แต่เมื่อมีแล้ว จะมี tmp อยู่พร้อมกันไม่เกินหนึ่งตัวต่อชั้นของ stack'));
        tree[id].done = true; tree[id].onStack = false; tree[id].sub = '';
        sim.ret(undefined, { show: false }); depth--; cur = prevCur; setCls();
      };
      ms(0, n, null, at('mergeSort(a, 0,'));
      cur = null; setCls();
      for (let k = 0; k < n; k++) sim.print(sim.r(A + 4 * k) + ' ');
      sim.step(at('for (int i = 0; i < ' + n), L('Sorted. The stack was at most ' + maxDepth + ' mergeSort frames deep (about log₂ n + 1), and each level of the tree did O(n) merge work: O(n log n) in total.', 'เรียงเสร็จ stack ลึกสุด ' + maxDepth + ' เฟรมของ mergeSort (ราว log₂ n + 1) และแต่ละชั้นของต้นไม้ใช้งานรวม O(n) รวมทั้งหมด O(n log n)'));
      sim.ret(0, { show: false });
    }
  });
})();
