/* Home / overview page */
function showHome() {
  const card = s => '<a class="card" href="#' + s.id + '"><span class="k">' + (s.lesson ? tr(T.lesson) + ' ' + esc(s.lesson) : '') + '</span><span class="t">' + tr(s.title) + '</span><span class="s">' + tr(s.blurb || s.summary) + '</span></a>';
  const parts = PARTS.map(p => '<section><h2>' + (LANG === 'th' ? 'ภาค ' : 'Part ') + ['', 'I', 'II', 'III'][p.id] + ' · ' + tr(p.title) + '</h2><div class="cards">' + SCEN.filter(s => s.part === p.id).map(card).join('') + '</div></section>').join('');
  const li = (sw, t, d) => '<div class="legend-item"><span class="sw-x">' + sw + '</span><div><b>' + tr(t) + '</b><br><span style="color:var(--muted)">' + tr(d) + '</span></div></div>';
  const first = SCEN[0] ? SCEN[0].id : 'home';
  $('#main').innerHTML = '<div class="home">' +
    '<section><h1>' + tr(L('Watch C++ run, one memory box at a time', 'ดู C++ ทำงานทีละกล่องหน่วยความจำ')) + '</h1>' +
    '<p class="lede">' + tr(L(
      'Every scenario is a short program from your DSA course. Press ▶ and the lab executes it line by line. You see each variable as a box with a real address, every pointer as an arrow, and every value that changes. The stack is on one side, the heap on the other, and a friendlier picture (tree, ring, list, graph, table) sits above them.',
      'แต่ละบทคือโปรแกรมสั้น ๆ จากคอร์ส DSA ของคุณ กด ▶ แล้วแล็บจะรันทีละบรรทัด คุณจะเห็นตัวแปรทุกตัวเป็นกล่องที่มีแอดเดรสจริง พอยน์เตอร์ทุกตัวเป็นลูกศร และค่าที่เปลี่ยนจะกะพริบให้เห็น ฝั่งหนึ่งคือ stack อีกฝั่งคือ heap และด้านบนมีภาพแนวคิดที่อ่านง่ายกว่า (ต้นไม้ วงแหวน ลิสต์ กราฟ ตาราง)')) + '</p>' +
    '<p style="margin-top:14px"><a class="btn primary" style="text-decoration:none;display:inline-block" href="#' + first + '">' + tr(L('Start with lesson 1 →', 'เริ่มบทแรก →')) + '</a></p></section>' +

    '<section><h2>' + tr(L('How to read the lab', 'วิธีอ่านหน้าจอแล็บ')) + '</h2><div class="legend-grid">' +
    li('<span class="v">10</span>', L('A box = some bytes of memory', 'กล่อง = ไบต์จำนวนหนึ่งในหน่วยความจำ'), L('The small grey number next to it (like 0xEFFC) is its address: the house number of its first byte.', 'ตัวเลขสีเทาเล็ก ๆ ข้างกล่อง (เช่น 0xEFFC) คือแอดเดรส หรือ "บ้านเลขที่" ของไบต์แรก')) +
    li('<span class="v ptr">0x1000</span>', L('A pointer', 'พอยน์เตอร์'), L('Its value is just an address. The lab draws an arrow from it to the box living at that address.', 'ค่าของมันคือแอดเดรสเท่านั้น แล็บจะวาดลูกศรจากมันไปยังกล่องที่อยู่ที่แอดเดรสนั้น')) +
    li('<span class="v garb">?</span>', L('Garbage', 'ค่าขยะ'), L('Declared but never given a value. In real C++ it holds leftover bits, not zero.', 'ประกาศแล้วแต่ยังไม่กำหนดค่า ใน C++ จริงมันคือบิตเก่าที่ค้างอยู่ ไม่ใช่ 0')) +
    li('<span class="v" style="background:var(--chg)">7</span>', L('Yellow flash = written', 'กะพริบเหลือง = ถูกเขียน'), L('This box changed in the step you just took.', 'กล่องนี้เปลี่ยนค่าในขั้นที่เพิ่งกดไป')) +
    li('<span class="v" style="outline:2px solid var(--read)">7</span>', L('Violet outline = read', 'ขอบม่วง = ถูกอ่าน'), L('The program looked at this box in this step.', 'โปรแกรมอ่านค่ากล่องนี้ในขั้นนี้')) +
    li('<span class="v ptr dang">0x2040</span>', L('Dangling pointer', 'พอยน์เตอร์ห้อยต่องแต่ง'), L('It still holds an address, but nothing valid lives there anymore. Using it is a bug.', 'มันยังเก็บแอดเดรสอยู่ แต่ที่นั่นไม่มีข้อมูลที่ใช้ได้แล้ว ถ้าใช้คือบั๊ก')) +
    '</div></section>' +

    '<section class="twocol"><div><h2>' + tr(L('Memory in one minute', 'หน่วยความจำใน 1 นาที')) + '</h2>' +
    '<p>' + tr(L('Memory is one long street of numbered byte-sized boxes. A variable occupies a few consecutive boxes; its address is the number of the first one. The type tells the compiler how many boxes to use and how to read the bits.',
      'หน่วยความจำคือถนนยาวที่มีกล่องขนาด 1 ไบต์เรียงกัน แต่ละกล่องมีเลขที่ ตัวแปรหนึ่งตัวใช้หลายกล่องติดกัน แอดเดรสของมันคือเลขของกล่องแรก ชนิดข้อมูล (type) บอกคอมไพเลอร์ว่าใช้กี่กล่องและตีความบิตอย่างไร')) + '</p>' +
    '<table class="ref"><tr><th>type</th><th>' + tr(L('bytes', 'ไบต์')) + '</th><th>' + tr(L('example', 'ตัวอย่าง')) + '</th></tr>' +
    [['char / bool', 1, "'A', true"], ['int', 4, '-2147483648 … 2147483647'], ['long long', 8, '≈ ±9.2·10¹⁸'], ['double', 8, '3.14'], ['T* (any pointer)', 8, '0x1000'], ['size_t', 8, '0 … 1.8·10¹⁹']].map(r => '<tr><td class="mono">' + r[0] + '</td><td class="num">' + r[1] + '</td><td class="num">' + r[2] + '</td></tr>').join('') + '</table></div>' +
    '<div><h2>' + tr(L('Stack vs heap', 'Stack กับ Heap')) + '</h2>' +
    '<table class="ref"><tr><th></th><th style="color:var(--stack)">Stack</th><th style="color:var(--heap)">Heap</th></tr>' +
    [[L('What lives there', 'อะไรอยู่ที่นั่น'), L('local variables, parameters', 'ตัวแปรภายใน พารามิเตอร์'), L('anything made by new', 'ทุกอย่างที่สร้างด้วย new')],
    [L('Created', 'ถูกสร้างเมื่อ'), L('when the function is called', 'ตอนเรียกฟังก์ชัน'), L('when new runs', 'ตอน new ทำงาน')],
    [L('Destroyed', 'ถูกทำลายเมื่อ'), L('automatically, when the function returns', 'อัตโนมัติ ตอนฟังก์ชัน return'), L('only when you delete it', 'เมื่อคุณสั่ง delete เท่านั้น')],
    [L('Size', 'ขนาด'), L('small (often 1–8 MB)', 'เล็ก (ปกติ 1–8 MB)'), L('large (most of RAM)', 'ใหญ่ (เกือบทั้ง RAM)')],
    [L('In this lab', 'ในแล็บนี้'), L('blue frames, left', 'เฟรมสีน้ำเงิน ด้านซ้าย'), L('amber blocks, right', 'บล็อกสีอำพัน ด้านขวา')]].map(r => '<tr><td><b>' + tr(r[0]) + '</b></td><td>' + tr(r[1]) + '</td><td>' + tr(r[2]) + '</td></tr>').join('') + '</table>' +
    '<p style="font-size:14px;color:var(--muted)">' + tr(L('Every container in Part II is a small object on the stack (a few fields such as mData, mSize, mCap) that points to its real data on the heap. Once that picture clicks, vector, queue, list, heap and map all look the same from far away.',
      'คอนเทนเนอร์ทุกตัวในภาค II คืออ็อบเจกต์เล็ก ๆ บน stack (มีฟิลด์ไม่กี่ตัว เช่น mData, mSize, mCap) ที่ชี้ไปยังข้อมูลจริงบน heap ถ้าเข้าใจภาพนี้แล้ว vector, queue, list, heap และ map จะดูคล้ายกันหมดเมื่อมองจากไกล ๆ')) + '</p></div></section>' +

    '<section><h2>' + tr(L('How to study with it', 'วิธีเรียนกับแล็บนี้')) + '</h2><ol style="max-width:75ch;padding-left:22px;display:grid;gap:4px">' +
    '<li>' + tr(L('Read the code first and guess what memory will look like after each line.', 'อ่านโค้ดก่อน แล้วเดาว่าหน่วยความจำจะเป็นอย่างไรหลังแต่ละบรรทัด')) + '</li>' +
    '<li>' + tr(L('Step with → (not Play). Before each step, say out loud which box will change.', 'กด → ทีละขั้น (อย่าเพิ่งกด Play) ก่อนกดแต่ละครั้ง พูดออกมาว่ากล่องไหนจะเปลี่ยน')) + '</li>' +
    '<li>' + tr(L('Hover a pointer to highlight its arrow. Turn arrows off if a picture gets busy.', 'ชี้เมาส์ที่พอยน์เตอร์เพื่อเน้นลูกศรของมัน ถ้าภาพรกไปให้ปิดลูกศร')) + '</li>' +
    '<li>' + tr(L('In Parts II and III, type your own input and press Run. Try the edge cases: empty, one element, wrap-around, duplicates.', 'ในภาค II และ III ใส่ข้อมูลของคุณเองแล้วกด Run ลองกรณีขอบ: ว่าง มีตัวเดียว วนรอบ ค่าซ้ำ')) + '</li>' +
    '<li>' + tr(L('Then redraw the final memory on paper without looking. That is the skill the grader exams test.', 'จากนั้นวาดหน่วยความจำสุดท้ายลงกระดาษโดยไม่ดู นี่คือทักษะที่ข้อสอบ grader วัด')) + '</li></ol></section>' +

    parts +

    '<section><div class="callout"><b>' + tr(L('What is simplified (so you are never misled)', 'อะไรถูกทำให้ง่ายลงบ้าง (เพื่อไม่ให้เข้าใจผิด)')) + '</b><ul style="margin:6px 0 0;padding-left:20px;display:grid;gap:3px">' +
    '<li>' + tr(L('Addresses are shortened to 4 hex digits. Real ones look like 0x7ffd5e3c1a2c (stack) and 0x55d4c2a1f2b0 (heap). The arithmetic between them is the same.', 'แอดเดรสถูกย่อเหลือเลขฐานสิบหก 4 หลัก ของจริงจะยาวเช่น 0x7ffd5e3c1a2c (stack) และ 0x55d4c2a1f2b0 (heap) แต่การคำนวณระหว่างแอดเดรสเหมือนกันทุกอย่าง')) + '</li>' +
    '<li>' + tr(L('The order of local variables inside a frame is up to the compiler. The lab packs them in declaration order, downward.', 'ลำดับตัวแปรภายในเฟรมขึ้นกับคอมไพเลอร์ แล็บวางเรียงตามลำดับที่ประกาศ จากบนลงล่าง')) + '</li>' +
    '<li>' + tr(L('Each heap block is followed by a 16-byte gap, standing in for the allocator\'s bookkeeping header. Real allocators also reuse freed space.', 'แต่ละบล็อกบน heap มีช่องว่าง 16 ไบต์คั่น แทน header ที่ตัวจัดสรรหน่วยความจำใช้จดบันทึก ของจริงจะนำพื้นที่ที่ถูกคืนกลับมาใช้ใหม่ด้วย')) + '</li>' +
    '<li>' + tr(L('Return addresses and saved registers are not drawn in stack frames.', 'ไม่ได้วาด return address และ register ที่ถูกเซฟไว้ในเฟรม')) + '</li>' +
    '<li>' + tr(L('Containers follow the CP:: code from your course. std::vector works the same way but stores three pointers (begin, end, end of capacity) instead of mData/mSize/mCap.', 'คอนเทนเนอร์ใช้โค้ด CP:: จากคอร์สของคุณ std::vector ทำงานแบบเดียวกันแต่เก็บพอยน์เตอร์ 3 ตัว (begin, end, ท้ายความจุ) แทน mData/mSize/mCap')) + '</li>' +
    '<li>' + tr(L('Globals (memo, vis, parent in Part III) really live in a separate static area. To keep the picture small they are drawn inside main\'s frame, and each scenario says so.', 'ตัวแปร global (memo, vis, parent ในภาค III) จริง ๆ อยู่ในพื้นที่ static แยกต่างหาก เพื่อให้ภาพเล็กลงจึงวาดไว้ในเฟรมของ main และแต่ละบทจะบอกไว้')) + '</li>' +
    '<li>' + tr(L('In Part III, std containers (adjacency lists, priority_queue) are shown in the concept view only; Part II shows what they look like in memory.', 'ในภาค III คอนเทนเนอร์ของ std (รายการประชิด, priority_queue) แสดงเฉพาะในภาพแนวคิด ภาค II แสดงแล้วว่าในหน่วยความจำมันหน้าตาอย่างไร')) + '</li>' +
    '</ul></div></section>' +
    '</div>';
}
