/* =====================================================================
   Memory Lab engine: a tiny simulated C++ memory.
   Scenarios drive a Sim object (call functions, declare locals, new/delete,
   read/write by address) and take snapshots with sim.step(line, note).
   The renderer only ever looks at snapshots.
   ===================================================================== */

// ---------- i18n ----------
const L = (en, th) => ({ en, th: th == null ? en : th });
let LANG = 'en';
const tr = x => (x && typeof x === 'object' && 'en' in x) ? (x[LANG] != null ? x[LANG] : x.en) : (x == null ? '' : String(x));

// ---------- values ----------
const P = a => ({ p: a });            // a pointer value holding address a (0 = nullptr)
const isP = v => v !== null && typeof v === 'object' && 'p' in v;
const CH = c => ({ ch: c });          // a char value
const isCH = v => v !== null && typeof v === 'object' && 'ch' in v;
const STR = s => ({ str: s });        // an opaque std::string value
const isSTR = v => v !== null && typeof v === 'object' && 'str' in v;

const BASE_SIZE = {
  char: 1, bool: 1, short: 2, int: 4, unsigned: 4, float: 4,
  long: 8, 'long long': 8, double: 8, size_t: 8, 'std::string': 32, string: 32
};
function sizeOf(type) {
  type = String(type).trim();
  if (/[*&]$/.test(type)) return 8;
  if (type in BASE_SIZE) return BASE_SIZE[type];
  const m = type.match(/^pair<(.+),(.+)>$/);
  if (m) return 8;               // only used for display of small pairs
  return 8;
}
const hex = a => '0x' + a.toString(16).toUpperCase().padStart(4, '0');

function clone(x) {
  if (x === undefined) return undefined;
  if (typeof structuredClone === 'function') return structuredClone(x);
  const fix = v => { if (Array.isArray(v)) return Array.from(v, fix); if (v && typeof v === 'object') { if (v.__U__) return undefined; const o = {}; for (const k in v) o[k] = fix(v[k]); return o; } return v; };
  return fix(JSON.parse(JSON.stringify(x, (k, v) => v === undefined ? { __U__: 1 } : v)));
}

// Lay out a list of [name, type, value] fields with natural alignment.
function layoutFields(fields, base) {
  let off = 0, maxAl = 1;
  const out = fields.map(([name, type, value]) => {
    const sz = sizeOf(type);
    const al = Math.min(sz, 8);
    maxAl = Math.max(maxAl, al);
    off = Math.ceil(off / al) * al;
    const f = { name, type, size: sz, off, addr: base + off, value };
    off += sz;
    return f;
  });
  const size = Math.ceil(off / maxAl) * maxAl;
  return { fields: out, size };
}
function structSize(fields) { return layoutFields(fields, 0).size; }

class Sim {
  constructor(opts = {}) {
    this.frames = [];
    this.ghosts = [];            // frames popped since the last snapshot (shown once, greyed)
    this.heap = [];
    this.globals = null;
    this.sp = opts.stackTop || 0xF000;
    this.hp = opts.heapBase || 0x1000;
    this.out = '';
    this.snaps = [];
    this.reads = new Set();
    this.viewFn = null;
    this.tagFn = null;
    this.seq = 0;
    this.limit = opts.limit || 1500;   // safety cap on number of steps
  }

  // ---------- frames ----------
  top() { return this.frames[this.frames.length - 1]; }
  call(sig, opts = {}) {
    const f = { id: ++this.seq, sig, vars: [], line: null, spStart: this.sp, ret: null, note: opts.note || null };
    this.frames.push(f);
    return f;
  }
  // pop the current frame; value is shown as a "returned" chip on the caller
  ret(value, opts = {}) {
    const f = this.frames.pop();
    this.sp = f.spStart;
    f.dead = true;
    this.ghosts.push(f);
    const caller = this.top();
    if (caller && opts.show !== false) caller.ret = { from: f.sig, value, type: opts.type || null };
    return value;
  }

  _alloc(size, align) {
    align = Math.min(align || size, 8) || 1;
    this.sp -= size;
    this.sp -= ((this.sp % align) + align) % align;
    return this.sp;
  }

  // scalar local (or parameter).  opts: {param:true, ref:true, note, cls}
  local(name, type, value, opts = {}) {
    const size = opts.ref ? 8 : sizeOf(type);
    const addr = this._alloc(size, size);
    const v = { kind: 'scalar', name, type, addr, size, value, param: !!opts.param, ref: !!opts.ref, cls: opts.cls || null, hidden: !!opts.hidden };
    this.top().vars.push(v);
    return addr;
  }
  param(name, type, value, opts = {}) { return this.local(name, type, value, Object.assign({ param: true }, opts)); }
  ref(name, type, target, opts = {}) { return this.local(name, type + '&', P(target), Object.assign({ ref: true }, opts)); }

  // remove a local from the current frame (end of its scope)
  drop(name) {
    const f = this.top();
    const v = f.vars.find(v => v.name === name);
    if (!v) return;
    f.vars = f.vars.filter(x => x !== v);
    if (v.addr === this.sp) this.sp += v.size;
    const lowest = f.vars.length ? Math.min(...f.vars.map(x => x.addr)) : f.spStart;
    this.sp = Math.min(lowest, f.spStart);
  }

  // local object with fields: fields = [[name, type, value], ...]
  obj(name, type, fields, opts = {}) {
    const size = structSize(fields);
    const addr = this._alloc(size, 8);
    const lay = layoutFields(fields, addr);
    const v = { kind: 'obj', name, type, addr, size, fields: lay.fields, param: !!opts.param, cls: opts.cls || null };
    this.top().vars.push(v);
    return addr;
  }

  // local C array
  arr(name, elemType, n, init, opts = {}) {
    const es = sizeOf(elemType);
    const addr = this._alloc(es * n, es);
    const cells = Array.from({ length: n }, (_, i) => Array.isArray(init) ? init[i] : init);
    this.top().vars.push({ kind: 'array', name, type: elemType + '[' + n + ']', elemType, es, n, addr, size: es * n, cells, param: !!opts.param });
    return addr;
  }

  // ---------- heap ----------
  _halloc(bytes) {
    const a = this.hp;
    this.hp += Math.ceil(Math.max(bytes, 1) / 16) * 16 + 16;   // 16-byte allocator header between blocks
    return a;
  }
  newArray(elemType, n, init, opts = {}) {
    const es = sizeOf(elemType);
    const addr = this._halloc(es * n);
    const cells = Array.from({ length: n }, (_, i) => Array.isArray(init) ? init[i] : (typeof init === 'function' ? init(i) : init));
    this.heap.push({ kind: 'array', addr, elemType, es, n, cells, size: es * n, label: opts.label || null, used: opts.used == null ? null : opts.used, born: true, expr: opts.expr || ('new ' + elemType + '[' + n + ']') });
    return addr;
  }
  newObj(type, fields, opts = {}) {
    const size = structSize(fields);
    const addr = this._halloc(size);
    const lay = layoutFields(fields, addr);
    this.heap.push({ kind: 'obj', addr, type, size, fields: lay.fields, label: opts.label || null, born: true, cls: opts.cls || null, expr: opts.expr || ('new ' + type) });
    return addr;
  }
  free(addr) {
    const b = this.heap.find(b => b.addr === addr && !b.freed);
    if (!b) throw new Error('free of unknown block ' + hex(addr));
    b.freed = true;
  }
  block(addr) { return this.heap.find(b => b.addr === addr && !b.freed); }
  setUsed(addr, n) { const b = this.block(addr); if (b) b.used = n; }
  setLabel(addr, label) { const b = this.block(addr); if (b) b.label = label; }

  // ---------- memory access by address ----------
  locate(addr) {
    for (const f of this.frames) {
      for (const v of f.vars) {
        if (v.kind === 'scalar' && v.addr === addr) return { o: v, k: 'value' };
        if (v.kind === 'obj') for (const fd of v.fields) if (fd.addr === addr) return { o: fd, k: 'value' };
        if (v.kind === 'array' && addr >= v.addr && addr < v.addr + v.size && (addr - v.addr) % v.es === 0) return { o: v.cells, k: (addr - v.addr) / v.es };
      }
    }
    for (const b of this.heap) {
      if (b.freed) continue;
      if (b.kind === 'array' && addr >= b.addr && addr < b.addr + b.size && (addr - b.addr) % b.es === 0) return { o: b.cells, k: (addr - b.addr) / b.es };
      if (b.kind === 'obj') for (const fd of b.fields) if (fd.addr === addr) return { o: fd, k: 'value' };
    }
    return null;
  }
  r(addr) {
    const c = this.locate(addr);
    if (!c) throw new Error('read of invalid address ' + hex(addr));
    this.reads.add(addr);
    return c.o[c.k];
  }
  peek(addr) { const c = this.locate(addr); if (!c) throw new Error('peek of invalid address ' + hex(addr)); return c.o[c.k]; }
  w(addr, value) {
    const c = this.locate(addr);
    if (!c) throw new Error('write to invalid address ' + hex(addr));
    c.o[c.k] = value;
    return value;
  }
  // field address of an object at base (stack or heap)
  f(base, field) {
    for (const fr of this.frames) for (const v of fr.vars) if (v.kind === 'obj' && v.addr === base) { const fd = v.fields.find(x => x.name === field); if (fd) return fd.addr; }
    for (const b of this.heap) if (b.kind === 'obj' && b.addr === base && !b.freed) { const fd = b.fields.find(x => x.name === field); if (fd) return fd.addr; }
    throw new Error('no field ' + field + ' at ' + hex(base));
  }
  // read/write a field
  rf(base, field) { return this.r(this.f(base, field)); }
  pf(base, field) { return this.peek(this.f(base, field)); }
  wf(base, field, value) { return this.w(this.f(base, field), value); }
  // address of element i of an array that starts at base
  at(base, i, es = 4) { return base + i * es; }

  print(s) { this.out += s; }

  _safe(fn, key, dflt) {
    if (!fn) return dflt;
    try { const r = fn(this); return r == null ? dflt : clone(r); }
    catch (e) { const last = this.snaps[this.snaps.length - 1]; return last ? last[key] : dflt; }
  }
  // ---------- snapshot ----------
  step(line, note, opts = {}) {
    if (this.snaps.length >= this.limit) throw new Error('STEP_LIMIT');
    if (line != null && this.frames.length) this.top().line = line;
    const s = {
      frames: clone(this.frames),
      ghosts: clone(this.ghosts),
      heap: clone(this.heap),
      out: this.out,
      note,
      reads: [...this.reads],
      view: this._safe(this.viewFn, 'view', null),
      tags: this._safe(this.tagFn, 'tags', []),
      line: line,
      lines: opts.lines || null,   // extra lines to highlight
      cls: opts.cls || null,       // e.g. 'warn' for a bad step
      label: opts.label || null
    };
    this.snaps.push(s);
    this.reads.clear();
    this.ghosts = [];
    this.heap = this.heap.filter(b => !b.freed);
    for (const b of this.heap) b.born = false;
    for (const f of this.frames) f.ret = null;
    return s;
  }
}

// ---------- scenario registry ----------
const SCEN = [];
function def(s) { SCEN.push(s); }
const PARTS = [
  { id: 1, title: L('C++ in memory', 'C++ ในหน่วยความจำ'), sub: L('Variables, pointers, functions, classes', 'ตัวแปร พอยน์เตอร์ ฟังก์ชัน คลาส') },
  { id: 2, title: L('Containers inside', 'ข้างในคอนเทนเนอร์'), sub: L('vector, stack, queue, list, heap, BST, hash', 'vector, stack, queue, list, heap, BST, hash') },
  { id: 3, title: L('Algorithms step by step', 'อัลกอริทึมทีละขั้น'), sub: L('Searching, sorting, recursion, DP, graphs', 'ค้นหา เรียง เรียกซ้ำ DP กราฟ') }
];

// parse "1, 2, 3" or "1 2 3" into numbers
function parseNums(s, max = 40) {
  return String(s).split(/[\s,]+/).filter(x => x !== '').slice(0, max).map(Number).filter(x => Number.isFinite(x)).map(x => Math.trunc(x));
}
// parse ops like "push 3, pop, push 5" → [['push',3],['pop']]
function parseOps(s, max = 30) {
  return String(s).split(/[,;\n]+/).map(x => x.trim()).filter(Boolean).slice(0, max).map(x => {
    const parts = x.split(/[\s()]+/).filter(Boolean);
    return [parts[0].toLowerCase(), ...parts.slice(1).map(t => (/^-?\d+$/.test(t) ? Number(t) : t))];
  });
}
