/* =====================================================================
   Concept views: friendlier pictures of the same state (tree, ring,
   chain, graph, table, ...). Each takes a plain data object and returns
   an HTML/SVG string.
   ===================================================================== */

const VCLS = {
  hl:  { f: 'var(--acc-tint)', s: 'var(--acc)' },
  cmp: { f: 'color-mix(in srgb, var(--read) 16%, var(--panel))', s: 'var(--read)' },
  chg: { f: 'color-mix(in srgb, var(--chg) 75%, var(--panel))', s: 'var(--heap)' },
  ok:  { f: 'color-mix(in srgb, var(--new) 18%, var(--panel))', s: 'var(--new)' },
  bad: { f: 'color-mix(in srgb, var(--bad) 15%, var(--panel))', s: 'var(--bad)' },
  dim: { f: 'var(--panel-2)', s: 'var(--line)' },
  st:  { f: 'var(--stack-tint)', s: 'var(--stack)' },
  hp:  { f: 'var(--heap-tint)', s: 'var(--heap)' },
  hdr: { f: 'var(--panel-2)', s: 'var(--muted)' },
  '':  { f: 'var(--panel)', s: 'var(--muted)' }
};
const vc = c => VCLS[c || ''] || VCLS[''];
const sesc = s => esc(tr(s));

const VIEWS = {};

// ---------- several views stacked ----------
VIEWS.multi = d => d.parts.map(p => (p.cap ? '<div class="cap">' + tr(p.cap) + '</div>' : '') + VIEWS[p.kind](p)).join('<div style="height:12px"></div>');

// ---------- raw html ----------
VIEWS.html = d => tr(d.html);

// ---------- bytes of variables ----------
VIEWS.bytes = d => {
  let h = '<div style="display:grid;gap:10px">';
  for (const v of d.vars) {
    h += '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><div style="min-width:120px;font-family:var(--font-mono);font-size:13px"><b>' + esc(v.name) + '</b> <span style="color:var(--muted)">' + esc(v.type) + '</span><br><span style="color:var(--muted);font-size:11.5px">= ' + esc(v.show) + '</span></div><div style="display:flex">';
    v.bytes.forEach((b, i) => {
      const c = vc(v.cls && v.cls[i]);
      h += '<div style="display:grid;justify-items:center"><div style="font-family:var(--font-mono);font-size:10px;color:var(--muted)">+' + i + '</div><div style="width:38px;height:32px;display:grid;place-items:center;border:1.5px solid ' + c.s + ';background:' + c.f + ';margin-left:-1.5px;font-family:var(--font-mono);font-size:13px">' + b + '</div><div style="font-family:var(--font-mono);font-size:9.5px;color:var(--muted)">' + hex(v.addr + i) + '</div></div>';
    });
    h += '</div>' + (v.extra ? '<div style="font-size:12.5px;color:var(--muted);max-width:40ch">' + tr(v.extra) + '</div>' : '') + '</div>';
  }
  return h + '</div>';
};

// ---------- arrays with index markers ----------
// d.rows = [{label, cells:[v], cls:[c], marks:{i:[label]}, idx:true, ranges:[{a,b,label,cls}] }]
VIEWS.array = d => {
  let h = '<div style="display:grid;gap:14px">';
  for (const r of d.rows) {
    const n = r.cells.length, W = r.w || 46, H = 34, top = 22, x0 = r.label ? 96 : 6;
    const ranges = r.ranges || [];
    const height = top + H + 18 + (ranges.length ? 22 * ranges.length : 0) + 4;
    const width = x0 + n * W + 10 + (r.marks && r.marks[n] ? 24 + 8 * r.marks[n].join(',').length : 0);
    let s = '<svg width="' + width + '" height="' + height + '" viewBox="0 0 ' + width + ' ' + height + '">';
    if (r.label) s += '<text x="0" y="' + (top + H / 2 + 4) + '" font-size="12.5" style="fill:var(--muted)">' + sesc(r.label) + '</text>';
    r.cells.forEach((v, i) => {
      const c = vc(r.cls && r.cls[i]);
      const x = x0 + i * W;
      s += '<rect x="' + x + '" y="' + top + '" width="' + W + '" height="' + H + '" rx="3" style="fill:' + c.f + ';stroke:' + c.s + ';stroke-width:1.5"/>';
      s += '<text x="' + (x + W / 2) + '" y="' + (top + H / 2 + 5) + '" text-anchor="middle" font-size="' + (String(v).length > 5 ? 10.5 : 13.5) + '">' + esc(v === undefined || v === null ? '' : String(v)) + '</text>';
      if (r.idx !== false) s += '<text x="' + (x + W / 2) + '" y="' + (top + H + 13) + '" text-anchor="middle" font-size="10" style="fill:var(--muted)">' + (r.idx0 != null ? r.idx0 + i : i) + '</text>';
      const mk = r.marks && r.marks[i];
      if (mk && mk.length) s += '<text x="' + (x + W / 2) + '" y="' + (top - 7) + '" text-anchor="middle" font-size="11.5" font-weight="700" style="fill:var(--ptr)">' + esc(mk.join(',')) + ' ▾</text>';
    });
    if (r.marks && r.marks[n] && r.marks[n].length) s += '<text x="' + (x0 + n * W + 4) + '" y="' + (top - 7) + '" font-size="11.5" font-weight="700" style="fill:var(--ptr)">' + esc(r.marks[n].join(',')) + ' ▾</text>';
    ranges.forEach((g, k) => {
      const y = top + H + 20 + k * 22, xa = x0 + g.a * W + 3, xb = x0 + (g.b + 1) * W - 3;
      const c = vc(g.cls || 'hl');
      if (g.b >= g.a) {
        s += '<path d="M' + xa + ',' + (y - 6) + ' L' + xa + ',' + y + ' L' + xb + ',' + y + ' L' + xb + ',' + (y - 6) + '" style="fill:none;stroke:' + c.s + ';stroke-width:1.8"/>';
        s += '<text x="' + ((xa + xb) / 2) + '" y="' + (y + 13) + '" text-anchor="middle" font-size="11" style="fill:' + c.s + '">' + sesc(g.label || '') + '</text>';
      }
    });
    s += '</svg>';
    h += s;
  }
  return h + '</div>';
};

// ---------- circular buffer (queue) ----------
// d = {cap, front, size, cells:[...]}
VIEWS.ring = d => {
  const n = d.n, R = Math.max(92, n * 15), r0 = R - 30, cx = R + 70, cy = R + 44, W = (R + 70) * 2, H = (R + 44) * 2;
  let s = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '">';
  const used = i => ((i - d.front + n) % n) < d.size;
  const P2 = (r, a) => (cx + r * Math.cos(a)).toFixed(1) + ',' + (cy + r * Math.sin(a)).toFixed(1);
  const nextSlot = d.size < n ? (d.front + d.size) % n : -1;
  for (let i = 0; i < n; i++) {
    const a0 = -Math.PI / 2 + (i - 0.5) * 2 * Math.PI / n, a1 = a0 + 2 * Math.PI / n, am = (a0 + a1) / 2;
    const u = used(i);
    const c = vc(u ? (d.cls && d.cls[i]) || 'hp' : 'dim');
    const isF = i === d.front && d.size > 0;
    s += '<path d="M' + P2(r0, a0) + ' L' + P2(R, a0) + ' A' + R + ',' + R + ' 0 0 1 ' + P2(R, a1) + ' L' + P2(r0, a1) + ' A' + r0 + ',' + r0 + ' 0 0 0 ' + P2(r0, a0) + 'Z" style="fill:' + c.f + ';stroke:' + (isF ? 'var(--ptr)' : c.s) + ';stroke-width:' + (isF ? 3 : 1.5) + '"/>';
    const rm = (r0 + R) / 2;
    s += '<text x="' + (cx + rm * Math.cos(am)).toFixed(1) + '" y="' + (cy + rm * Math.sin(am) + 5).toFixed(1) + '" text-anchor="middle" font-size="14" style="' + (u ? 'font-weight:700' : 'fill:var(--muted)') + '">' + esc(u ? String(d.cells[i]) : '·') + '</text>';
    s += '<text x="' + (cx + (r0 - 12) * Math.cos(am)).toFixed(1) + '" y="' + (cy + (r0 - 12) * Math.sin(am) + 4).toFixed(1) + '" text-anchor="middle" font-size="10" style="fill:var(--muted)">' + i + '</text>';
    const lab = [];
    if (isF) lab.push(['front', 'var(--ptr)']);
    if (u && i === (d.front + d.size - 1) % n) lab.push(['back', 'var(--acc)']);
    if (i === nextSlot) lab.push(['next push', 'var(--muted)']);
    lab.forEach((l, k) => {
      const rr = R + 16 + k * 14;
      s += '<text x="' + (cx + rr * Math.cos(am)).toFixed(1) + '" y="' + (cy + rr * Math.sin(am) + 4).toFixed(1) + '" text-anchor="middle" font-size="11.5" font-weight="700" style="fill:' + l[1] + '">' + l[0] + '</text>';
    });
  }
  s += '<text x="' + cx + '" y="' + (cy - 3) + '" text-anchor="middle" font-size="11.5" style="fill:var(--muted)">mFront=' + d.front + '</text>';
  s += '<text x="' + cx + '" y="' + (cy + 12) + '" text-anchor="middle" font-size="11.5" style="fill:var(--muted)">mSize=' + d.size + '</text>';
  return s + '</svg>';
};

// ---------- linked nodes (list) ----------
// d = {nodes:[{addr, label, sub, slot, row, cls}], links:[{from, to, kind:'next'|'prev', cls}]}
VIEWS.chain = d => {
  const BW = 74, BH = 46, GX = 112, top = 46, RH = 112;
  const rows = Math.max(...d.nodes.map(n => n.row || 0), 0) + 1;
  const slots = Math.max(...d.nodes.map(n => n.slot), 0) + 1;
  const W = 30 + slots * GX + 40, H = top + rows * RH + 30;
  const pos = new Map();
  d.nodes.forEach(n => pos.set(n.addr, { x: 20 + n.slot * GX, y: top + (n.row || 0) * RH }));
  let s = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '"><defs>' +
    '<marker id="cn" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0L10,5L0,10z" style="fill:var(--ptr)"/></marker>' +
    '<marker id="cp" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0L10,5L0,10z" style="fill:var(--stack)"/></marker>' +
    '<marker id="cx" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0L10,5L0,10z" style="fill:var(--heap)"/></marker></defs>';
  for (const l of d.links) {
    const a = pos.get(l.from), b = pos.get(l.to);
    if (!a || !b) continue;
    const next = l.kind === 'next';
    const col = l.cls === 'chg' ? 'var(--heap)' : (next ? 'var(--ptr)' : 'var(--stack)');
    const mk = l.cls === 'chg' ? 'cx' : (next ? 'cn' : 'cp');
    const sw = l.cls === 'chg' ? 3 : 1.7;
    let p;
    if (a === b) { // self loop
      const x = a.x + BW / 2, y = next ? a.y : a.y + BH;
      p = next ? 'M' + (x + 10) + ',' + y + ' C' + (x + 40) + ',' + (y - 40) + ' ' + (x - 40) + ',' + (y - 40) + ' ' + (x - 10) + ',' + y
        : 'M' + (x - 10) + ',' + y + ' C' + (x - 40) + ',' + (y + 40) + ' ' + (x + 40) + ',' + (y + 40) + ' ' + (x + 10) + ',' + y;
    } else {
      const dist = Math.abs(b.x - a.x) / GX;
      const lift = (dist <= 1 && a.y === b.y) ? 14 : 22 + dist * 10;
      if (next) {
        const x1 = a.x + BW * 0.7, y1 = a.y, x2 = b.x + BW * 0.3, y2 = b.y;
        p = 'M' + x1 + ',' + y1 + ' C' + x1 + ',' + (Math.min(y1, y2) - lift) + ' ' + x2 + ',' + (Math.min(y1, y2) - lift) + ' ' + x2 + ',' + y2;
      } else {
        const x1 = a.x + BW * 0.3, y1 = a.y + BH, x2 = b.x + BW * 0.7, y2 = b.y + BH;
        p = 'M' + x1 + ',' + y1 + ' C' + x1 + ',' + (Math.max(y1, y2) + lift) + ' ' + x2 + ',' + (Math.max(y1, y2) + lift) + ' ' + x2 + ',' + y2;
      }
    }
    s += '<path d="' + p + '" style="fill:none;stroke:' + col + ';stroke-width:' + sw + '" marker-end="url(#' + mk + ')"/>';
  }
  for (const n of d.nodes) {
    const q = pos.get(n.addr), c = vc(n.cls || (n.header ? 'hdr' : 'hp'));
    s += '<rect x="' + q.x + '" y="' + q.y + '" width="' + BW + '" height="' + BH + '" rx="7" style="fill:' + c.f + ';stroke:' + c.s + ';stroke-width:1.6' + (n.header ? ';stroke-dasharray:4 3' : '') + '"/>';
    s += '<text x="' + (q.x + BW / 2) + '" y="' + (q.y + 20) + '" text-anchor="middle" font-size="14" font-weight="700">' + esc(n.label) + '</text>';
    s += '<text x="' + (q.x + BW / 2) + '" y="' + (q.y + 36) + '" text-anchor="middle" font-size="10" style="fill:var(--muted)">' + esc(n.sub || '') + '</text>';
    if (n.tag) s += '<text x="' + (q.x + BW / 2) + '" y="' + (q.y - 6 - (n.row ? 0 : 0)) + '" text-anchor="middle" font-size="11" font-weight="700" style="fill:var(--acc)">' + esc(n.tag) + '</text>';
  }
  s += '<g font-size="10.5"><line x1="' + (W - 150) + '" y1="' + (H - 10) + '" x2="' + (W - 128) + '" y2="' + (H - 10) + '" style="stroke:var(--ptr);stroke-width:2"/><text x="' + (W - 124) + '" y="' + (H - 6) + '" style="fill:var(--muted)">next</text>' +
    '<line x1="' + (W - 86) + '" y1="' + (H - 10) + '" x2="' + (W - 64) + '" y2="' + (H - 10) + '" style="stroke:var(--stack);stroke-width:2"/><text x="' + (W - 60) + '" y="' + (H - 6) + '" style="fill:var(--muted)">prev</text></g>';
  return s + '</svg>';
};

// ---------- trees ----------
// d = {nodes:{id:{label, sub, cls, kids:[id|null,...]}}, root, binary:true, edgeLabels}
VIEWS.tree = d => {
  if (d.root == null || !d.nodes[d.root]) return '<div class="cap">' + tr(d.empty || L('(empty tree)', '(ต้นไม้ว่าง)')) + '</div>';
  const R = d.r || 21, GX = d.gx || (R * 2 + 12), GY = d.gy || 64;
  const pos = {};
  let next = 0, maxDepth = 0;
  const place = (id, depth) => {
    const nd = d.nodes[id];
    maxDepth = Math.max(maxDepth, depth);
    const kids = nd.kids || [];
    if (d.binary) {
      const [l, r] = kids;
      if (l != null) place(l, depth + 1); else if (r != null) next += 0.5;
      pos[id] = { x: next++, y: depth };
      if (r != null) place(r, depth + 1); else if (l != null) next += 0.5;
    } else {
      const real = kids.filter(k => k != null);
      if (!real.length) pos[id] = { x: next++, y: depth };
      else { real.forEach(k => place(k, depth + 1)); pos[id] = { x: (pos[real[0]].x + pos[real[real.length - 1]].x) / 2, y: depth }; }
    }
  };
  place(d.root, 0);
  const W = next * GX + 30, H = (maxDepth + 1) * GY + 20;
  const X = id => 15 + pos[id].x * GX + GX / 2, Y = id => 10 + pos[id].y * GY + R + 4;
  let s = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '">';
  for (const id in pos) for (const k of (d.nodes[id].kids || [])) if (k != null && pos[k]) {
    const ec = d.nodes[k].edge;
    s += '<line x1="' + X(id) + '" y1="' + Y(id) + '" x2="' + X(k) + '" y2="' + Y(k) + '" style="stroke:' + (ec ? vc(ec).s : 'var(--muted)') + ';stroke-width:' + (ec ? 2.6 : 1.4) + '"/>';
  }
  for (const id in pos) {
    const nd = d.nodes[id], c = vc(nd.cls);
    const w = Math.max(R * 2, String(nd.label).length * 8 + 14);
    s += '<rect x="' + (X(id) - w / 2) + '" y="' + (Y(id) - R) + '" width="' + w + '" height="' + (R * 2) + '" rx="' + (d.square ? 6 : R) + '" style="fill:' + c.f + ';stroke:' + c.s + ';stroke-width:' + (nd.cls ? 2.2 : 1.5) + '"/>';
    s += '<text x="' + X(id) + '" y="' + (Y(id) + 5) + '" text-anchor="middle" font-size="' + (String(nd.label).length > 6 ? 11 : 13.5) + '" font-weight="600">' + esc(nd.label) + '</text>';
    if (nd.sub != null) s += '<text x="' + X(id) + '" y="' + (Y(id) + R + 12) + '" text-anchor="middle" font-size="10" style="fill:var(--muted)">' + esc(nd.sub) + '</text>';
    if (nd.tag) s += '<text x="' + (X(id) + w / 2 + 4) + '" y="' + (Y(id) - R + 6) + '" font-size="11" font-weight="700" style="fill:var(--ptr)">' + esc(nd.tag) + '</text>';
  }
  return s + '</svg>';
};

// ---------- graphs ----------
// d = {nodes:[{id,label,x,y,cls,sub}], edges:[{a,b,w,cls,dir}], w, h}
VIEWS.graph = d => {
  const W = d.w || 460, H = d.h || 260, R = 19;
  const P = {}; d.nodes.forEach(n => P[n.id] = { x: 30 + n.x * (W - 60), y: 26 + n.y * (H - 66) });
  let s = '<svg width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '"><defs><marker id="ge" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0L10,5L0,10z" style="fill:var(--muted)"/></marker></defs>';
  for (const e of d.edges) {
    const a = P[e.a], b = P[e.b], c = e.cls ? vc(e.cls).s : 'var(--line)';
    const dx = b.x - a.x, dy = b.y - a.y, L0 = Math.hypot(dx, dy) || 1;
    const x2 = b.x - dx / L0 * (R + 2), y2 = b.y - dy / L0 * (R + 2);
    s += '<line x1="' + a.x + '" y1="' + a.y + '" x2="' + (e.dir ? x2 : b.x) + '" y2="' + (e.dir ? y2 : b.y) + '" style="stroke:' + c + ';stroke-width:' + (e.cls ? 3.2 : 1.6) + '"' + (e.dir ? ' marker-end="url(#ge)"' : '') + '/>';
    if (e.w != null) { const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2; s += '<rect x="' + (mx - 11) + '" y="' + (my - 9) + '" width="22" height="16" rx="4" style="fill:var(--panel);stroke:var(--line)"/><text x="' + mx + '" y="' + (my + 3) + '" text-anchor="middle" font-size="10.5">' + e.w + '</text>'; }
  }
  for (const n of d.nodes) {
    const c = vc(n.cls), q = P[n.id];
    s += '<circle cx="' + q.x + '" cy="' + q.y + '" r="' + R + '" style="fill:' + c.f + ';stroke:' + c.s + ';stroke-width:' + (n.cls ? 2.4 : 1.5) + '"/>';
    s += '<text x="' + q.x + '" y="' + (q.y + 5) + '" text-anchor="middle" font-size="13.5" font-weight="700">' + esc(n.label) + '</text>';
    if (n.sub != null) s += '<text x="' + q.x + '" y="' + (q.y + R + 13) + '" text-anchor="middle" font-size="10.5" style="fill:var(--ptr);font-weight:700">' + esc(n.sub) + '</text>';
  }
  return s + '</svg>';
};

// ---------- 2-D tables (DP) ----------
// d = {rows:[label], cols:[label], cells:[[v]], cls:[[c]], corner}
VIEWS.table = d => {
  let h = '<table style="border-collapse:collapse;font-family:var(--font-mono);font-size:12.5px;margin:0 auto">';
  h += '<tr><th style="padding:3px 7px;color:var(--muted)">' + esc(d.corner || '') + '</th>' + d.cols.map(c => '<th style="padding:3px 7px;color:var(--muted);font-weight:600">' + esc(c) + '</th>').join('') + '</tr>';
  d.cells.forEach((row, i) => {
    h += '<tr><th style="padding:3px 7px;color:var(--muted);font-weight:600;text-align:right">' + esc(d.rows[i]) + '</th>';
    row.forEach((v, j) => {
      const c = vc(d.cls && d.cls[i] && d.cls[i][j]);
      h += '<td style="min-width:34px;height:30px;text-align:center;border:1.5px solid ' + c.s + ';background:' + c.f + '">' + esc(v == null ? '' : String(v)) + '</td>';
    });
    h += '</tr>';
  });
  return h + '</table>';
};

// ---------- hash table buckets ----------
// d = {buckets:[[{k,v,cls}]], hl}
VIEWS.buckets = d => {
  // d.buckets: [{addr, cls, tag, nodes:[{k, v, addr, cls, tag}]}] ; d.side: optional html under
  let h = '<div style="display:grid;gap:6px;font-family:var(--font-mono);font-size:13px">';
  d.buckets.forEach((b, i) => {
    const c = vc(b.cls || 'st');
    h += '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;min-height:' + (b.nodes.length ? 44 : 30) + 'px">' +
      '<div style="width:54px;text-align:right;color:' + (b.tag ? 'var(--acc)' : 'var(--muted)') + ';font-size:11.5px;font-weight:' + (b.tag ? 700 : 400) + '">' + (b.tag ? esc(b.tag) + ' → ' : '') + '[' + i + ']</div>' +
      '<div title="' + (b.addr != null ? hex(b.addr) : '') + '" style="min-width:34px;height:30px;display:grid;place-items:center;border:1.5px solid ' + c.s + ';background:' + c.f + ';border-radius:5px;font-size:10.5px;color:var(--muted)">' + (b.nodes.length ? '●' : '∅') + '</div>';
    b.nodes.forEach(e => {
      const cc = vc(e.cls || 'hp');
      h += '<span style="color:var(--ptr)">→</span><div style="position:relative;padding:3px 10px 2px;border:1.5px solid ' + cc.s + ';background:' + cc.f + ';border-radius:7px;text-align:center;line-height:1.25">' +
        (e.tag ? '<div style="position:absolute;top:-15px;left:0;right:0;text-align:center;font-size:10.5px;font-weight:700;color:var(--acc)">' + esc(e.tag) + '</div>' : '') +
        '<b>' + esc(e.k) + '</b>' + (e.v != null ? ' <span style="color:var(--muted)">:</span> ' + esc(e.v) : '') +
        '<div style="font-size:9.5px;color:var(--muted)">' + (e.addr != null ? hex(e.addr) : '') + '</div></div>';
    });
    if (b.nodes.length) h += '<span style="color:var(--ptr)">→</span><span style="color:var(--muted);font-size:11px">NULL</span>';
    h += '</div>';
  });
  h += '</div>';
  if (d.foot) h += '<div class="cap" style="margin-top:10px">' + tr(d.foot) + '</div>';
  return h;
};
