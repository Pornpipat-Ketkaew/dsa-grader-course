/* =====================================================================
   Memory Lab UI: sidebar, home page, lab view, step controls, memory
   renderer, pointer arrows.
   ===================================================================== */

const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const UI = {
  scen: null, snaps: [], i: 0, playing: false, timer: null, speed: 1, params: {}, error: null,
  arrows: true
};

// ---------------------------------------------------------------- i18n UI strings
const T = {
  home: L('Overview', 'ภาพรวม'),
  step: L('Step', 'ขั้นที่'),
  play: L('Play', 'เล่น'), pause: L('Pause', 'หยุด'),
  code: L('Code', 'โค้ด'), console: L('Console output', 'ผลลัพธ์บนหน้าจอ'),
  view: L('Concept view', 'ภาพแนวคิด'), memory: L('Memory', 'หน่วยความจำ'),
  stack: L('Stack', 'Stack'), heap: L('Heap', 'Heap'),
  stackSub: L('high addresses at the top · grows downward ↓', 'แอดเดรสสูงอยู่บน · โตลงล่าง ↓'),
  heapSub: L('memory from new · lives until delete', 'หน่วยความจำจาก new · อยู่จนกว่าจะ delete'),
  noHeap: L('Nothing allocated with new yet.', 'ยังไม่มีอะไรถูกจองด้วย new'),
  run: L('Run with my input', 'รันด้วยข้อมูลของฉัน'), reset: L('Reset example', 'กลับไปตัวอย่างเดิม'),
  arrowsOn: L('Arrows on', 'แสดงลูกศร'), arrowsOff: L('Arrows off', 'ซ่อนลูกศร'),
  line: L('line', 'บรรทัด'), waiting: L('waiting here', 'รออยู่ตรงนี้'),
  returned: L('returned', 'คืนค่า'), popped: L('popped (gone)', 'ถูก pop ออกแล้ว'),
  bytes: L('bytes', 'ไบต์'), newb: L('new', 'ใหม่'), freed: L('freed', 'ถูกคืนแล้ว'),
  unused: L('unused', 'ว่าง'), menu: L('Menu', 'เมนู'),
  speed: L('Speed', 'ความเร็ว'), noOut: L('(nothing printed yet)', '(ยังไม่มีอะไรถูกพิมพ์)'),
  keys: L('Keys: ← → step · Space play · Home/End', 'ปุ่ม: ← → เลื่อนทีละขั้น · Space เล่น · Home/End'),
  error: L('Could not run that input:', 'รันข้อมูลนี้ไม่ได้:'),
  lesson: L('Course lesson', 'บทเรียน'),
  open: L('Open', 'เปิด'),
};

// ---------------------------------------------------------------- C++ syntax colouring
const KW = new Set('if else for while do return break continue new delete class struct public private protected template typename const static void auto true false nullptr this namespace using operator sizeof switch case default inline virtual friend'.split(' '));
const TY = new Set('int char bool double float long short unsigned size_t string vector list map set queue stack deque pair priority_queue unordered_map iterator T node std CP KeyT MappedT Comp greater less'.split(' '));
function hl(line) {
  let out = '', m;
  const re = /(\/\/.*$)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|(\b\d+(?:\.\d+)?\b)|([A-Za-z_]\w*)|(\s+)|(.)/g;
  while ((m = re.exec(line))) {
    if (m[1]) out += '<span class="tk-c">' + esc(m[1]) + '</span>';
    else if (m[2]) out += '<span class="tk-s">' + esc(m[2]) + '</span>';
    else if (m[3]) out += '<span class="tk-n">' + m[3] + '</span>';
    else if (m[4]) out += KW.has(m[4]) ? '<span class="tk-k">' + m[4] + '</span>' : TY.has(m[4]) ? '<span class="tk-t">' + m[4] + '</span>' : esc(m[4]);
    else if (m[5]) out += m[5];
    else out += (m[6] === '*' || m[6] === '&') ? '<span class="tk-p">' + esc(m[6]) + '</span>' : esc(m[6]);
  }
  return out;
}

// ---------------------------------------------------------------- value formatting
function fmtVal(v, type, ctx) {
  if (v === undefined) return '<span class="v garb" title="' + esc(tr(L('Uninitialized: whatever bits were left here before', 'ยังไม่ได้กำหนดค่า: เป็นบิตขยะที่ค้างอยู่เดิม'))) + '">?</span>';
  if (isP(v)) {
    if (v.p === 0) return '<span class="v ptr null" data-ptr="0">nullptr</span>';
    const dang = ctx && ctx.live && !ctx.live.has(v.p);
    return '<span class="v ptr' + (dang ? ' dang' : '') + '" data-ptr="' + v.p + '">' + hex(v.p) + '</span>';
  }
  return '<span class="v">' + esc(fmtPlain(v, type)) + '</span>';
}
function fmtPlain(v, type) {
  if (v === undefined) return '?';
  if (isP(v)) return v.p === 0 ? 'nullptr' : hex(v.p);
  if (isCH(v)) return "'" + (v.ch === '\0' ? '\\0' : v.ch) + "'";
  if (isSTR(v)) return '"' + v.str + '"';
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'number' && type && /double|float/.test(type) && Number.isInteger(v)) return v.toFixed(1);
  if (typeof v === 'number' && !Number.isInteger(v)) return String(Math.round(v * 1000) / 1000);
  return String(v);
}
function cellText(v, type, ctx) {
  if (isP(v)) {
    if (v.p === 0) return '<span class="ptrv null" data-ptr="0">null</span>';
    const dang = ctx && ctx.live && !ctx.live.has(v.p);
    return '<span class="ptrv' + (dang ? ' dang' : '') + '" data-ptr="' + v.p + '">' + hex(v.p) + '</span>';
  }
  return esc(fmtPlain(v, type));
}

// collect "address → display string" for change detection, and the set of live addresses
function addrMap(s) {
  const m = new Map(), live = new Set(), names = new Map();
  const put = (a, v, t) => m.set(a, fmtPlain(v, t));
  for (const f of s.frames) for (const v of f.vars) {
    if (v.kind === 'scalar') { put(v.addr, v.value, v.type); live.add(v.addr); names.set(v.addr, v.name); }
    if (v.kind === 'obj') { live.add(v.addr); names.set(v.addr, v.name); for (const fd of v.fields) { put(fd.addr, fd.value, fd.type); live.add(fd.addr); names.set(fd.addr, v.name + '.' + fd.name); } }
    if (v.kind === 'array') { v.cells.forEach((c, i) => { const a = v.addr + i * v.es; put(a, c, v.elemType); live.add(a); names.set(a, v.name + (v.cols ? '[' + Math.floor(i / v.cols) + '][' + (i % v.cols) + ']' : '[' + i + ']')); }); live.add(v.addr + v.n * v.es); }
  }
  for (const b of s.heap) {
    if (b.freed) continue;
    if (b.kind === 'array') { b.cells.forEach((c, i) => { const a = b.addr + i * b.es; put(a, c, b.elemType); live.add(a); }); live.add(b.addr + b.n * b.es); }
    if (b.kind === 'obj') { live.add(b.addr); for (const fd of b.fields) { put(fd.addr, fd.value, fd.type); live.add(fd.addr); } }
  }
  return { m, live, names };
}

// ---------------------------------------------------------------- sidebar + routing
function buildSide() {
  let h = '<a href="#home" data-id="home"><span class="ls">◎</span><span>' + tr(T.home) + '</span></a>';
  for (const part of PARTS) {
    h += '<h4>' + (LANG === 'th' ? 'ภาค ' : 'Part ') + ['', 'I', 'II', 'III'][part.id] + ' · ' + tr(part.title) + '<small>' + tr(part.sub) + '</small></h4>';
    for (const s of SCEN.filter(s => s.part === part.id))
      h += '<a href="#' + s.id + '" data-id="' + s.id + '"><span class="ls">' + esc(s.lesson || '') + '</span><span>' + tr(s.title) + '</span></a>';
  }
  $('#side').innerHTML = h;
  markSide();
}
function markSide() {
  const id = UI.scen ? UI.scen.id : 'home';
  document.querySelectorAll('#side a').forEach(a => { if (a.dataset.id === id) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
}
function route() {
  stop();
  const id = (location.hash || '#home').slice(1);
  const s = SCEN.find(x => x.id === id);
  $('#side').classList.remove('open');
  if (!s) { UI.scen = null; showHome(); }
  else openScen(s);
  markSide();
  window.scrollTo(0, 0);
}

// ---------------------------------------------------------------- lab
function openScen(s, keepParams) {
  UI.scen = s;
  if (!keepParams) { UI.params = {}; (s.params || []).forEach(p => UI.params[p.id] = p.value); }
  runScen();
  renderLab();
}
function runScen() {
  const s = UI.scen;
  const sim = new Sim(s.simOpts || {});
  UI.error = null;
  try { s.build(sim, UI.params); }
  catch (e) {
    UI.error = e && e.message === 'STEP_LIMIT' ? tr(L('Too many steps: try a smaller input.', 'ขั้นตอนเยอะเกินไป ลองข้อมูลที่เล็กลง')) : (e && e.userMsg ? tr(e.userMsg) : String(e && e.message || e));
    if (window.console) console.warn(e);
  }
  UI.snaps = sim.snaps;
  UI.i = 0;
}
function userErr(msg) { const e = new Error(tr(msg)); e.userMsg = msg; return e; }

function renderLab() {
  const s = UI.scen;
  const pHTML = (s.params && s.params.length) ? '<div class="params">' + s.params.map(p =>
    '<label for="p-' + p.id + '">' + tr(p.label) + '<input id="p-' + p.id + '" data-p="' + p.id + '" value="' + esc(UI.params[p.id]) + '" spellcheck="false"' + (p.w ? ' style="width:' + p.w + 'px"' : '') + '></label>').join('') +
    '<button class="btn primary" id="runbtn">' + tr(T.run) + '</button><button class="btn" id="resetbtn">' + tr(T.reset) + '</button>' +
    (s.paramHint ? '<div class="hint" style="flex-basis:100%">' + tr(s.paramHint) + '</div>' : '') +
    (UI.error ? '<div class="err" style="flex-basis:100%">' + tr(T.error) + ' ' + esc(UI.error) + '</div>' : '') + '</div>'
    : (UI.error ? '<div class="params"><div class="err">' + esc(UI.error) + '</div></div>' : '');
  const lessonTxt = s.lesson ? tr(T.lesson) + ' ' + s.lesson + (s.lessonFile ? ' · ' + s.lessonFile : '') : '';
  $('#main').innerHTML =
    '<div class="lab-head"><div class="crumbs">' + esc(lessonTxt) + '</div><h1>' + tr(s.title) + '</h1><p class="summary">' + tr(s.summary) + '</p></div>' + pHTML +
    '<div class="stepbar"><div class="controls">' +
    '<button id="b-first" title="Home" aria-label="first step">⏮</button><button id="b-prev" title="←" aria-label="previous step">◀</button>' +
    '<button id="b-play" class="play"></button><button id="b-next" title="→" aria-label="next step">▶</button><button id="b-last" title="End" aria-label="last step">⏭</button>' +
    '<input type="range" id="slider" min="0" value="0" aria-label="step">' +
    '<span class="count" id="count"></span>' +
    '<select id="speed" aria-label="' + tr(T.speed) + '"><option value="0.5">0.5×</option><option value="1" selected>1×</option><option value="2">2×</option><option value="4">4×</option></select>' +
    '</div><div class="note" id="note" aria-live="polite"></div></div>' +
    '<div class="lab-grid">' +
    '<div class="col col-left">' +
    '<div class="panel"><div class="ph">' + tr(T.code) + '</div><div class="code" id="code"></div></div>' +
    '<div class="panel"><div class="ph">' + tr(T.console) + '</div><pre class="console" id="console"></pre></div>' +
    '</div>' +
    '<div class="panel" id="viewpanel"><div class="ph">' + tr(T.view) + '<span class="sub" id="viewcap"></span></div><div class="view" id="view"></div></div>' +
    '<div class="panel" id="mempanel"><div class="ph">' + tr(T.memory) + '<span class="sub">' + tr(L('every box has a real address · arrows are pointers', 'ทุกกล่องมีแอดเดรสจริง · ลูกศรคือพอยน์เตอร์')) + '</span><span style="flex:1"></span><button class="iconbtn" id="arrbtn"></button></div>' +
    '<div class="mem" id="mem"></div>' + legendBar() + '</div>' +
    '</div>';
  // code
  const lines = (s.codeFn ? s.codeFn(UI.params) : s.code).replace(/\n$/, '').split('\n');
  $('#code').innerHTML = lines.map((ln, k) => '<div class="ln" data-n="' + (k + 1) + '"><span class="no">' + (k + 1) + '</span><span>' + (hl(ln) || ' ') + '</span></div>').join('');
  UI.lines = lines;
  { const g = document.querySelector('.lab-grid'), anyView = UI.snaps.some(x => x.view), anyHeap = UI.snaps.some(x => x.heap.length);
    const wideView = anyView && UI.snaps.some(x => x.view && /^(chain|tree|graph|buckets|ring)$/.test(x.view.kind));
    g.classList.toggle('noview', !anyView); g.classList.toggle('wide', anyHeap && wideView); }
  // controls
  const sl = $('#slider'); sl.max = Math.max(0, UI.snaps.length - 1);
  sl.oninput = () => go(+sl.value);
  $('#b-first').onclick = () => go(0);
  $('#b-prev').onclick = () => go(UI.i - 1);
  $('#b-next').onclick = () => go(UI.i + 1);
  $('#b-last').onclick = () => go(UI.snaps.length - 1);
  $('#b-play').onclick = () => UI.playing ? stop() : play();
  $('#speed').value = String(UI.speed);
  $('#speed').onchange = e => { UI.speed = +e.target.value; if (UI.playing) { stop(); play(); } };
  $('#arrbtn').onclick = () => { UI.arrows = !UI.arrows; syncArrowBtn(); };
  syncArrowBtn();
  if ($('#runbtn')) {
    $('#runbtn').onclick = () => { document.querySelectorAll('[data-p]').forEach(inp => UI.params[inp.dataset.p] = inp.value); openScen(s, true); };
    $('#resetbtn').onclick = () => openScen(s, false);
    document.querySelectorAll('[data-p]').forEach(inp => inp.onkeydown = e => { if (e.key === 'Enter') $('#runbtn').click(); });
  }
  go(0, true);
}
function syncArrowBtn() {
  const b = $('#arrbtn'); if (!b) return;
  b.textContent = UI.arrows ? tr(T.arrowsOn) : tr(T.arrowsOff);
  $('#mem').classList.toggle('arrows-off', !UI.arrows);
}
function legendBar() {
  const it = (cls, t) => '<span><i class="sw ' + cls + '"></i>' + tr(t) + '</span>';
  return '<div class="legend-bar">' + it('st', L('stack frame', 'เฟรมบน stack')) + it('hp', L('heap block', 'บล็อกบน heap')) + it('pt', L('pointer', 'พอยน์เตอร์')) +
    it('ch', L('just changed', 'เพิ่งถูกเขียน')) + it('rd', L('just read', 'เพิ่งถูกอ่าน')) + it('nw', L('just created', 'เพิ่งถูกสร้าง')) + it('gb', L('? = garbage', '? = ค่าขยะ')) + it('un', L('allocated but unused', 'จองแล้วแต่ยังไม่ใช้')) + '</div>';
}

function play() {
  if (UI.i >= UI.snaps.length - 1) go(0);
  UI.playing = true; $('#b-play') && ($('#b-play').textContent = '❚❚ ' + tr(T.pause));
  UI.timer = setInterval(() => { if (UI.i >= UI.snaps.length - 1) stop(); else go(UI.i + 1); }, 1400 / UI.speed);
}
function stop() {
  UI.playing = false; clearInterval(UI.timer); UI.timer = null;
  const b = $('#b-play'); if (b) b.textContent = '▶ ' + tr(T.play);
}

function go(i, first) {
  if (!UI.snaps.length) { $('#note').textContent = UI.error || ''; $('#b-play').textContent = '▶ ' + tr(T.play); return; }
  i = Math.max(0, Math.min(UI.snaps.length - 1, i));
  UI.i = i;
  const s = UI.snaps[i], prev = i > 0 ? UI.snaps[i - 1] : null;
  $('#slider').value = i;
  $('#count').textContent = tr(T.step) + ' ' + (i + 1) + ' / ' + UI.snaps.length;
  if (!UI.playing) $('#b-play').textContent = '▶ ' + tr(T.play);
  const note = $('#note');
  const ln = s.line && UI.lines ? UI.lines[s.line - 1] : null;
  note.innerHTML = tr(s.note) + (ln && ln.trim() ? '<span class="lineecho"><b>' + tr(L('line', 'บรรทัด')) + ' ' + s.line + '</b> │ ' + esc(ln.trim()) + '</span>' : '');
  note.classList.toggle('warn', s.cls === 'warn');
  renderCode(s);
  renderConsole(s, prev);
  renderView(s);
  renderMem(s, prev);
}

function renderCode(s) {
  const box = $('#code');
  box.querySelectorAll('.ln').forEach(el => { el.classList.remove('cur', 'wait', 'extra'); el.removeAttribute('data-w'); });
  const frames = s.frames;
  // caller frames: mark their lines as "waiting"
  for (let k = 0; k < frames.length - 1; k++) {
    const f = frames[k];
    if (f.line != null) {
      const el = box.querySelector('.ln[data-n="' + f.line + '"]');
      if (el) { el.classList.add('wait'); el.setAttribute('data-w', '↩ ' + f.sig.replace(/\(.*$/, '()') + ' ' + tr(T.waiting)); }
    }
  }
  (s.lines || []).forEach(n => { const el = box.querySelector('.ln[data-n="' + n + '"]'); if (el) el.classList.add('extra'); });
  if (s.line != null) {
    const el = box.querySelector('.ln[data-n="' + s.line + '"]');
    if (el) {
      el.classList.remove('wait'); el.removeAttribute('data-w'); el.classList.add('cur');
      const top = el.offsetTop, h = box.clientHeight;
      if (top < box.scrollTop + 20 || top > box.scrollTop + h - 40) box.scrollTop = Math.max(0, top - h / 3);
    }
  }
}
function renderConsole(s, prev) {
  const c = $('#console');
  const old = prev ? prev.out : '';
  if (!s.out) { c.innerHTML = '<span style="color:var(--muted)">' + tr(T.noOut) + '</span>'; return; }
  if (s.out.startsWith(old) && s.out.length > old.length) c.innerHTML = esc(old) + '<span class="new">' + esc(s.out.slice(old.length)) + '</span>';
  else c.textContent = s.out;
  c.scrollTop = c.scrollHeight;
}
function renderView(s) {
  const panel = $('#viewpanel');
  if (!s.view) { panel.style.display = 'none'; return; }
  panel.style.display = '';
  const fn = VIEWS[s.view.kind];
  $('#view').innerHTML = (s.view.cap ? '<div class="cap">' + tr(s.view.cap) + '</div>' : '') + (fn ? fn(s.view) : '');
  $('#viewcap').textContent = s.view.title ? ' · ' + tr(s.view.title) : '';
}

// ---------------------------------------------------------------- memory renderer
function renderMem(s, prev) {
  const mem = $('#mem');
  const cur = addrMap(s), old = prev ? addrMap(prev) : null;
  const reads = new Set(s.reads);
  const tagsBy = new Map();
  (s.tags || []).forEach(t => { if (!tagsBy.has(t.addr)) tagsBy.set(t.addr, []); tagsBy.get(t.addr).push(t); });
  const ctx = { live: cur.live };
  const st = a => {   // state classes for an address
    let c = '';
    if (old && cur.m.has(a) && old.m.has(a) && old.m.get(a) !== cur.m.get(a)) c += ' chg';
    if (reads.has(a)) c += ' read';
    return c;
  };
  const tagHTML = a => (tagsBy.get(a) || []).map(t => '<span class="tag ' + (t.cls || '') + '">' + esc(t.label) + '</span>').join('');

  // pointer targets beyond the end of an array (end() iterators)
  const ptrTargets = new Set();
  const scanP = v => { if (isP(v) && v.p) ptrTargets.add(v.p); };
  for (const f of s.frames.concat(s.ghosts || [])) for (const v of f.vars) { if (v.kind === 'scalar') scanP(v.value); if (v.kind === 'obj') v.fields.forEach(fd => scanP(fd.value)); if (v.kind === 'array') v.cells.forEach(scanP); }
  for (const b of s.heap) { if (b.kind === 'obj') b.fields.forEach(fd => scanP(fd.value)); else b.cells.forEach(scanP); }

  const arrHTML = (base, cells, es, et, used, region, cols) => {
    let h = '<div class="arr">';
    cells.forEach((c, i) => {
      const a = base + i * es;
      const un = used != null && i >= used;
      h += '<div class="cell' + (i === cells.length - 1 ? ' last' : '') + (un ? ' unused' : '') + (c === undefined ? ' garb' : '') + st(a) + '" data-addr="' + a + '">' +
        '<span class="tags">' + tagHTML(a) + '</span><span class="ci">' + (cols ? '[' + Math.floor(i / cols) + '][' + (i % cols) + ']' : '[' + i + ']') + '</span><span class="cv">' + (c === undefined ? '?' : cellText(c, et, ctx)) + '</span><span class="ca">' + hex(a) + '</span></div>';
    });
    const endA = base + cells.length * es;
    if (ptrTargets.has(endA) || tagsBy.has(endA)) h += '<div class="cell endmark" data-addr="' + endA + '"><span class="tags">' + tagHTML(endA) + '</span><span class="ci">&nbsp;</span><span class="cv">end</span><span class="ca">' + hex(endA) + '</span></div>';
    return h + '</div>';
  };

  const varHTML = v => {
    if (v.kind === 'scalar') {
      if (v.hidden) return '';
      let val;
      if (v.ref) {
        const tn = cur.names.get(v.value.p);
        val = '<span class="v ptr" data-ptr="' + v.value.p + '" data-ref="1">' + hex(v.value.p) + '</span> <span style="font-size:11.5px;color:var(--muted)">' + esc(tr(L('alias of', 'ชื่อเล่นของ'))) + ' <b>' + esc(tn || '?') + '</b></span>';
      } else val = fmtVal(v.value, v.type, ctx);
      return '<div class="var' + (v.param ? ' param' : '') + (v.ref ? ' ref' : '') + (old && !old.m.has(v.addr) ? ' nwv' : '') + st(v.addr) + '" data-addr="' + v.addr + '">' +
        '<span class="addr">' + hex(v.addr) + '</span><span class="nm">' + esc(v.name) + '<small>' + esc(v.type) + ' · ' + v.size + 'B</small></span><span class="val">' + val + ' ' + tagHTML(v.addr) + '</span></div>';
    }
    if (v.kind === 'obj') {
      return '<div class="var objv' + (v.param ? ' param' : '') + '" data-base="' + v.addr + '"><div class="oh"><span class="nm">' + esc(v.name) + '</span><span class="ty">' + esc(v.type) + '</span>' + tagHTML(v.addr) + '<span class="addr">' + hex(v.addr) + ' · ' + v.size + 'B</span></div><div class="fields">' +
        v.fields.map(fd => '<div class="fld' + st(fd.addr) + '" data-addr="' + fd.addr + '"><span class="addr">' + hex(fd.addr) + '</span><span class="fn">' + esc(fd.name) + '<small>' + esc(fd.type) + '</small></span><span>' + fmtVal(fd.value, fd.type, ctx) + ' ' + tagHTML(fd.addr) + '</span></div>').join('') + '</div></div>';
    }
    if (v.kind === 'array') {
      return '<div class="var objv' + (v.param ? ' param' : '') + '"><div class="oh"><span class="nm">' + esc(v.name) + '</span><span class="ty">' + esc(v.type) + '</span><span class="addr">' + hex(v.addr) + ' · ' + v.size + 'B</span></div>' + arrHTML(v.addr, v.cells, v.es, v.elemType, null, 'stack', v.cols) + '</div>';
    }
    return '';
  };

  const frameHTML = (f, isTop, dead) => {
    const saved = ctx.live;
    if (dead) { ctx.live = new Set(cur.live); for (const g of (s.ghosts || [])) for (const v of g.vars) { ctx.live.add(v.addr); if (v.fields) v.fields.forEach(fd => ctx.live.add(fd.addr)); if (v.kind === 'array') for (let i = 0; i <= v.n; i++) ctx.live.add(v.addr + i * v.es); } }
    try { return frameHTML0(f, isTop, dead); } finally { ctx.live = saved; }
  };
  const frameHTML0 = (f, isTop, dead) => {
    const vars = f.vars.slice().sort((a, b) => b.addr - a.addr);
    return '<div class="frame' + (isTop ? ' top' : '') + (dead ? ' dead' : '') + '"><div class="frame-h"><span>' + esc(f.sig) + '</span><span class="fl">' +
      (dead ? tr(T.popped) : (f.line != null ? tr(T.line) + ' ' + f.line : '')) + '</span></div><div class="frame-body">' +
      (vars.length ? vars.map(varHTML).join('') : '<div style="font-size:12px;color:var(--muted);padding:2px 6px">' + tr(L('(no local variables)', '(ไม่มีตัวแปรภายใน)')) + '</div>') + '</div>' +
      (f.ret ? '<div class="retchip">↩ ' + esc(f.ret.from.replace(/\s*\{.*$/, '')) + ' ' + tr(T.returned) + ' <b>' + esc(fmtPlain(f.ret.value, f.ret.type)) + '</b></div>' : '') + '</div>';
  };

  let sh = '<div class="region stack"><div class="region-h"><span>' + tr(T.stack) + '</span><span class="sub">' + tr(T.stackSub) + '</span></div>';
  s.frames.forEach((f, k) => sh += frameHTML(f, k === s.frames.length - 1, false));
  (s.ghosts || []).forEach(f => sh += frameHTML(f, false, true));
  if (!s.frames.length && !(s.ghosts || []).length) sh += '<div class="empty-note">' + tr(L('No function is running.', 'ไม่มีฟังก์ชันที่กำลังทำงาน')) + '</div>';
  sh += '</div>';

  let hh = '<div class="region heap"><div class="region-h"><span>' + tr(T.heap) + '</span><span class="sub">' + tr(T.heapSub) + '</span></div>';
  if (!s.heap.length) hh += '<div class="empty-note">' + tr(T.noHeap) + '</div>';
  let k = 0;
  const blocks = s.heap;
  while (k < blocks.length) {
    const b = blocks[k];
    if (b.kind === 'array') {
      hh += '<div class="block' + (b.born ? ' born' : '') + (b.freed ? ' freed' : '') + '"><div class="block-h">' + (b.label ? '<span class="bl">' + esc(tr(b.label)) + '</span>' : '') + '<span class="bx">' + esc(b.expr) + ' · ' + b.size + 'B · ' + hex(b.addr) + '–' + hex(b.addr + b.size - 1) + '</span>' +
        (b.born ? '<span class="badge">' + tr(T.newb) + '</span>' : '') + (b.freed ? '<span class="badge freedb">' + tr(T.freed) + '</span>' : '') + '</div>' + arrHTML(b.addr, b.cells, b.es, b.elemType, b.used, 'heap') + '</div>';
      k++;
    } else {
      hh += '<div class="heap-nodes">';
      while (k < blocks.length && blocks[k].kind === 'obj') {
        const o = blocks[k];
        hh += '<div class="block obj' + (o.born ? ' born' : '') + (o.freed ? ' freed' : '') + '" data-base="' + o.addr + '"><div class="block-h">' + (o.label ? '<span class="bl">' + esc(tr(o.label)) + '</span>' : '<span class="bl">' + esc(o.type) + '</span>') + '<span class="bx">' + hex(o.addr) + ' · ' + o.size + 'B</span>' + tagHTML(o.addr) +
          (o.born ? '<span class="badge">' + tr(T.newb) + '</span>' : '') + (o.freed ? '<span class="badge freedb">' + tr(T.freed) + '</span>' : '') + '</div><div class="fields">' +
          o.fields.map(fd => '<div class="fld' + st(fd.addr) + '" data-addr="' + fd.addr + '"><span class="addr">' + hex(fd.addr) + '</span><span class="fn">' + esc(fd.name) + '<small>' + esc(fd.type) + '</small></span><span>' + fmtVal(fd.value, fd.type, ctx) + '</span></div>').join('') + '</div></div>';
        k++;
      }
      hh += '</div>';
    }
  }
  hh += '</div>';
  const anyHeap = UI.snaps.some(x => x.heap.length);
  mem.classList.toggle('no-heap', !anyHeap);
  mem.classList.toggle('heap-light', anyHeap && Math.max(...UI.snaps.map(x => x.heap.filter(b => !b.freed).length)) <= 2);
  mem.innerHTML = sh + (anyHeap ? hh : '') + '<svg class="arrows" aria-hidden="true"></svg>';
  // remember which pointers changed
  mem.querySelectorAll('[data-ptr]').forEach(el => {
    const holder = el.closest('[data-addr]');
    if (holder && (holder.classList.contains('chg'))) el.dataset.hchg = '1';
  });
  requestAnimationFrame(drawArrows);
}

function drawArrows() {
  const mem = $('#mem'); if (!mem) return;
  const svg = mem.querySelector('svg.arrows'); if (!svg) return;
  const R = mem.getBoundingClientRect();
  let h = '<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" style="fill:var(--ptr);stroke:none"/></marker></defs>';
  const srcs = [...mem.querySelectorAll('[data-ptr]')].filter(el => el.dataset.ptr !== '0');
  let lane = 0;
  srcs.forEach((el, idx) => {
    const p = el.dataset.ptr;
    const tgt = mem.querySelector('[data-base="' + p + '"]') || mem.querySelector('.cell[data-addr="' + p + '"]') || mem.querySelector('[data-addr="' + p + '"]');
    if (!tgt) return;
    const a = el.getBoundingClientRect(), b = (tgt.classList.contains('cell') ? (tgt.querySelector('.cv') || tgt) : tgt).getBoundingClientRect();
    const lab = el.dataset.ref && el.nextElementSibling;
    const sx = (lab ? lab.getBoundingClientRect().right + 4 : a.right) - R.left, sy = a.top + a.height / 2 - R.top;
    let d;
    const isCell = tgt.classList.contains('cell');
    if (isCell) {
      // aim at the top-centre of the cell's value box
      const tx = b.left + b.width / 2 - R.left, ty = b.top - R.top;
      if (ty > sy + 8) d = 'M' + sx + ',' + sy + ' C' + (sx + 50) + ',' + sy + ' ' + tx + ',' + (ty - 50) + ' ' + tx + ',' + ty;
      else { const by = b.bottom - R.top; d = 'M' + sx + ',' + sy + ' C' + (sx + 50) + ',' + sy + ' ' + tx + ',' + (by + 60) + ' ' + tx + ',' + by; }
    } else {
      const tl = b.left - R.left, tr_ = b.right - R.left, ty = b.top + Math.min(14, b.height / 2) - R.top;
      if (tl > sx + 10) d = 'M' + sx + ',' + sy + ' C' + (sx + (tl - sx) / 2) + ',' + sy + ' ' + (tl - (tl - sx) / 2) + ',' + ty + ' ' + tl + ',' + ty;
      else if (tr_ < a.left - R.left - 10) { const sx2 = a.left - R.left; d = 'M' + sx2 + ',' + sy + ' C' + (sx2 - 40) + ',' + sy + ' ' + (tr_ + 40) + ',' + ty + ' ' + tr_ + ',' + ty; }
      else { const out = Math.max(sx, tr_) + 22 + (lane++ % 4) * 8; d = 'M' + sx + ',' + sy + ' C' + out + ',' + sy + ' ' + out + ',' + ty + ' ' + tr_ + ',' + ty; }
    }
    h += '<path data-i="' + idx + '" class="' + (el.dataset.hchg ? 'hchg' : '') + (el.dataset.ref ? ' refp' : '') + '" d="' + d + '" marker-end="url(#ah)"/>';
    el.dataset.ai = idx;
  });
  svg.innerHTML = h;
}

function hookHover() {
  document.addEventListener('mouseover', e => {
    const el = e.target.closest && e.target.closest('[data-ai]');
    const svg = document.querySelector('#mem svg.arrows'); if (!svg) return;
    svg.querySelectorAll('path').forEach(p => p.classList.remove('hot', 'dim'));
    if (el) { svg.querySelectorAll('path[data-i]').forEach(p => p.classList.add(p.dataset.i === el.dataset.ai ? 'hot' : 'dim')); }
  });
}

// ---------------------------------------------------------------- language
function setLang(l) {
  LANG = l;
  try { localStorage.setItem('memlab-lang', l); } catch (e) { }
  document.documentElement.lang = l === 'th' ? 'th' : 'en';
  document.querySelectorAll('#lang button').forEach(b => b.setAttribute('aria-pressed', b.dataset.l === l ? 'true' : 'false'));
  $('#menubtn').textContent = tr(T.menu);
  buildSide();
  if (UI.scen) { const i = UI.i; renderLab(); go(i); } else showHome();
}

function init() {
  SCEN.sort((a, b) => a.part - b.part || (a.part === 3 ? (+a.lesson) - (+b.lesson) : 0));
  try { const l = localStorage.getItem('memlab-lang'); if (l) LANG = l; } catch (e) { }
  document.querySelectorAll('#lang button').forEach(b => b.onclick = () => setLang(b.dataset.l));
  $('#menubtn').onclick = () => $('#side').classList.toggle('open');
  window.addEventListener('hashchange', route);
  window.addEventListener('resize', () => requestAnimationFrame(drawArrows));
  document.addEventListener('keydown', e => {
    if (!UI.scen || /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) return;
    if (e.key === 'ArrowRight') { e.preventDefault(); stop(); go(UI.i + 1); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); stop(); go(UI.i - 1); }
    else if (e.key === ' ') { e.preventDefault(); UI.playing ? stop() : play(); }
    else if (e.key === 'Home') { e.preventDefault(); go(0); }
    else if (e.key === 'End') { e.preventDefault(); go(UI.snaps.length - 1); }
  });
  hookHover();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => requestAnimationFrame(drawArrows));
  setLang(LANG);
  route();
}
