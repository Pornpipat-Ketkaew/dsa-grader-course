// usage: node test.js [scenarioId] [shotStep]
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1500, height: 1000 } });
  const errs = [];
  page.on('pageerror', e => errs.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errs.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve('dist/index.html'));
  await page.waitForTimeout(300);
  const only = process.argv[2];
  const ids = await page.evaluate(() => SCEN.map(s => s.id));
  let total = 0;
  for (const id of ids) {
    if (only && only !== 'all' && only !== id) continue;
    for (const lang of ['en', 'th']) {
      await page.evaluate(([id, lang]) => { LANG = lang; location.hash = '#' + id; route(); }, [id, lang]);
      const r = await page.evaluate(() => {
        const out = { n: UI.snaps.length, err: UI.error, bad: [] };
        for (let i = 0; i < UI.snaps.length; i++) {
          try { go(i); } catch (e) { out.bad.push(i + ': ' + e.message); continue; }
          const note = document.querySelector('#note').textContent;
          if (!note || note.length < 3) out.bad.push(i + ': empty note');
          const s = UI.snaps[i];
          if (s.line == null && i > 0) out.bad.push(i + ': no line');
          // dangling pointers that are not expected
          const d = document.querySelectorAll('#mem .dang').length;
          if (d && !UI.scen.dangOK) out.bad.push(i + ': dangling x' + d);
        }
        return out;
      });
      total += r.n;
      if (lang === 'en' || r.err || r.bad.length) console.log(id, lang, 'steps=' + r.n, r.err ? 'ERROR ' + r.err : '', r.bad.length ? JSON.stringify(r.bad.slice(0, 12)) : '');
    }
  }
  if (only && process.argv[3] != null) {
    await page.evaluate(([id, k, lang]) => { LANG = lang || 'en'; location.hash = '#' + id; route(); go(+k); }, [only, process.argv[3], process.argv[4]]);
    await page.waitForTimeout(400);
    await page.screenshot({ path: '/tmp/claude-0/shot.png', fullPage: true });
    console.log('shot saved');
  }
  console.log('total steps', total, 'errors', errs.length ? errs.slice(0, 10) : 'none');
  await browser.close();
})();
