import glob, os, sys
src = 'src'
css = open(f'{src}/style.css', encoding='utf-8').read()
order = ['engine.js', 'views.js', 'ui.js', 'home.js']
js = '\n'.join(open(f'{src}/{f}', encoding='utf-8').read() for f in order)
for f in sorted(glob.glob(f'{src}/scen/*.js')):
    js += '\n' + open(f, encoding='utf-8').read()
html = open(f'{src}/template.html', encoding='utf-8').read().replace('/*CSS*/', css).replace('/*JS*/', js)
os.makedirs('dist', exist_ok=True)
open('dist/index.html', 'w', encoding='utf-8').write(html)
print('built', len(html), 'bytes')
